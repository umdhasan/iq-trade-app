package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.engine.HasanProSignal
import com.example.engine.SignalEngine
import com.example.engine.TechnicalAnalysisEngine
import com.example.model.Candle
import com.example.model.ExpiryTime
import com.example.model.FeedRef
import com.example.model.FeedSource
import com.example.model.MarketCategory
import com.example.model.MarketPlatform
import com.example.model.MarketType
import com.example.model.TradingAsset
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("TradePro IQ", appName)
  }

  @Test
  fun `hasan pro signal and signal generation on an uptrend`() {
    val base = 1_700_000_000_000L
    val candles = (1..80).map { i ->
      val o = 100.0 + i * 0.30
      Candle(
        timestamp = base + i * 60_000L,
        open = o,
        high = o + 0.42,
        low = o - 0.02,
        close = o + 0.40,
        volume = 50.0 + i
      )
    }

    val indicators = TechnicalAnalysisEngine.analyze(candles)
    assertTrue(indicators.rsi14 in 0.0..100.0)
    assertTrue(indicators.bbUpper >= indicators.bbLower)

    val state = HasanProSignal.lastClosed(candles)
    assertTrue("steady uptrend must never give a DOWN signal", !state.isDown)

    val asset = TradingAsset(
      id = "blitz_eur_usd",
      symbol = "EUR/USD",
      name = "Euro / US Dollar",
      category = MarketCategory.CURRENCIES,
      marketType = MarketType.BLITZ,
      feed = FeedRef(FeedSource.YAHOO, "EURUSD=X"),
      payoutPercent = 87,
      priceDecimals = 5,
      currentPrice = candles.last().close,
      prevPrice = candles[candles.size - 2].close
    )

    val signal = SignalEngine.generateSignal(
      asset = asset,
      candles = candles,
      indicators = indicators,
      platform = MarketPlatform.IQ_OPTION,
      expiryTime = ExpiryTime.MIN_1,
      baseTradeAmount = 10.0
    )

    assertNotNull(signal)
    assertTrue(signal.confidence in 0..100)
    assertTrue(signal.martingaleStep1 > 10.0)
  }

  @Test
  fun `too few candles gives WAIT`() {
    val candles = (1..10).map { i ->
      Candle(1_700_000_000_000L + i * 60_000L, 100.0, 100.5, 99.5, 100.2, 1.0)
    }
    val state = HasanProSignal.lastClosed(candles)
    assertTrue(!state.hasSignal)
  }
}
