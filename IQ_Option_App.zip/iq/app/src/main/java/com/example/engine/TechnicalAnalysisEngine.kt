package com.example.engine

import com.example.model.Candle
import com.example.model.TechnicalIndicators
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sqrt

object TechnicalAnalysisEngine {

    fun analyze(candles: List<Candle>): TechnicalIndicators {
        if (candles.isEmpty()) {
            return defaultIndicators()
        }

        val closes = candles.map { it.close }
        val rsi = calculateRsi(closes, 14)
        val ema9 = calculateEma(closes, 9)
        val ema21 = calculateEma(closes, 21)
        val (bbUpper, bbMiddle, bbLower) = calculateBollingerBands(closes, 20, 2.0)
        val (macdVal, macdSig, macdHist) = calculateMacd(closes)
        val (stochK, stochD) = calculateStochastic(candles, 14, 3)

        // Bullish sentiment calculation based on recent candle bodies & momentum
        val recentCandles = candles.takeLast(10)
        val bullCandlesCount = recentCandles.count { it.isBullish }
        val bullRatio = (bullCandlesCount.toDouble() / recentCandles.size.toDouble()) * 100.0
        val sentiment = (bullRatio * 0.6 + (rsi / 100.0 * 40.0)).toInt().coerceIn(15, 88)

        // Volatility assessment
        val lastPrice = closes.last()
        val bandSpread = if (bbMiddle > 0) ((bbUpper - bbLower) / bbMiddle) * 100.0 else 0.5
        val volatilityLevel = when {
            bandSpread > 2.0 -> "Ultra"
            bandSpread > 1.2 -> "High"
            bandSpread > 0.6 -> "Medium"
            else -> "Low"
        }

        // Trend recommendation
        val trend = when {
            rsi < 30 && lastPrice <= bbLower -> "STRONG_BUY"
            rsi < 42 && ema9 > ema21 -> "BUY"
            rsi > 70 && lastPrice >= bbUpper -> "STRONG_SELL"
            rsi > 58 && ema9 < ema21 -> "SELL"
            ema9 > ema21 && macdHist > 0 -> "BUY"
            ema9 < ema21 && macdHist < 0 -> "SELL"
            else -> "NEUTRAL"
        }

        return TechnicalIndicators(
            rsi14 = rsi,
            ema9 = ema9,
            ema21 = ema21,
            bbUpper = bbUpper,
            bbMiddle = bbMiddle,
            bbLower = bbLower,
            macdValue = macdVal,
            macdSignal = macdSig,
            macdHistogram = macdHist,
            stochasticK = stochK,
            stochasticD = stochD,
            bullishSentimentPercent = sentiment,
            volatilityLevel = volatilityLevel,
            trendRecommendation = trend
        )
    }

    private fun calculateRsi(prices: List<Double>, period: Int = 14): Double {
        if (prices.size <= period) return 50.0
        var gains = 0.0
        var losses = 0.0

        for (i in 1..period) {
            val diff = prices[i] - prices[i - 1]
            if (diff >= 0) gains += diff else losses -= diff
        }

        var avgGain = gains / period
        var avgLoss = losses / period

        for (i in (period + 1) until prices.size) {
            val diff = prices[i] - prices[i - 1]
            if (diff >= 0) {
                avgGain = (avgGain * (period - 1) + diff) / period
                avgLoss = (avgLoss * (period - 1)) / period
            } else {
                avgGain = (avgGain * (period - 1)) / period
                avgLoss = (avgLoss * (period - 1) - diff) / period
            }
        }

        if (avgLoss == 0.0) return 100.0
        val rs = avgGain / avgLoss
        return (100.0 - (100.0 / (1.0 + rs))).coerceIn(0.0, 100.0)
    }

    private fun calculateEma(prices: List<Double>, period: Int): Double {
        if (prices.isEmpty()) return 0.0
        if (prices.size < period) return prices.average()

        val multiplier = 2.0 / (period + 1.0)
        var ema = prices.take(period).average()

        for (i in period until prices.size) {
            ema = (prices[i] - ema) * multiplier + ema
        }
        return ema
    }

    private fun calculateBollingerBands(
        prices: List<Double>,
        period: Int = 20,
        k: Double = 2.0
    ): Triple<Double, Double, Double> {
        if (prices.size < period) {
            val avg = if (prices.isEmpty()) 0.0 else prices.average()
            return Triple(avg * 1.002, avg, avg * 0.998)
        }

        val subset = prices.takeLast(period)
        val sma = subset.average()
        val variance = subset.map { (it - sma).pow(2) }.average()
        val stdDev = sqrt(variance)

        val upper = sma + (k * stdDev)
        val lower = sma - (k * stdDev)
        return Triple(upper, sma, lower)
    }

    /** Real MACD (12, 26, 9): histogram = MACD line - EMA9(MACD line). */
    private fun calculateMacd(prices: List<Double>): Triple<Double, Double, Double> {
        if (prices.size < 35) return Triple(0.0, 0.0, 0.0)
        val k12 = 2.0 / 13.0
        val k26 = 2.0 / 27.0
        val k9 = 2.0 / 10.0
        var ema12 = prices[0]
        var ema26 = prices[0]
        var signal = 0.0
        var macd = 0.0
        for (i in 1 until prices.size) {
            ema12 = prices[i] * k12 + ema12 * (1 - k12)
            ema26 = prices[i] * k26 + ema26 * (1 - k26)
            macd = ema12 - ema26
            signal = if (i == 1) macd else macd * k9 + signal * (1 - k9)
        }
        return Triple(macd, signal, macd - signal)
    }

    private fun calculateStochastic(
        candles: List<Candle>,
        period: Int = 14,
        smoothD: Int = 3
    ): Pair<Double, Double> {
        if (candles.size < period + smoothD) return Pair(50.0, 50.0)
        val ks = ArrayList<Double>()
        for (end in (candles.size - smoothD + 1)..candles.size) {
            val window = candles.subList(end - period, end)
            val hh = window.maxOf { it.high }
            val ll = window.minOf { it.low }
            val close = window.last().close
            ks.add(if (hh != ll) ((close - ll) / (hh - ll)) * 100.0 else 50.0)
        }
        val k = ks.last().coerceIn(0.0, 100.0)
        val d = ks.average().coerceIn(0.0, 100.0)
        return Pair(k, d)
    }

    /** Neutral values while there is no real candle data yet (no made-up numbers). */
    private fun defaultIndicators(): TechnicalIndicators {
        return TechnicalIndicators(
            rsi14 = 50.0,
            ema9 = 0.0,
            ema21 = 0.0,
            bbUpper = 0.0,
            bbMiddle = 0.0,
            bbLower = 0.0,
            macdValue = 0.0,
            macdSignal = 0.0,
            macdHistogram = 0.0,
            stochasticK = 50.0,
            stochasticD = 50.0,
            bullishSentimentPercent = 50,
            volatilityLevel = "-",
            trendRecommendation = "NEUTRAL"
        )
    }
}
