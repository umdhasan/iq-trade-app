package com.example.engine

import java.util.Calendar
import java.util.Locale
import java.util.TimeZone

data class TradingSessionInfo(
    val id: String,
    val nameEn: String,
    val nameBn: String,
    val utcHours: String,
    val bstHours: String,
    val bestPairs: List<String>,
    val bestPairIds: List<String>,
    val marketBehaviorBn: String,
    val tipsAndStrategyBn: String,
    val startMinuteOfDayBst: Int,
    val endMinuteOfDayBst: Int,
    val isActive: Boolean,
    val isGoldenHour: Boolean = false
)

object MarketSessionEngine {

    fun getSessions(): List<TradingSessionInfo> {
        val nowBst = Calendar.getInstance(TimeZone.getTimeZone("GMT+6"))
        val currentMinuteOfDay = nowBst.get(Calendar.HOUR_OF_DAY) * 60 + nowBst.get(Calendar.MINUTE)

        val sydneyActive = isTimeBetween(currentMinuteOfDay, 4 * 60, 13 * 60)
        val tokyoActive = isTimeBetween(currentMinuteOfDay, 6 * 60, 15 * 60)
        val londonActive = isTimeBetween(currentMinuteOfDay, 13 * 60, 22 * 60)
        val newYorkActive = isTimeBetween(currentMinuteOfDay, 18 * 60, 3 * 60)

        return listOf(
            // 1. Sydney Session
            TradingSessionInfo(
                id = "sydney",
                nameEn = "Sydney Session",
                nameBn = "সিডনি সেশন (Sydney Session)",
                utcHours = "22:00 - 07:00 UTC",
                bstHours = "ভোর ০৪:০০ - দুপুর ০১:০০ BST",
                bestPairs = listOf("AUD/CAD", "AUD/CHF", "EUR/NZD", "AU 200"),
                bestPairIds = listOf("blitz_aud_cad", "blitz_aud_chf", "blitz_eur_nzd", "blitz_au_200"),
                marketBehaviorBn = "মার্কেট তুলনামূলক শান্ত ও স্থিতিশীল থাকে। বিশ্ব ট্রেডিং দিবসের সূচনা হয় এই সেশন দিয়ে। হঠাৎ বড় ধরনের স্পাইক কম দেখা যায়, ফলে টেকনিক্যাল বাউন্স অত্যন্ত কার্যকরী হয়।",
                tipsAndStrategyBn = "অস্ট্রেলীয় (AUD) এবং নিউজিল্যান্ড (NZD) পেয়ারগুলোতে সাপোর্ট ও রেজিস্ট্যান্স লেভেল রেঞ্জ বাউন্সের জন্য সেরা সময়। ১ মিনিট ও ৫ মিনিট টার্বো অপশনে ওভারসোল্ড ও ওভারবট রিভার্সাল কৌশল ব্যবহার করুন।",
                startMinuteOfDayBst = 4 * 60,
                endMinuteOfDayBst = 13 * 60,
                isActive = sydneyActive
            ),

            // 2. Tokyo Session
            TradingSessionInfo(
                id = "tokyo",
                nameEn = "Tokyo Session",
                nameBn = "টোকিও সেশন (Tokyo Session)",
                utcHours = "00:00 - 09:00 UTC",
                bstHours = "সকাল ০৬:০০ - বিকেল ০৩:০০ BST",
                bestPairs = listOf("EUR/JPY", "JP 225", "AUD/CAD"),
                bestPairIds = listOf("blitz_eur_jpy", "blitz_jp_225", "blitz_aud_cad"),
                marketBehaviorBn = "জাপানিজ ব্যাংক ও এশিয়ান করপোরেশনের লেনদেনের কারণে JPY ক্রস পেয়ারে ধারাবাহিক ফ্লো তৈরি হয়। ইউরোপীয় সেশনের আগে প্রাথমিক দিকনির্দেশনা স্পষ্ট হয়।",
                tipsAndStrategyBn = "এশিয়ান সেশনের ভোলাটিলিটি কাজে লাগাতে EUR/JPY এবং JPN225 পেয়ারে নজর রাখুন। ব্রেকআউটের আগে কনসলিডেশন জোন তৈরি হলে ৫ মিনিটের বুলিশ/বিয়ারিশ ডিরেকশনে সিগন্যাল গ্রহণ করা বেশি নিরাপদ।",
                startMinuteOfDayBst = 6 * 60,
                endMinuteOfDayBst = 15 * 60,
                isActive = tokyoActive
            ),

            // 3. London Session
            TradingSessionInfo(
                id = "london",
                nameEn = "London Session",
                nameBn = "লন্ডন সেশন (London Session)",
                utcHours = "07:00 - 16:00 UTC",
                bstHours = "দুপুর ০১:০০ - রাত ১০:০০ BST",
                bestPairs = listOf("EUR/GBP", "EUR/CHF", "UK 100", "GER 30"),
                bestPairIds = listOf("blitz_eur_gbp", "blitz_eur_chf", "blitz_uk_100", "blitz_ger_30"),
                marketBehaviorBn = "বিশ্ব ফরেক্স ট্রেডিংয়ের একক বৃহত্তম তারল্য (High Liquidity) এবং আগ্রাসী মুভমেন্টের মূল কেন্দ্র। ট্রেন্ডের গতি বৃদ্ধি পায় এবং শক্তিশালী ব্রেকআউট দেখা যায়।",
                tipsAndStrategyBn = "ইউরোপীয় পেয়ারগুলোতে ট্রেন্ড কন্টিনিউয়েশন ও ভলিউম এক্সপেনশনে কাজ করুন। ভুয়া ব্রেকআউট এড়িয়ে ইএমএ ৯ ও ২১ এর ক্রসওভার দেখে IQ Option-এ ১ মিনিট বা ২ মিনিটের ডিরেকশনাল কল/পুট এন্ট্রি নিন।",
                startMinuteOfDayBst = 13 * 60,
                endMinuteOfDayBst = 22 * 60,
                isActive = londonActive,
                isGoldenHour = false
            ),

            // 4. New York Session
            TradingSessionInfo(
                id = "new_york",
                nameEn = "New York Session",
                nameBn = "নিউ ইয়র্ক সেশন (New York Session)",
                utcHours = "12:00 - 21:00 UTC",
                bstHours = "সন্ধ্যা ০৬:০০ - রাত ০৩:০০ BST",
                bestPairs = listOf("CAD/CHF", "US 100", "US 500", "Crude Oil WTI", "Gold"),
                bestPairIds = listOf("blitz_cad_chf", "blitz_us_100", "blitz_us_500", "blitz_crude_oil_wti", "blitz_gold"),
                marketBehaviorBn = "লন্ডন সেশনের সাথে সন্ধ্যা ০৬:০০ থেকে রাত ১০:০০ পর্যন্ত গোল্ডেন ওভারল্যাপ ঘটে। এটি দিনের সর্বোচ্চ ভোলাটাইল ও সবচেয়ে বেশি ট্রেড হওয়া সময়। ইউএস অর্থনৈতিক খবর ও টেক সূচকের ব্যাপক প্রভাব থাকে।",
                tipsAndStrategyBn = "মেজর হাই-ইমপ্যাক্ট নিউজ রিলিজের সময় অতিরিক্ত সতর্ক থাকুন। গোল্ডেন ওভারল্যাপ চলাকালীন US100, গোল্ড এবং ওয়েল পেয়ারে সুইং মোমেন্টাম ট্রেড করে দ্রুত প্রফিট লক করুন।",
                startMinuteOfDayBst = 18 * 60,
                endMinuteOfDayBst = 3 * 60,
                isActive = newYorkActive,
                isGoldenHour = true
            )
        )
    }

    fun getCurrentBstFormatted(): String {
        val nowBst = Calendar.getInstance(TimeZone.getTimeZone("GMT+6"))
        val hour = nowBst.get(Calendar.HOUR_OF_DAY)
        val minute = nowBst.get(Calendar.MINUTE)
        val amPm = if (hour >= 12) "PM" else "AM"
        val hour12 = if (hour % 12 == 0) 12 else hour % 12
        return String.format(Locale.US, "%02d:%02d %s BST", hour12, minute, amPm)
    }

    private fun isTimeBetween(current: Int, start: Int, end: Int): Boolean {
        return if (start <= end) {
            current in start until end
        } else {
            current >= start || current < end
        }
    }
}
