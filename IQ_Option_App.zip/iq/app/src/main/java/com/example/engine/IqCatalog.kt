package com.example.engine

import com.example.model.FeedRef
import com.example.model.FeedSource
import com.example.model.MarketCategory
import com.example.model.MarketType
import com.example.model.TradingAsset
import kotlin.math.abs

/**
 * IQ Option asset catalogue for the four market lists (Digital, Binary, Forex/Margin CFD, Blitz).
 *
 * Every asset points to a REAL price source (Binance for crypto, Yahoo Finance for everything else,
 * or a derived ratio of two real prices). IQ Option's own OTC quotes and some synthetic baskets
 * ("Euro Index", "Luxury", ...) are generated inside IQ Option and have no public feed:
 *  - OTC assets are mapped to the real underlying market (price is a reference, flagged isOtc).
 *  - Pure synthetic baskets get FeedSource.NONE and show "no public feed".
 */
object IqCatalog {

    private val CURRENCY_NAMES = mapOf(
        "EUR" to "Euro", "USD" to "US Dollar", "GBP" to "British Pound", "JPY" to "Japanese Yen",
        "CHF" to "Swiss Franc", "CAD" to "Canadian Dollar", "AUD" to "Australian Dollar",
        "NZD" to "New Zealand Dollar", "SGD" to "Singapore Dollar", "HKD" to "Hong Kong Dollar",
        "MXN" to "Mexican Peso", "ZAR" to "South African Rand", "NOK" to "Norwegian Krone",
        "SEK" to "Swedish Krona", "DKK" to "Danish Krone", "TRY" to "Turkish Lira",
        "THB" to "Thai Baht", "PLN" to "Polish Zloty", "CZK" to "Czech Koruna",
        "HUF" to "Hungarian Forint", "CNH" to "Chinese Yuan", "BRL" to "Brazilian Real",
        "INR" to "Indian Rupee", "IDR" to "Indonesian Rupiah", "COP" to "Colombian Peso",
        "AED" to "UAE Dirham", "RUB" to "Russian Ruble", "KRW" to "Korean Won", "ILS" to "Israeli Shekel"
    )

    // ---- real forex pairs (Yahoo Finance: XXXYYY=X) ----
    private val FX_CORE = listOf(
        "EUR/USD", "GBP/USD", "USD/JPY", "USD/CHF", "USD/CAD", "AUD/USD", "NZD/USD",
        "EUR/GBP", "EUR/JPY", "EUR/CHF", "EUR/AUD", "EUR/CAD", "EUR/NZD",
        "GBP/JPY", "GBP/CHF", "GBP/AUD", "GBP/CAD", "GBP/NZD",
        "AUD/JPY", "AUD/CHF", "AUD/CAD", "AUD/NZD",
        "CAD/JPY", "CAD/CHF", "CHF/JPY", "NZD/JPY", "NZD/CAD", "NZD/CHF"
    )
    private val FX_EXOTIC = listOf(
        "USD/SGD", "USD/HKD", "USD/MXN", "USD/ZAR", "USD/NOK", "USD/SEK", "USD/DKK", "USD/TRY",
        "USD/THB", "USD/PLN", "USD/CZK", "USD/HUF", "USD/CNH", "EUR/NOK", "EUR/SEK", "EUR/TRY",
        "EUR/THB", "EUR/ZAR", "EUR/PLN", "EUR/HUF", "CHF/NOK", "CHF/SGD", "USD/BRL", "USD/INR"
    )
    private val FX_OTC_ONLY = listOf(
        "USD/COP", "USD/AED", "USD/IDR", "USD/HKD", "USD/INR", "USD/ZAR", "USD/BRL", "USD/PLN",
        "USD/CZK", "USD/KRW"
    )

    // ---- crypto: ticker -> display name (Binance <TICKER>USDT) ----
    private val CRYPTO_MAJOR = listOf(
        "BTC" to "Bitcoin", "ETH" to "Ethereum", "BNB" to "BNB", "SOL" to "Solana", "XRP" to "Ripple",
        "ADA" to "Cardano", "DOGE" to "Dogecoin", "LTC" to "Litecoin", "DOT" to "Polkadot",
        "AVAX" to "Avalanche", "LINK" to "Chainlink", "TRX" to "Tron", "TON" to "Toncoin",
        "POL" to "Polygon", "BCH" to "Bitcoin Cash", "ATOM" to "Cosmos", "NEAR" to "NEAR Protocol",
        "SHIB" to "Shiba Inu", "AAVE" to "AAVE", "UNI" to "Uniswap"
    )
    private val CRYPTO_ALT = listOf(
        "SUI" to "Sui", "HBAR" to "Hedera", "FET" to "Fetch.ai", "RENDER" to "Render", "TAO" to "Bittensor",
        "ONDO" to "Ondo", "DYDX" to "DYDX", "INJ" to "Injective", "ARB" to "Arbitrum", "APT" to "Aptos",
        "PEPE" to "Pepe", "ICP" to "Internet Computer", "ORDI" to "ORDI", "STX" to "Stacks",
        "IOTA" to "IOTA", "KAS" to "Kaspa", "FIL" to "Filecoin", "AXS" to "Axie Infinity",
        "TRUMP" to "TRUMP Coin", "PENGU" to "Pudgy Penguins", "RAY" to "Raydium", "XLM" to "Stellar",
        "ETC" to "Ethereum Classic", "OP" to "Optimism", "SAND" to "Sandbox", "WLD" to "Worldcoin"
    )

    // ---- US / global stocks: Yahoo symbol -> display name ----
    private val STOCKS_US = listOf(
        "AAPL" to "Apple", "MSFT" to "Microsoft", "GOOGL" to "Alphabet (Google)", "AMZN" to "Amazon",
        "META" to "Meta (Facebook)", "TSLA" to "Tesla", "NVDA" to "NVIDIA", "NFLX" to "Netflix",
        "AMD" to "AMD", "INTC" to "Intel", "BABA" to "Alibaba", "BA" to "Boeing", "JPM" to "JPMorgan",
        "KO" to "Coca-Cola", "MCD" to "McDonald's", "DIS" to "Disney", "NKE" to "Nike", "V" to "Visa",
        "MA" to "Mastercard", "PYPL" to "PayPal", "UBER" to "Uber", "COIN" to "Coinbase",
        "GME" to "GameStop", "XOM" to "ExxonMobil", "CVX" to "Chevron", "WMT" to "Walmart",
        "PFE" to "Pfizer", "JNJ" to "Johnson & Johnson", "CSCO" to "Cisco", "ORCL" to "Oracle",
        "IBM" to "IBM", "AXP" to "American Express", "GS" to "Goldman Sachs", "MS" to "Morgan Stanley",
        "C" to "Citigroup", "BAC" to "Bank of America", "T" to "AT&T", "VZ" to "Verizon",
        "PEP" to "PepsiCo", "SBUX" to "Starbucks", "ADBE" to "Adobe", "CRM" to "Salesforce",
        "QCOM" to "Qualcomm", "TSM" to "TSMC", "SNAP" to "Snapchat", "SHOP" to "Shopify", "MRNA" to "Moderna",
        "F" to "Ford", "GM" to "General Motors", "FWONK" to "Formula One Group", "PLTR" to "Palantir",
        "BIDU" to "Baidu", "JD" to "JD.com", "NIO" to "NIO", "ABNB" to "Airbnb"
    )
    private val STOCKS_GLOBAL = listOf(
        "ADS.DE" to "Adidas AG", "VOW3.DE" to "Volkswagen AG", "SAP.DE" to "SAP", "SIE.DE" to "Siemens",
        "HEIA.AS" to "Heineken NV", "ASML.AS" to "ASML Holding NV", "TIT.MI" to "Telecom Italia",
        "NEXI.MI" to "Nexi SpA", "SRG.MI" to "Snam SpA", "0992.HK" to "Lenovo Group",
        "1810.HK" to "Xiaomi Corp", "3690.HK" to "Meituan Class B", "3988.HK" to "Bank of China",
        "1288.HK" to "Agricultural Bank of China", "9868.HK" to "Xpeng", "005930.KS" to "Samsung",
        "7203.T" to "Toyota", "MC.PA" to "LVMH", "OR.PA" to "L'Oreal", "AIR.PA" to "Airbus"
    )
    private val ETFS = listOf(
        "SPY" to "S&P 500 ETF", "IWM" to "iShares Russell 2000 ETF", "GDX" to "Gold Miners ETF",
        "XLK" to "Technology SPDR", "XLE" to "Energy SPDR", "QQQ" to "Nasdaq 100 ETF (QQQ)",
        "XLF" to "Financial SPDR", "EEM" to "Emerging Markets ETF"
    )

    // ---- indices: display -> Yahoo ----
    private val INDICES_CORE = listOf(
        Triple("US 500", "^GSPC", "S&P 500"), Triple("US 100", "^NDX", "Nasdaq 100"),
        Triple("US 30", "^DJI", "Dow Jones 30"), Triple("US 2000", "^RUT", "Russell 2000"),
        Triple("UK 100", "^FTSE", "FTSE 100"), Triple("GER 30", "^GDAXI", "DAX 40"),
        Triple("FR 40", "^FCHI", "CAC 40"), Triple("AU 200", "^AXJO", "ASX 200"),
        Triple("JP 225", "^N225", "Nikkei 225"), Triple("HK 33", "^HSI", "Hang Seng"),
        Triple("ES 35", "^IBEX", "IBEX 35"), Triple("EU 50", "^STOXX50E", "Euro Stoxx 50")
    )

    // ---- commodities: display -> (Yahoo symbol, name) ----
    private val COMMODITIES_CORE = listOf(
        Triple("Gold", "XAUUSD=X", "Gold Spot (XAU/USD)"),
        Triple("Silver", "XAGUSD=X", "Silver Spot (XAG/USD)"),
        Triple("Crude Oil WTI", "CL=F", "WTI Crude Oil"),
        Triple("Crude Oil Brent", "BZ=F", "Brent Crude Oil"),
        Triple("Natural Gas", "NG=F", "Natural Gas"),
        Triple("Platinum", "PL=F", "Platinum"),
        Triple("Palladium", "PA=F", "Palladium"),
        Triple("Copper", "HG=F", "Copper")
    )
    private val COMMODITIES_SOFT = listOf(
        Triple("Cocoa", "CC=F", "Cocoa"), Triple("Coffee", "KC=F", "Coffee"),
        Triple("Cotton", "CT=F", "Cotton"), Triple("Sugar", "SB=F", "Sugar"),
        Triple("Corn", "ZC=F", "Corn"), Triple("Wheat", "ZW=F", "Wheat"), Triple("Soybean", "ZS=F", "Soybean")
    )

    private const val XAU = "Y:XAUUSD=X"
    private const val XAG = "Y:XAGUSD=X"
    private const val BTC = "B:BTCUSDT"

    private fun yahoo(sym: String) = FeedRef(FeedSource.YAHOO, sym)
    private fun binance(ticker: String) = FeedRef(FeedSource.BINANCE, "${ticker}USDT")
    private fun none(sym: String) = FeedRef(FeedSource.NONE, sym)
    private fun ratio(num: String, den: String) =
        FeedRef(FeedSource.DERIVED, numeratorKey = num, denominatorKey = den, multiply = false)
    private fun product(a: String, b: String) =
        FeedRef(FeedSource.DERIVED, numeratorKey = a, denominatorKey = b, multiply = true)
    private fun fxKey(pair: String) = "Y:${pair.replace("/", "")}=X"

    private class Builder(val market: MarketType, private val payoutBase: Int, private val otcPayoutBase: Int) {
        val out = mutableListOf<TradingAsset>()
        private val seen = HashSet<String>()

        private fun payoutFor(symbol: String, otc: Boolean): Int {
            if (payoutBase == 0) return 0 // Margin CFD has no fixed payout
            val base = if (otc) otcPayoutBase else payoutBase
            return base + (abs(symbol.hashCode()) % 4) - 1
        }

        fun add(
            symbol: String,
            name: String,
            cat: MarketCategory,
            feed: FeedRef,
            otc: Boolean = false
        ) {
            val shownSymbol = if (otc) "$symbol (OTC)" else symbol
            val id = market.name.lowercase() + "_" +
                shownSymbol.lowercase().replace(Regex("[^a-z0-9]+"), "_").trim('_')
            if (!seen.add(id)) return
            out.add(
                TradingAsset(
                    id = id,
                    symbol = shownSymbol,
                    name = if (otc) "$name (OTC)" else name,
                    category = cat,
                    marketType = market,
                    feed = feed,
                    payoutPercent = payoutFor(shownSymbol, otc),
                    isOtc = otc,
                    priceDecimals = 5
                )
            )
        }

        fun fx(pair: String, otc: Boolean = false) {
            val (a, b) = pair.split("/")
            val name = "${CURRENCY_NAMES[a] ?: a} / ${CURRENCY_NAMES[b] ?: b}"
            add(pair, name, MarketCategory.CURRENCIES, FeedRef(FeedSource.YAHOO, "$a$b=X"), otc)
        }

        fun crypto(list: List<Pair<String, String>>, otc: Boolean = false) {
            list.forEach { (t, n) -> add(n, "$n / USDT", MarketCategory.CRYPTO, binance(t), otc) }
        }

        fun stocks(list: List<Pair<String, String>>, otc: Boolean = false) {
            list.forEach { (s, n) -> add(n, n, MarketCategory.STOCKS, FeedRef(FeedSource.YAHOO, s), otc) }
        }

        fun indices(list: List<Triple<String, String, String>>) {
            list.forEach { (d, s, n) -> add(d, n, MarketCategory.INDICES, FeedRef(FeedSource.YAHOO, s)) }
        }

        fun commodities(list: List<Triple<String, String, String>>, otc: Boolean = false) {
            list.forEach { (d, s, n) -> add(d, n, MarketCategory.COMMODITIES, FeedRef(FeedSource.YAHOO, s), otc) }
        }
    }

    fun build(): List<TradingAsset> {
        val all = mutableListOf<TradingAsset>()
        all += buildBlitz()
        all += buildBinary()
        all += buildDigital()
        all += buildForex()
        return all
    }

    // ------------------------------------------------------------------ BLITZ
    private fun buildBlitz(): List<TradingAsset> {
        val b = Builder(MarketType.BLITZ, 87, 84)
        FX_CORE.forEach { b.fx(it) }
        listOf("USD/SGD", "USD/MXN", "USD/NOK", "USD/SEK", "USD/TRY", "USD/THB", "EUR/THB", "CHF/NOK",
            "USD/HKD", "USD/ZAR", "EUR/NOK", "EUR/SEK", "USD/PLN", "USD/BRL").forEach { b.fx(it) }
        listOf("USD/BRL", "USD/ZAR", "USD/INR", "USD/IDR", "USD/COP").forEach { b.fx(it, otc = true) }
        b.add("Dollar Index", "US Dollar Index", MarketCategory.CURRENCIES, yahoo("DX-Y.NYB"))
        b.indices(INDICES_CORE.filter { it.first in setOf("US 500", "US 100", "US 30", "US 2000", "UK 100", "GER 30", "FR 40", "AU 200", "JP 225") })
        b.commodities(COMMODITIES_CORE.filter { it.first in setOf("Gold", "Silver", "Crude Oil WTI", "Crude Oil Brent") })
        b.crypto(CRYPTO_MAJOR.take(2))
        b.add("Gold/Silver", "Gold / Silver ratio", MarketCategory.COMMODITIES, ratio(XAU, XAG))
        b.add("Bitcoin/Gold", "Bitcoin / Gold ratio", MarketCategory.CRYPTO, ratio(BTC, XAU))
        b.add("S&P500/Gold", "S&P 500 / Gold ratio", MarketCategory.INDICES, ratio("Y:^GSPC", XAU))
        b.stocks(STOCKS_US.take(15))
        return b.out
    }

    // ----------------------------------------------------------------- BINARY
    private fun buildBinary(): List<TradingAsset> {
        val b = Builder(MarketType.BINARY, 87, 83)
        FX_CORE.forEach { b.fx(it) }
        listOf("USD/SGD", "USD/MXN", "USD/NOK", "USD/SEK", "USD/DKK", "USD/TRY", "USD/THB", "USD/PLN",
            "USD/CZK", "USD/HUF", "EUR/NOK", "EUR/SEK", "EUR/THB", "EUR/ZAR", "CHF/NOK", "USD/HKD",
            "USD/ZAR", "USD/BRL", "USD/INR", "USD/CNH").forEach { b.fx(it) }
        FX_OTC_ONLY.forEach { b.fx(it, otc = true) }
        // IQ "currency index" baskets
        b.add("Dollar Index", "US Dollar Index", MarketCategory.CURRENCIES, yahoo("DX-Y.NYB"))
        listOf("Euro Index", "Yen Index", "Pound Index", "Canadian Dollar Index", "Australian Dollar Index")
            .forEach { b.add(it, "$it (IQ basket, no public feed)", MarketCategory.CURRENCIES, none(it)) }
        b.indices(INDICES_CORE)
        b.commodities(COMMODITIES_CORE)
        b.commodities(COMMODITIES_SOFT, otc = true)
        b.crypto(CRYPTO_MAJOR.take(10))
        b.crypto(CRYPTO_ALT, otc = true)
        b.add("Gold/Silver", "Gold / Silver ratio", MarketCategory.COMMODITIES, ratio(XAU, XAG))
        b.add("Bitcoin/Gold", "Bitcoin / Gold ratio", MarketCategory.CRYPTO, ratio(BTC, XAU))
        b.add("S&P500/Gold", "S&P 500 / Gold ratio", MarketCategory.INDICES, ratio("Y:^GSPC", XAU))
        b.add("Gold/BRL", "Gold / Brazilian Real", MarketCategory.COMMODITIES, product(XAU, fxKey("USD/BRL")))
        b.add("Crude Oil Brent/BRL", "Brent / Brazilian Real", MarketCategory.COMMODITIES, product("Y:BZ=F", fxKey("USD/BRL")))
        b.add("Uranium", "Uranium (no public spot feed)", MarketCategory.COMMODITIES, none("Uranium"), otc = true)
        b.add("Luxury", "Luxury basket (IQ, no public feed)", MarketCategory.STOCKS, none("Luxury"))
        b.stocks(STOCKS_US.take(27))
        b.stocks(ETFS)
        return b.out
    }

    // ---------------------------------------------------------------- DIGITAL
    private fun buildDigital(): List<TradingAsset> {
        val b = Builder(MarketType.DIGITAL, 86, 82)
        FX_CORE.forEach { b.fx(it) }
        listOf("USD/SGD", "USD/MXN", "USD/NOK", "USD/SEK", "USD/TRY", "USD/THB", "USD/ZAR",
            "USD/PLN", "EUR/NOK", "EUR/SEK", "CHF/NOK", "USD/HKD").forEach { b.fx(it) }
        listOf("USD/BRL", "USD/INR", "USD/IDR", "USD/COP", "USD/AED").forEach { b.fx(it, otc = true) }
        b.add("Dollar Index", "US Dollar Index", MarketCategory.CURRENCIES, yahoo("DX-Y.NYB"))
        b.indices(INDICES_CORE)
        b.commodities(COMMODITIES_CORE)
        b.crypto(CRYPTO_MAJOR.take(12))
        b.add("Gold/Silver", "Gold / Silver ratio", MarketCategory.COMMODITIES, ratio(XAU, XAG))
        b.add("Bitcoin/Gold", "Bitcoin / Gold ratio", MarketCategory.CRYPTO, ratio(BTC, XAU))
        b.stocks(STOCKS_US.take(30))
        b.stocks(ETFS.take(4))
        return b.out
    }

    // ------------------------------------------------------ FOREX (Margin CFD)
    private fun buildForex(): List<TradingAsset> {
        val b = Builder(MarketType.FOREX, 0, 0)
        FX_CORE.forEach { b.fx(it) }
        FX_EXOTIC.forEach { b.fx(it) }
        b.add("Dollar Index", "US Dollar Index", MarketCategory.CURRENCIES, yahoo("DX-Y.NYB"))
        listOf("Euro Index", "Yen Index", "Pound Index", "Canadian Dollar Index", "Australian Dollar Index")
            .forEach { b.add(it, "$it (IQ basket, no public feed)", MarketCategory.CURRENCIES, none(it)) }
        b.indices(INDICES_CORE)
        b.commodities(COMMODITIES_CORE)
        b.commodities(COMMODITIES_SOFT)
        b.crypto(CRYPTO_MAJOR)
        b.crypto(CRYPTO_ALT)
        b.add("Gold/Silver", "Gold / Silver ratio", MarketCategory.COMMODITIES, ratio(XAU, XAG))
        b.add("Gold/EUR", "Gold / Euro", MarketCategory.COMMODITIES, ratio(XAU, fxKey("EUR/USD")))
        b.add("Gold/GBP", "Gold / British Pound", MarketCategory.COMMODITIES, ratio(XAU, fxKey("GBP/USD")))
        b.add("Gold/THB", "Gold / Thai Baht", MarketCategory.COMMODITIES, product(XAU, fxKey("USD/THB")))
        b.add("Gold/BRL", "Gold / Brazilian Real", MarketCategory.COMMODITIES, product(XAU, fxKey("USD/BRL")))
        b.add("Bitcoin/Gold", "Bitcoin / Gold ratio", MarketCategory.CRYPTO, ratio(BTC, XAU))
        b.add("US30/JP225", "Dow Jones / Nikkei ratio", MarketCategory.INDICES, ratio("Y:^DJI", "Y:^N225"))
        b.add("XAG/EUR", "Silver / Euro", MarketCategory.COMMODITIES, ratio(XAG, fxKey("EUR/USD")))
        b.stocks(STOCKS_US)
        b.stocks(STOCKS_GLOBAL)
        b.stocks(ETFS)
        return b.out
    }
}
