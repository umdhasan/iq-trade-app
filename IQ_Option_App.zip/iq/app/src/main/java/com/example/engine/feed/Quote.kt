package com.example.engine.feed

/** One real market quote coming from a public price feed. */
data class Quote(
    val price: Double,
    /** previous distinct price (for the up/down colour) */
    val prevPrice: Double,
    /** reference price for the daily % change (previous close / 24h open) */
    val refClose: Double,
    val dayHigh: Double,
    val dayLow: Double,
    /** time of the last trade as reported by the exchange/data vendor */
    val marketTimeMs: Long,
    /** local time when we received it */
    val receivedMs: Long
)

/** A raw price tick used to build the sub-minute (5s / 15s / 30s) candles. */
data class PriceTick(val timeMs: Long, val price: Double)
