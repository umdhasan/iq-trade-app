package com.example.engine

import com.example.model.Candle
import kotlin.math.abs

/**
 * Exact Kotlin port of the "Hasan Pro Signal" indicator (Hasan_Trade_V1):
 *
 *   fast = WMA(close, 2)        slow = EMA(close, 21)        r = RSI(close, 21)
 *   strong_green / strong_red : body >= 60 % of the range and a close within 25 % of the high / low
 *   UP?   : fast > slow, fast rising, close > fast, RSI > 52
 *   DOWN? : fast < slow, fast falling, close < fast, RSI < 48
 *   UP+   : UP?  + slow not falling + RSI > 58 + strong green candle
 *   DOWN+ : DOWN?+ slow not rising  + RSI < 42 + strong red candle
 */
object HasanProSignal {

    const val NONE = 0
    const val UP_POSSIBLE = 1
    const val UP_PLUS = 2
    const val DOWN_POSSIBLE = -1
    const val DOWN_PLUS = -2

    class Series(
        val fast: DoubleArray,
        val slow: DoubleArray,
        val rsi: DoubleArray,
        /** signal code per candle: NONE / UP_POSSIBLE / UP_PLUS / DOWN_POSSIBLE / DOWN_PLUS */
        val signal: IntArray
    ) {
        val size: Int get() = signal.size

        /** Last [n] bars of every array (used to draw only the visible part of the chart). */
        fun takeLast(n: Int): Series {
            val from = (size - n).coerceAtLeast(0)
            return Series(
                fast.copyOfRange(from, size),
                slow.copyOfRange(from, size),
                rsi.copyOfRange(from, size),
                signal.copyOfRange(from, size)
            )
        }
    }

    /** Result for one candle (usually the last CLOSED candle). */
    data class State(
        val code: Int,
        val label: String,
        val rsi: Double,
        val fast: Double,
        val slow: Double,
        /** 0..100 rule-based setup strength (NOT a win probability) */
        val strength: Int,
        val candleIndex: Int
    ) {
        val isUp: Boolean get() = code > 0
        val isDown: Boolean get() = code < 0
        val isStrong: Boolean get() = abs(code) == 2
        val hasSignal: Boolean get() = code != NONE
    }

    fun labelOf(code: Int): String = when (code) {
        UP_PLUS -> "UP+"
        UP_POSSIBLE -> "UP?"
        DOWN_PLUS -> "DOWN+"
        DOWN_POSSIBLE -> "DOWN?"
        else -> "WAIT"
    }

    fun compute(candles: List<Candle>): Series {
        val n = candles.size
        val fast = DoubleArray(n)
        val slow = DoubleArray(n)
        val rsi = DoubleArray(n)
        val sig = IntArray(n)
        if (n == 0) return Series(fast, slow, rsi, sig)

        val close = DoubleArray(n) { candles[it].close }

        // WMA(2): weights 1 (older) and 2 (newer)
        for (i in 0 until n) {
            fast[i] = if (i == 0) close[0] else (close[i - 1] * 1.0 + close[i] * 2.0) / 3.0
        }
        // EMA(21)
        val k = 2.0 / (21.0 + 1.0)
        slow[0] = close[0]
        for (i in 1 until n) slow[i] = close[i] * k + slow[i - 1] * (1.0 - k)
        // RSI(21) with Wilder smoothing
        val p = 21
        var avgGain = 0.0
        var avgLoss = 0.0
        for (i in 0 until n) {
            if (i == 0) { rsi[i] = 50.0; continue }
            val d = close[i] - close[i - 1]
            val g = if (d > 0) d else 0.0
            val l = if (d < 0) -d else 0.0
            if (i <= p) {
                avgGain += g / p
                avgLoss += l / p
                rsi[i] = if (i < p) 50.0 else rsiFrom(avgGain, avgLoss)
            } else {
                avgGain = (avgGain * (p - 1) + g) / p
                avgLoss = (avgLoss * (p - 1) + l) / p
                rsi[i] = rsiFrom(avgGain, avgLoss)
            }
        }

        for (i in 1 until n) {
            val c = candles[i]
            val range = c.high - c.low
            val body = abs(c.close - c.open)
            val strongGreen = c.close > c.open && range > 0 &&
                body / range >= 0.60 && (c.high - c.close) / range <= 0.25
            val strongRed = c.close < c.open && range > 0 &&
                body / range >= 0.60 && (c.close - c.low) / range <= 0.25

            val r = rsi[i]
            val upPossible = fast[i] > slow[i] && fast[i] > fast[i - 1] && c.close > fast[i] && r > 52
            val downPossible = fast[i] < slow[i] && fast[i] < fast[i - 1] && c.close < fast[i] && r < 48
            val upStrong = upPossible && slow[i] >= slow[i - 1] && r > 58 && strongGreen
            val downStrong = downPossible && slow[i] <= slow[i - 1] && r < 42 && strongRed

            sig[i] = when {
                upStrong -> UP_PLUS
                downStrong -> DOWN_PLUS
                upPossible -> UP_POSSIBLE
                downPossible -> DOWN_POSSIBLE
                else -> NONE
            }
        }
        return Series(fast, slow, rsi, sig)
    }

    /**
     * State of one candle. [index] < 0 means "last candle". Warm-up: at least 40 candles are needed
     * for EMA(21)/RSI(21) to be meaningful, otherwise the state is WAIT.
     */
    fun stateAt(candles: List<Candle>, series: Series, index: Int = -1): State {
        val n = candles.size
        val i = if (index < 0) n - 1 else index
        if (n < 40 || i < 1 || i >= n) {
            return State(NONE, "WAIT", 50.0, 0.0, 0.0, 0, i)
        }
        val code = series.signal[i]
        val c = candles[i]
        val range = c.high - c.low
        val bodyRatio = if (range > 0) abs(c.close - c.open) / range else 0.0
        var strength = when (abs(code)) {
            2 -> 70
            1 -> 45
            else -> 0
        }
        if (code != NONE) {
            val r = series.rsi[i]
            val rsiPush = if (code > 0) (r - 50.0) else (50.0 - r)
            strength += (rsiPush.coerceIn(0.0, 25.0)).toInt()          // up to +25
            strength += (bodyRatio * 5.0).toInt()                      // up to +5
            strength = strength.coerceIn(0, 100)
        }
        return State(code, labelOf(code), series.rsi[i], series.fast[i], series.slow[i], strength, i)
    }

    /** Last CLOSED candle (the forming candle repaints, so signals use the candle before it). */
    fun lastClosed(candles: List<Candle>): State {
        if (candles.size < 2) return State(NONE, "WAIT", 50.0, 0.0, 0.0, 0, -1)
        val series = compute(candles)
        return stateAt(candles, series, candles.size - 2)
    }

    private fun rsiFrom(avgGain: Double, avgLoss: Double): Double {
        if (avgLoss == 0.0) return if (avgGain == 0.0) 50.0 else 100.0
        val rs = avgGain / avgLoss
        return 100.0 - 100.0 / (1.0 + rs)
    }
}
