package com.example.engine

import com.example.database.AlertDao
import com.example.database.AlertNotificationEntity
import com.example.database.AlertRuleEntity
import com.example.model.AlertNotification
import com.example.model.AlertRule
import com.example.model.AlertType
import com.example.model.ExpiryTime
import com.example.model.MarketPlatform
import com.example.model.TradingAsset
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.Locale
import java.util.UUID

class AlertEngine(
    private val scope: CoroutineScope,
    private val alertDao: AlertDao,
    private val marketEngine: MarketEngine,
    private val soundManager: AlertSoundManager
) {

    private val _isAutoScannerActive = MutableStateFlow<Boolean>(true)
    val isAutoScannerActive: StateFlow<Boolean> = _isAutoScannerActive.asStateFlow()

    private val _minConfidenceThreshold = MutableStateFlow<Int>(80)
    val minConfidenceThreshold: StateFlow<Int> = _minConfidenceThreshold.asStateFlow()

    // Sound & Vibration toggles - Default OFF
    private val _soundEnabled = MutableStateFlow<Boolean>(false)
    val soundEnabled: StateFlow<Boolean> = _soundEnabled.asStateFlow()

    private val _vibrationEnabled = MutableStateFlow<Boolean>(false)
    val vibrationEnabled: StateFlow<Boolean> = _vibrationEnabled.asStateFlow()

    private val _latestAlert = MutableStateFlow<AlertNotification?>(null)
    val latestAlert: StateFlow<AlertNotification?> = _latestAlert.asStateFlow()

    private val _customRules = MutableStateFlow<List<AlertRuleEntity>>(emptyList())
    val customRules: StateFlow<List<AlertRuleEntity>> = _customRules.asStateFlow()

    private val lastTriggeredCache = mutableMapOf<String, Long>()

    init {
        // Collect custom rules from database
        scope.launch(Dispatchers.IO) {
            alertDao.getAllRules().collect { rules ->
                _customRules.value = rules
                marketEngine.setAlertAssets(rules.filter { it.isEnabled }.map { it.assetId }.toSet())
            }
        }
        startScannerLoop()
        startCustomPriceAlertMonitor()
    }

    fun setAutoScannerActive(active: Boolean) {
        _isAutoScannerActive.value = active
    }

    fun setMinConfidenceThreshold(threshold: Int) {
        _minConfidenceThreshold.value = threshold
    }

    fun setSoundEnabled(enabled: Boolean) {
        _soundEnabled.value = enabled
    }

    fun setVibrationEnabled(enabled: Boolean) {
        _vibrationEnabled.value = enabled
    }

    fun dismissLatestAlert() {
        _latestAlert.value = null
    }

    /**
     * High-frequency monitor checking custom price alert thresholds against live market feed data.
     */
    private fun startCustomPriceAlertMonitor() {
        scope.launch(Dispatchers.Default) {
            while (true) {
                delay(650L) // Synchronized with live price tick frequency
                val activeRules = _customRules.value.filter { it.isEnabled }
                if (activeRules.isEmpty()) continue

                val assets = marketEngine.assets.value
                val assetMap = assets.associateBy { it.id }
                val now = System.currentTimeMillis()

                for (rule in activeRules) {
                    val asset = assetMap[rule.assetId] ?: assets.firstOrNull { it.symbol == rule.assetSymbol }
                    if (asset != null && asset.hasPrice) {
                        val currentPrice = asset.currentPrice
                        val target = rule.targetValue
                        val isAbove = rule.alertType.contains("ABOVE", ignoreCase = true)
                        val isBelow = rule.alertType.contains("BELOW", ignoreCase = true)

                        val isTriggered = when {
                            isAbove -> currentPrice >= target
                            isBelow -> currentPrice <= target
                            rule.alertType == "RSI_OVERSOLD" -> TechnicalAnalysisEngine.analyze(marketEngine.candlesFor(asset)).rsi14 <= target
                            rule.alertType == "RSI_OVERBOUGHT" -> TechnicalAnalysisEngine.analyze(marketEngine.candlesFor(asset)).rsi14 >= target
                            else -> false
                        }

                        if (isTriggered) {
                            val cooldownKey = "custom_rule_${rule.id}"
                            val lastTime = lastTriggeredCache[cooldownKey] ?: 0L
                            // Cooldown: prevent multiple alerts in 15 seconds
                            if (now - lastTime > 15_000L) {
                                lastTriggeredCache[cooldownKey] = now
                                triggerCustomPriceAlert(rule, asset, currentPrice)

                                scope.launch(Dispatchers.IO) {
                                    alertDao.markRuleTriggered(rule.id, now)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    private fun triggerCustomPriceAlert(rule: AlertRuleEntity, asset: TradingAsset, triggeredPrice: Double) {
        val isAbove = rule.alertType.contains("ABOVE")
        val directionBengali = if (isAbove) "উর্ধ্বে (≥)" else "নিম্নে (≤)"
        val title = "🎯 প্রাইস টার্গেট অ্যালার্ট: ${asset.symbol}"
        val message = "${asset.symbol} আপনার নির্ধারিত টার্গেট $directionBengali ${String.format(Locale.US, "%.${asset.priceDecimals}f", rule.targetValue)} স্পর্শ করেছে! লাইভ মূল্য: ${String.format(Locale.US, "%.${asset.priceDecimals}f", triggeredPrice)}।"

        val playSound = rule.soundEnabled || _soundEnabled.value
        val playVibe = rule.vibrationEnabled || _vibrationEnabled.value
        soundManager.playUrgentAlert(soundEnabled = playSound, vibrationEnabled = playVibe)

        val notification = AlertNotification(
            id = UUID.randomUUID().toString(),
            title = title,
            message = message,
            assetSymbol = asset.symbol,
            type = if (isAbove) AlertType.PRICE_ABOVE else AlertType.PRICE_BELOW,
            timestamp = System.currentTimeMillis()
        )

        _latestAlert.value = notification
        saveNotification(notification)
    }

    private fun startScannerLoop() {
        scope.launch(Dispatchers.Default) {
            while (true) {
                delay(3000L)
                if (!_isAutoScannerActive.value) continue

                val assets = marketEngine.scanTargets()
                val now = System.currentTimeMillis()

                // Scan the watch-list with the Hasan Pro Signal indicator (last closed 1m candle)
                for (asset in assets) {
                    val candles = marketEngine.candlesFor(asset)
                    if (candles.size < 40) continue
                    val indicators = TechnicalAnalysisEngine.analyze(candles)
                    val signal = SignalEngine.generateSignal(
                        asset = asset,
                        candles = candles,
                        indicators = indicators,
                        platform = MarketPlatform.IQ_OPTION,
                        expiryTime = ExpiryTime.MIN_1
                    )

                    if (!signal.isWait && signal.confidence >= _minConfidenceThreshold.value) {
                        val cacheKey = "sig_${asset.id}_${signal.direction}"
                        val lastTime = lastTriggeredCache[cacheKey] ?: 0L
                        if (now - lastTime > 60_000L) {
                            lastTriggeredCache[cacheKey] = now
                            triggerSignalAlert(asset, signal.direction.label, signal.confidence, signal.strategyName)
                            break
                        }
                    }

                    // Technical Overbought / Oversold triggers
                    if (indicators.rsi14 <= 28.0) {
                        val cacheKey = "rsi_os_${asset.id}"
                        val lastTime = lastTriggeredCache[cacheKey] ?: 0L
                        if (now - lastTime > 60_000L) {
                            lastTriggeredCache[cacheKey] = now
                            triggerTechnicalAlert(
                                asset = asset,
                                title = "📉 RSI ওভারসোল্ড সতর্কবার্তা: ${asset.symbol}",
                                message = "RSI নেমে গেছে ${String.format(Locale.US, "%.1f", indicators.rsi14)}! সম্ভাব্য বুলিশ রিভার্সাল সেটআপ প্রস্তুত।",
                                type = AlertType.RSI_OVERSOLD
                            )
                            break
                        }
                    } else if (indicators.rsi14 >= 72.0) {
                        val cacheKey = "rsi_ob_${asset.id}"
                        val lastTime = lastTriggeredCache[cacheKey] ?: 0L
                        if (now - lastTime > 60_000L) {
                            lastTriggeredCache[cacheKey] = now
                            triggerTechnicalAlert(
                                asset = asset,
                                title = "📈 RSI ওভারবট সতর্কবার্তা: ${asset.symbol}",
                                message = "RSI পৌঁছেছে ${String.format(Locale.US, "%.1f", indicators.rsi14)}! মূল্য রিভার্সাল হওয়ার সম্ভাবনা (বিয়ারিশ রিজেকশন)।",
                                type = AlertType.RSI_OVERBOUGHT
                            )
                            break
                        }
                    }
                }
            }
        }
    }

    private fun triggerSignalAlert(asset: TradingAsset, direction: String, confidence: Int, strategy: String) {
        val bengaliDirection = if (direction.equals("CALL", ignoreCase = true)) "CALL (ক্রয়)" else "PUT (বিক্রয়)"
        val title = "⚡ এআই সিগন্যাল সতর্কবার্তা: $bengaliDirection - ${asset.symbol}"
        val message = "সেটআপ স্ট্রেংথ [${confidence}/100] সনাক্ত হয়েছে ($strategy)। বর্তমান মূল্য: ${asset.currentPrice}।"

        val playSound = _soundEnabled.value
        val playVibe = _vibrationEnabled.value

        if (direction.equals("CALL", ignoreCase = true)) {
            soundManager.playCallAlert(soundEnabled = playSound, vibrationEnabled = playVibe)
        } else {
            soundManager.playPutAlert(soundEnabled = playSound, vibrationEnabled = playVibe)
        }

        val notification = AlertNotification(
            id = UUID.randomUUID().toString(),
            title = title,
            message = message,
            assetSymbol = asset.symbol,
            type = AlertType.HIGH_WINRATE_SIGNAL,
            timestamp = System.currentTimeMillis()
        )

        _latestAlert.value = notification
        saveNotification(notification)
    }

    private fun triggerTechnicalAlert(
        asset: TradingAsset,
        title: String,
        message: String,
        type: AlertType
    ) {
        val playSound = _soundEnabled.value
        val playVibe = _vibrationEnabled.value
        soundManager.playUrgentAlert(soundEnabled = playSound, vibrationEnabled = playVibe)

        val notification = AlertNotification(
            id = UUID.randomUUID().toString(),
            title = title,
            message = message,
            assetSymbol = asset.symbol,
            type = type,
            timestamp = System.currentTimeMillis()
        )

        _latestAlert.value = notification
        saveNotification(notification)
    }

    private fun saveNotification(notif: AlertNotification) {
        scope.launch(Dispatchers.IO) {
            try {
                alertDao.insertNotification(
                    AlertNotificationEntity(
                        id = notif.id,
                        title = notif.title,
                        message = notif.message,
                        assetSymbol = notif.assetSymbol,
                        alertType = notif.type.name,
                        timestamp = notif.timestamp,
                        isRead = false
                    )
                )
            } catch (e: Exception) {}
        }
    }

    fun addCustomAlertRule(rule: AlertRule) {
        scope.launch(Dispatchers.IO) {
            alertDao.insertRule(
                AlertRuleEntity(
                    id = rule.id,
                    assetId = rule.assetId,
                    assetSymbol = rule.assetSymbol,
                    alertType = rule.type.name,
                    targetValue = rule.targetValue,
                    isEnabled = rule.isEnabled,
                    soundEnabled = rule.soundEnabled,
                    vibrationEnabled = rule.vibrationEnabled,
                    createdAt = rule.createdAt,
                    triggeredCount = 0,
                    lastTriggeredAt = 0L
                )
            )
        }
    }

    fun toggleRuleStatus(ruleId: String, isEnabled: Boolean) {
        scope.launch(Dispatchers.IO) {
            alertDao.toggleRuleStatus(ruleId, isEnabled)
        }
    }

    fun testTriggerCustomRule(rule: AlertRuleEntity) {
        val asset = marketEngine.assets.value.firstOrNull { it.id == rule.assetId }
            ?: marketEngine.assets.value.firstOrNull { it.symbol == rule.assetSymbol }
            ?: return
        triggerCustomPriceAlert(rule, asset, rule.targetValue)
    }

    fun deleteCustomAlertRule(ruleId: String) {
        scope.launch(Dispatchers.IO) {
            alertDao.deleteRuleById(ruleId)
        }
    }
}
