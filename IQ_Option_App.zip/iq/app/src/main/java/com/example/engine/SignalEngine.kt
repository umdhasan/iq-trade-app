package com.example.engine

import com.example.model.Candle
import com.example.model.ExpiryTime
import com.example.model.MarketPlatform
import com.example.model.SignalDirection
import com.example.model.TechnicalIndicators
import com.example.model.TradingAsset
import com.example.model.TradingSignal
import java.util.UUID

/**
 * Signal generator built on the "Hasan Pro Signal" indicator (WMA2 / EMA21 / RSI21 + strong candle).
 *
 *  - UP+ / DOWN+ : all strong-candle conditions fulfilled  -> CALL / PUT, high setup strength
 *  - UP? / DOWN? : trend conditions only                   -> CALL / PUT, medium setup strength
 *  - otherwise   : WAIT (no trade)
 *
 * The "confidence" value is a rule-based SETUP STRENGTH (0-100). It is NOT a win probability.
 * Signals are taken from the last CLOSED candle, so they do not repaint.
 */
object SignalEngine {

    fun generateSignal(
        asset: TradingAsset,
        candles: List<Candle>,
        indicators: TechnicalIndicators,
        platform: MarketPlatform,
        expiryTime: ExpiryTime,
        baseTradeAmount: Double = 10.0
    ): TradingSignal {
        val state = HasanProSignal.lastClosed(candles)

        val direction = when {
            state.isUp -> SignalDirection.CALL
            state.isDown -> SignalDirection.PUT
            // no setup: show the side of the slow trend, but flag the signal as WAIT
            state.fast >= state.slow -> SignalDirection.CALL
            else -> SignalDirection.PUT
        }

        val strategy = when (state.code) {
            HasanProSignal.UP_PLUS -> "Hasan Pro Signal • UP+ (strong candle)"
            HasanProSignal.DOWN_PLUS -> "Hasan Pro Signal • DOWN+ (strong candle)"
            HasanProSignal.UP_POSSIBLE -> "Hasan Pro Signal • UP? (trend only)"
            HasanProSignal.DOWN_POSSIBLE -> "Hasan Pro Signal • DOWN? (trend only)"
            else -> "WAIT • no Hasan Pro setup on the last closed candle"
        }

        val step1 = baseTradeAmount * 2.2
        val step2 = step1 * 2.3

        return TradingSignal(
            id = UUID.randomUUID().toString(),
            assetId = asset.id,
            assetSymbol = asset.symbol,
            assetCategory = asset.category,
            direction = direction,
            confidence = state.strength,
            strikePrice = asset.currentPrice,
            expiryTime = expiryTime,
            platform = platform,
            strategyName = strategy,
            martingaleStep1 = roundToTwoDecimals(step1),
            martingaleStep2 = roundToTwoDecimals(step2),
            rsiValue = roundToTwoDecimals(state.rsi),
            macdTrend = if (indicators.macdHistogram >= 0) "Bullish Convergence" else "Bearish Divergence",
            isWait = !state.hasSignal
        )
    }

    private fun roundToTwoDecimals(value: Double): Double {
        return kotlin.math.round(value * 100.0) / 100.0
    }
}
