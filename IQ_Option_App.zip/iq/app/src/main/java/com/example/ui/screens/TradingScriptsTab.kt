package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BearishRed
import com.example.ui.theme.BullishGreen
import com.example.ui.theme.CardBorder
import com.example.ui.theme.CardSurface
import com.example.ui.theme.CardSurfaceElevated
import com.example.ui.theme.CryptoGold
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DarkNavyBg
import com.example.ui.theme.DigitalTeal
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

data class ScriptTemplate(
    val id: String,
    val titleBn: String,
    val subtitle: String,
    val timeframe: String,
    val expiryTime: String,
    val winRate: String,
    val callConditionBn: String,
    val putConditionBn: String,
    val proTipBn: String,
    val code: String
)

val MASTER_TEMPLATES = listOf(
    ScriptTemplate(
        id = "hasan_pro_signal",
        titleBn = "Hasan Pro Signal (UP+ / DOWN+ / UP? / DOWN?)",
        subtitle = "WMA 2 + EMA 21 + RSI 21 + শক্তিশালী ক্যান্ডেল ফিল্টার",
        timeframe = "১ মিনিট বা তার বেশি (অ্যাপের টার্মিনালে ডিফল্ট ১m)",
        expiryTime = "১ মিনিট থেকে ৫ মিনিট (ব্লিটজে ৫s-৩০s নিজে ব্যাকটেস্ট করে নিন)",
        winRate = "উইন রেটের কোনো নিশ্চয়তা নেই (নিজে ব্যাকটেস্ট করুন)",
        callConditionBn = "UP?: দ্রুত WMA(2) > ধীর EMA(21), WMA ঊর্ধ্বমুখী, ক্লোজ WMA-র উপরে, RSI(21) > 52। UP+: UP? এর সাথে EMA(21) নিচমুখী নয়, RSI > 58 এবং শক্তিশালী গ্রিন ক্যান্ডেল (বডি ≥ ৬০% রেঞ্জ, ক্লোজ হাই-এর ২৫% এর মধ্যে)।",
        putConditionBn = "DOWN?: WMA(2) < EMA(21), WMA নিম্নমুখী, ক্লোজ WMA-র নিচে, RSI(21) < 48। DOWN+: DOWN? এর সাথে EMA(21) ঊর্ধ্বমুখী নয়, RSI < 42 এবং শক্তিশালী রেড ক্যান্ডেল।",
        proTipBn = "সিগন্যাল শুধু ক্লোজ হওয়া ক্যান্ডেল থেকে নিন, চলমান ক্যান্ডেলে সিগন্যাল বদলে যেতে পারে। UP+/DOWN+ কে UP?/DOWN? এর চেয়ে শক্তিশালী সেটআপ ধরা হয়, তবে কোনোটাই জেতার গ্যারান্টি নয়। অ্যাপের AI Bot-এর সেটআপ স্ট্রেংথ এই নিয়ম মেলারই স্কোর।",
        code = """
//@version=5
indicator("Hasan Pro Signal", overlay=true)

fast = ta.wma(close, 2)
slow = ta.ema(close, 21)
r    = ta.rsi(close, 21)

rng  = high - low
body = math.abs(close - open)
strongGreen = close > open and rng > 0 and body / rng >= 0.60 and (high - close) / rng <= 0.25
strongRed   = close < open and rng > 0 and body / rng >= 0.60 and (close - low) / rng <= 0.25

upPossible   = fast > slow and fast > fast[1] and close > fast and r > 52
downPossible = fast < slow and fast < fast[1] and close < fast and r < 48
upStrong     = upPossible   and slow >= slow[1] and r > 58 and strongGreen
downStrong   = downPossible and slow <= slow[1] and r < 42 and strongRed

plot(fast, color=color.aqua,   linewidth=2, title="WMA 2 (Fast)")
plot(slow, color=color.orange, linewidth=2, title="EMA 21 (Slow)")

plotshape(upStrong,   title="UP+",   style=shape.labelup,   location=location.belowbar, color=color.green, text="UP+",   textcolor=color.white)
plotshape(downStrong, title="DOWN+", style=shape.labeldown, location=location.abovebar, color=color.red,   text="DOWN+", textcolor=color.white)
plotshape(upPossible   and not upStrong,   title="UP?",   style=shape.triangleup,   location=location.belowbar, color=color.new(color.green, 40), size=size.tiny)
plotshape(downPossible and not downStrong, title="DOWN?", style=shape.triangledown, location=location.abovebar, color=color.new(color.red, 40),   size=size.tiny)

alertcondition(upStrong,   title="Hasan UP+",   message="Hasan Pro Signal: UP+")
alertcondition(downStrong, title="Hasan DOWN+", message="Hasan Pro Signal: DOWN+")
        """.trimIndent()
    ),
    ScriptTemplate(
        id = "blitz_scalper_1m",
        titleBn = "Ultra Pro 1-Minute Blitz Scalper",
        subtitle = "EMA 9/21 ক্রস + RSI 14 মিন রিভার্সন + Stochastic অসিলেটর",
        timeframe = "১ মিনিট (1m Candle)",
        expiryTime = "১ মিনিট (60s Blitz / Digital Option)",
        winRate = "৮৭% - ৮৯% উইনিং রেট",
        callConditionBn = "CALL এন্ট্রি: দ্রুত EMA (9) নিচ থেকে ধীর EMA (21) কে ক্রস করে উপরে উঠবে, RSI 14 এর মান 50 এর উপরে থাকবে এবং Stochastic %K %D কে 20-40 জোনে গোল্ডেন ক্রস দেবে।",
        putConditionBn = "PUT এন্ট্রি: দ্রুত EMA (9) উপর থেকে ধীর EMA (21) কে ক্রস করে নিচে নামবে, RSI 14 এর মান 50 এর নিচে নামবে এবং Stochastic %K %D কে 60-80 জোনে ডেথ ক্রস দেবে।",
        proTipBn = "উচ্চ তারল্যের গোল্ডেন সেশনে (সন্ধ্যা ৬টা - রাত ১০টা) EUR/USD, GBP/USD বা Blitz Gold এ সবচেয়ে ভালো ফলাফল দেয়।",
        code = """
//@version=5
indicator("TradePro Ultra 1m Blitz Scalper", overlay=true)
ema9 = ta.ema(close, 9)
ema21 = ta.ema(close, 21)
rsi14 = ta.rsi(close, 14)
k = ta.sma(ta.stoch(close, high, low, 14), 3)
d = ta.sma(k, 3)

buySignal = ta.crossover(ema9, ema21) and rsi14 > 50 and ta.crossover(k, d) and k < 45
sellSignal = ta.crossunder(ema9, ema21) and rsi14 < 50 and ta.crossunder(k, d) and k > 55

plot(ema9, color=color.aqua, linewidth=2, title="EMA 9 (Fast)")
plot(ema21, color=color.purple, linewidth=2, title="EMA 21 (Slow)")

plotshape(buySignal, title="CALL 60s", style=shape.triangleup, location=location.belowbar, color=color.green, size=size.normal, text="CALL 60s")
plotshape(sellSignal, title="PUT 60s", style=shape.triangledown, location=location.abovebar, color=color.red, size=size.normal, text="PUT 60s")

alertcondition(buySignal, title="Blitz CALL Alert", message="⚡ 1m Blitz CALL Entry Signal!")
alertcondition(sellSignal, title="Blitz PUT Alert", message="⚡ 1m Blitz PUT Entry Signal!")
        """.trimIndent()
    ),
    ScriptTemplate(
        id = "trend_surfer_5m",
        titleBn = "5-Minute Trend Surfer Pro",
        subtitle = "Bollinger Bands (20, 2) + MACD হিস্টোগ্রাম কনফার্মেশন",
        timeframe = "৫ মিনিট (5m Candle)",
        expiryTime = "৫ মিনিট থেকে ১৫ মিনিট এক্সপায়ারি",
        winRate = "৮৩% - ৮৬% উইনিং রেট",
        callConditionBn = "CALL এন্ট্রি: ক্যান্ডেল বলিঙ্গার ব্যান্ডের লোয়ার ব্যান্ড স্পর্শ করে শক্তিশালী রিজেকশন বা বুলিশ পিনবার তৈরি করবে এবং MACD হিস্টোগ্রাম গ্রিন ও ঊর্ধ্বমুখী হবে।",
        putConditionBn = "PUT এন্ট্রি: ক্যান্ডেল বলিঙ্গার ব্যান্ডের আপার ব্যান্ডে রিজেকশন বা বিয়ারিশ পিনবার তৈরি করবে এবং MACD হিস্টোগ্রাম রেড ও নিম্নমুখী হবে।",
        proTipBn = "ব্যান্ড ওয়াইডেনিং (ব্যান্ড খোলার সময়) ট্রেন্ডের সাথে চলুন। ফ্ল্যাট মার্কেটে ব্যান্ড বাউন্স রিভার্সাল সেরা কাজ করে।",
        code = """
//@version=5
indicator("TradePro 5m Trend Surfer Pro", overlay=true)
[bbMiddle, bbUpper, bbLower] = ta.bb(close, 20, 2.0)
[macdLine, signalLine, hist] = ta.macd(close, 12, 26, 9)

callEntry = ta.crossover(close, bbLower) and hist > 0 and hist > hist[1]
putEntry = ta.crossunder(close, bbUpper) and hist < 0 and hist < hist[1]

plot(bbUpper, color=color.red, linewidth=1, title="Upper Band")
plot(bbMiddle, color=color.gray, linewidth=1, title="Middle SMA 20")
plot(bbLower, color=color.green, linewidth=1, title="Lower Band")

plotshape(callEntry, title="CALL 5m", style=shape.labelup, location=location.belowbar, color=color.green, text="CALL 5m", textcolor=color.white)
plotshape(putEntry, title="PUT 5m", style=shape.labeldown, location=location.abovebar, color=color.red, text="PUT 5m", textcolor=color.white)
        """.trimIndent()
    ),
    ScriptTemplate(
        id = "sr_breakout",
        titleBn = "সাপোর্ট এবং রেজিস্ট্যান্স ব্রেকআউট অ্যালার্ট",
        subtitle = "ডায়নামিক পিভট লেভেল + ভলিউম ব্রেকআউট ডিটেকশন",
        timeframe = "১ মিনিট বা ৫ মিনিট",
        expiryTime = "১ থেকে ৩ ক্যান্ডেল এক্সপায়ারি",
        winRate = "৮৫%+ উইনিং রেট",
        callConditionBn = "CALL এন্ট্রি: বিগত রেজিস্ট্যান্স লেভেল উচ্চ ভলিউমের সাথে ব্রেকআউট হলে এবং রিটেস্টে বুলিশ ক্যান্ডেল নিশ্চিত হলে CALL ট্রেড নিন।",
        putConditionBn = "PUT এন্ট্রি: বিগত সাপোর্ট লেভেল উচ্চ ভলিউমের সাথে ব্রেকডাউন হলে এবং রিটেস্টে বিয়ারিশ ক্যান্ডেল নিশ্চিত হলে PUT ট্রেড নিন।",
        proTipBn = "ফলস ব্রেকআউট এড়ানোর জন্য সর্বদা ক্যান্ডেল ক্লোজের অপেক্ষা করুন এবং RSI 50 এর সাথে সামঞ্জস্য যাচাই করুন।",
        code = """
//@version=5
indicator("TradePro Dynamic S/R Breakout", overlay=true)
leftBars = 15
rightBars = 15
ph = ta.pivothigh(high, leftBars, rightBars)
pl = ta.pivotlow(low, leftBars, rightBars)

var float resLevel = na
var float supLevel = na
if not na(ph)
    resLevel := ph
if not na(pl)
    supLevel := pl

resBreak = ta.crossover(close, resLevel)
supBreak = ta.crossunder(close, supLevel)

plot(resLevel, color=color.red, style=plot.style_circles, linewidth=2, title="Resistance")
plot(supLevel, color=color.green, style=plot.style_circles, linewidth=2, title="Support")

plotshape(resBreak, title="Res Breakout", style=shape.arrowup, location=location.belowbar, color=color.teal, text="BREAK CALL")
plotshape(supBreak, title="Sup Breakdown", style=shape.arrowdown, location=location.abovebar, color=color.maroon, text="BREAK PUT")
        """.trimIndent()
    )
)

@Composable
fun TradingScriptsTab(
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var copiedId by remember { mutableStateOf<String?>(null) }

    Column(modifier = modifier.fillMaxWidth()) {
        Text(
            text = "ট্রেডিং স্ক্রিপ্ট ও প্রফেশনাল ইন্ডিকেটর টেমপ্লেট",
            color = CyberCyan,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "TradingView ও IQ Option-এর জন্য রেডিমেড কোড ও গাইড। কোনো স্ক্রিপ্টই জেতার গ্যারান্টি দেয় না।",
            color = TextSecondary,
            fontSize = 11.sp
        )

        Spacer(modifier = Modifier.height(12.dp))

        MASTER_TEMPLATES.forEach { template ->
            ScriptCardItem(
                template = template,
                isCopied = copiedId == template.id,
                onCopy = {
                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                    val clip = ClipData.newPlainText("TradePro Script", template.code)
                    clipboard?.setPrimaryClip(clip)
                    copiedId = template.id
                }
            )
            Spacer(modifier = Modifier.height(12.dp))
        }
    }
}

@Composable
fun ScriptCardItem(
    template: ScriptTemplate,
    isCopied: Boolean,
    onCopy: () -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = CardSurface),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, CardBorder, RoundedCornerShape(12.dp))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(CyberCyan.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Code, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(18.dp))
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = template.titleBn,
                            color = TextPrimary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = template.subtitle,
                            color = TextMuted,
                            fontSize = 10.sp
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(BullishGreen.copy(alpha = 0.15f))
                        .border(1.dp, BullishGreen.copy(alpha = 0.3f), RoundedCornerShape(6.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = template.winRate,
                        color = BullishGreen,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Badges row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(CardSurfaceElevated)
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text("ক্যান্ডেল: ${template.timeframe}", color = TextSecondary, fontSize = 10.sp)
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(CardSurfaceElevated)
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text("মেয়াদ: ${template.expiryTime}", color = CryptoGold, fontSize = 10.sp)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Instructions
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(DarkNavyBg.copy(alpha = 0.6f))
                    .padding(10.dp)
            ) {
                Text(template.callConditionBn, color = BullishGreen, fontSize = 11.sp, lineHeight = 16.sp)
                Spacer(modifier = Modifier.height(6.dp))
                Text(template.putConditionBn, color = BearishRed, fontSize = 11.sp, lineHeight = 16.sp)
                Spacer(modifier = Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Lightbulb, contentDescription = null, tint = CryptoGold, modifier = Modifier.size(13.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(template.proTipBn, color = TextMuted, fontSize = 10.sp)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Action Buttons: Toggle code & Copy
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .clickable { expanded = !expanded }
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (expanded) "কোড লুকান" else "স্ক্রিপ্ট কোড দেখুন",
                        color = CyberCyan,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Icon(
                        imageVector = if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = null,
                        tint = CyberCyan,
                        modifier = Modifier.size(16.dp)
                    )
                }

                Button(
                    onClick = onCopy,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isCopied) BullishGreen else CyberCyan
                    ),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier.height(32.dp)
                ) {
                    Icon(
                        imageVector = if (isCopied) Icons.Default.Check else Icons.Default.ContentCopy,
                        contentDescription = null,
                        tint = DarkNavyBg,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (isCopied) "কপি হয়েছে!" else "কোড কপি করুন",
                        color = DarkNavyBg,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Code Preview Block
            AnimatedVisibility(visible = expanded) {
                Column(
                    modifier = Modifier
                        .padding(top = 10.dp)
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF0D1117))
                        .border(1.dp, CardBorder, RoundedCornerShape(8.dp))
                        .padding(10.dp)
                ) {
                    Text(
                        text = template.code,
                        color = Color(0xFF58A6FF),
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        lineHeight = 14.sp,
                        modifier = Modifier.horizontalScroll(rememberScrollState())
                    )
                }
            }
        }
    }
}
