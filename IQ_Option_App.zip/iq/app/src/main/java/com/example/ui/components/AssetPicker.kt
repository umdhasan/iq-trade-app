package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.model.MarketCategory
import com.example.model.MarketType
import com.example.model.QuoteStatus
import com.example.model.TradingAsset
import com.example.ui.theme.BearishRed
import com.example.ui.theme.BullishGreen
import com.example.ui.theme.CardBorder
import com.example.ui.theme.CardSurface
import com.example.ui.theme.CardSurfaceElevated
import com.example.ui.theme.CryptoGold
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DarkNavyBg
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.Locale

fun marketColor(m: MarketType): Color = when (m) {
    MarketType.DIGITAL -> Color(0xFF14B8A6)
    MarketType.BINARY -> Color(0xFF38BDF8)
    MarketType.FOREX -> Color(0xFFF59E0B)
    MarketType.BLITZ -> Color(0xFFA855F7)
}

fun formatPrice(a: TradingAsset): String =
    if (a.hasPrice) String.format(Locale.US, "%.${a.priceDecimals}f", a.currentPrice) else "—"

@Composable
fun StatusDot(status: QuoteStatus, modifier: Modifier = Modifier) {
    val color = when (status) {
        QuoteStatus.LIVE -> BullishGreen
        QuoteStatus.STALE -> CryptoGold
        QuoteStatus.WAITING -> TextMuted
        QuoteStatus.NO_FEED -> BearishRed
    }
    Box(modifier = modifier.size(7.dp).clip(CircleShape).background(color))
}

fun statusLabel(a: TradingAsset): String = when (a.status) {
    QuoteStatus.LIVE -> "LIVE"
    QuoteStatus.STALE -> "মার্কেট বন্ধ/বিলম্বিত"
    QuoteStatus.WAITING -> "লোড হচ্ছে..."
    QuoteStatus.NO_FEED -> "পাবলিক ফিড নেই"
}

/**
 * Asset chooser with the four IQ Option market lists: Digital, Binary, Forex, Blitz.
 * [onBrowse] tells the price engine which list is visible so only those prices are fetched.
 */
@Composable
fun AssetPickerDialog(
    allAssets: List<TradingAsset>,
    initialMarket: MarketType,
    onBrowse: (MarketType?) -> Unit,
    onDismiss: () -> Unit,
    onSelect: (TradingAsset) -> Unit
) {
    var market by remember { mutableStateOf(initialMarket) }
    var category by remember { mutableStateOf<MarketCategory?>(null) }
    var query by remember { mutableStateOf("") }

    DisposableEffect(market) {
        onBrowse(market)
        onDispose { onBrowse(null) }
    }

    val list = allAssets.filter { a ->
        a.marketType == market &&
            (category == null || a.category == category) &&
            (query.isBlank() || a.symbol.contains(query, ignoreCase = true) || a.name.contains(query, ignoreCase = true))
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.92f)
                .padding(horizontal = 8.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(DarkNavyBg)
                .border(1.dp, CardBorder, RoundedCornerShape(16.dp))
                .padding(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Choose an asset", color = TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                }
            }

            // Market tabs (Digital / Binary / Forex / Blitz)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(CardSurface)
                    .padding(3.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                MarketType.values().forEach { m ->
                    val sel = m == market
                    val count = allAssets.count { it.marketType == m }
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (sel) marketColor(m).copy(alpha = 0.25f) else Color.Transparent)
                            .border(1.dp, if (sel) marketColor(m) else Color.Transparent, RoundedCornerShape(8.dp))
                            .clickable { market = m; category = null }
                            .padding(vertical = 7.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                m.displayName,
                                color = if (sel) marketColor(m) else TextSecondary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text("$count", color = TextMuted, fontSize = 9.sp)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                placeholder = { Text("Search by name or ticker", color = TextMuted, fontSize = 12.sp) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = TextMuted, modifier = Modifier.size(16.dp)) },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = CardSurface,
                    unfocusedContainerColor = CardSurface,
                    focusedBorderColor = CyberCyan,
                    unfocusedBorderColor = CardBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(6.dp))

            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                item {
                    CategoryPill("All", allAssets.count { it.marketType == market }, category == null, CyberCyan) { category = null }
                }
                items(MarketCategory.values().toList()) { c ->
                    val cnt = allAssets.count { it.marketType == market && it.category == c }
                    if (cnt > 0) {
                        CategoryPill(c.displayName, cnt, category == c, Color(c.badgeColorHex)) { category = c }
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            LazyColumn(
                modifier = Modifier.fillMaxWidth().weight(1f),
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                items(list, key = { it.id }) { a ->
                    AssetPickerRow(a) { onSelect(a) }
                }
            }
        }
    }
}

@Composable
private fun CategoryPill(label: String, count: Int, selected: Boolean, color: Color, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .background(if (selected) color.copy(alpha = 0.22f) else CardSurface)
            .border(1.dp, if (selected) color else CardBorder, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 5.dp)
    ) {
        Text(
            text = "$label $count",
            color = if (selected) color else TextSecondary,
            fontSize = 11.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
        )
    }
}

@Composable
private fun AssetPickerRow(a: TradingAsset, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(CardSurface)
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 9.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
            StatusDot(a.status)
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(a.symbol, color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                Text(
                    text = if (a.payoutPercent > 0) "${a.category.displayName} • +${a.payoutPercent}%" else a.category.displayName,
                    color = TextMuted,
                    fontSize = 10.sp,
                    maxLines = 1
                )
            }
        }
        Column(horizontalAlignment = Alignment.End) {
            Text(
                formatPrice(a),
                color = if (!a.hasPrice) TextMuted else if (a.isUp) BullishGreen else BearishRed,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )
            if (a.hasPrice) {
                Text(
                    text = String.format(Locale.US, "%+.2f%%", a.change24h),
                    color = if (a.change24h >= 0) BullishGreen else BearishRed,
                    fontSize = 10.sp
                )
            } else {
                Text(statusLabel(a), color = TextMuted, fontSize = 9.sp)
            }
        }
    }
}
