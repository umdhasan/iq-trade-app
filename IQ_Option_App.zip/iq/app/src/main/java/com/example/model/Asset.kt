package com.example.model

enum class MarketCategory(val displayName: String, val badgeColorHex: Long) {
    CURRENCIES("Currencies", 0xFF14B8A6),
    CRYPTO("Crypto", 0xFFF59E0B),
    COMMODITIES("Commodities", 0xFF38BDF8),
    STOCKS("Stocks / ETF", 0xFFA855F7),
    INDICES("Indices", 0xFFEC4899)
}

/** The four IQ Option market lists. Each one has its own, separate asset list. */
enum class MarketType(val displayName: String, val subtitle: String) {
    DIGITAL("Digital", "Digital Options"),
    BINARY("Binary", "Binary Options"),
    FOREX("Forex", "Margin CFD / Forex"),
    BLITZ("Blitz", "Blitz Options")
}

enum class MarketPlatform(val displayName: String, val shortName: String) {
    IQ_OPTION("IQ Option", "IQ")
}

enum class ExpiryTime(val label: String, val seconds: Int, val isBlitz: Boolean = false) {
    SEC_5("5s", 5, true),
    SEC_15("15s", 15, true),
    SEC_30("30s", 30, true),
    MIN_1("1m", 60),
    MIN_2("2m", 120),
    MIN_5("5m", 300),
    MIN_15("15m", 900)
}

data class Candle(
    val timestamp: Long,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Double
) {
    val isBullish: Boolean get() = close >= open
}

/** Where the real price of an asset comes from. */
enum class FeedSource { BINANCE, YAHOO, DERIVED, NONE }

/**
 * Price feed description.
 * - BINANCE: [symbol] is a Binance spot pair such as BTCUSDT.
 * - YAHOO: [symbol] is a Yahoo Finance symbol such as EURUSD=X.
 * - DERIVED: price = numerator / denominator (or * when [multiply]) of two other feed keys.
 */
data class FeedRef(
    val source: FeedSource,
    val symbol: String = "",
    val numeratorKey: String = "",
    val denominatorKey: String = "",
    val multiply: Boolean = false
) {
    /** Unique key shared by every asset that uses the same real price. */
    val key: String
        get() = when (source) {
            FeedSource.BINANCE -> "B:$symbol"
            FeedSource.YAHOO -> "Y:$symbol"
            FeedSource.DERIVED -> "D:$numeratorKey${if (multiply) "*" else "/"}$denominatorKey"
            FeedSource.NONE -> "N:$symbol"
        }
}

enum class QuoteStatus { WAITING, LIVE, STALE, NO_FEED }

data class TradingAsset(
    val id: String,
    val symbol: String,
    val name: String,
    val category: MarketCategory,
    val marketType: MarketType,
    val feed: FeedRef,
    val payoutPercent: Int,
    val isOtc: Boolean = false,
    val priceDecimals: Int = 5,
    val basePrice: Double = 0.0,
    val currentPrice: Double = 0.0,
    val prevPrice: Double = 0.0,
    val change24h: Double = 0.0,
    val high24h: Double = 0.0,
    val low24h: Double = 0.0,
    val status: QuoteStatus = QuoteStatus.WAITING,
    val lastUpdateMs: Long = 0L
) {
    val isUp: Boolean get() = currentPrice >= prevPrice
    val hasPrice: Boolean get() = currentPrice > 0.0
}

data class TechnicalIndicators(
    val rsi14: Double,
    val ema9: Double,
    val ema21: Double,
    val bbUpper: Double,
    val bbMiddle: Double,
    val bbLower: Double,
    val macdValue: Double,
    val macdSignal: Double,
    val macdHistogram: Double,
    val stochasticK: Double,
    val stochasticD: Double,
    val bullishSentimentPercent: Int,
    val volatilityLevel: String, // "Low", "Medium", "High", "Ultra"
    val trendRecommendation: String // "STRONG_BUY", "BUY", "NEUTRAL", "SELL", "STRONG_SELL"
)
