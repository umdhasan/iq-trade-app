package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.MarketSessionEngine
import com.example.engine.TradingSessionInfo
import com.example.model.MarketCategory
import com.example.model.MarketType
import com.example.model.TradingAsset
import com.example.ui.NavigationTab
import com.example.ui.TradeProViewModel
import com.example.ui.components.StatusDot
import com.example.ui.components.formatPrice
import com.example.ui.components.marketColor
import com.example.ui.components.statusLabel
import com.example.ui.theme.BearishRed
import com.example.ui.theme.BullishGreen
import com.example.ui.theme.CardBorder
import com.example.ui.theme.CardSurface
import com.example.ui.theme.CardSurfaceElevated
import com.example.ui.theme.CryptoGold
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DarkNavyBg
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.Locale

@Composable
fun MarketsScreen(
    viewModel: TradeProViewModel,
    modifier: Modifier = Modifier
) {
    val assets by viewModel.allAssets.collectAsState()
    val selectedMarket by viewModel.selectedMarket.collectAsState()
    val selectedCategory by viewModel.selectedCategory.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val watchlist by viewModel.watchlist.collectAsState()

    var activeScreenTab by remember { mutableStateOf("MARKETS") } // "MARKETS" or "SESSIONS"
    var activePresetFilter by remember { mutableStateOf("ALL") }

    val sessions = remember { MarketSessionEngine.getSessions() }
    val currentBstTime = remember { MarketSessionEngine.getCurrentBstFormatted() }

    val marketAssets = remember(assets, selectedMarket) {
        assets.filter { it.marketType == selectedMarket }
    }

    val filteredAssets = remember(marketAssets, selectedCategory, searchQuery, activePresetFilter, watchlist) {
        marketAssets.filter { asset ->
            val matchesCategory = selectedCategory == null || asset.category == selectedCategory
            val matchesSearch = searchQuery.isBlank() ||
                asset.symbol.contains(searchQuery, ignoreCase = true) ||
                asset.name.contains(searchQuery, ignoreCase = true)
            val matchesPreset = when (activePresetFilter) {
                "WATCH" -> asset.id in watchlist
                "OTC_ONLY" -> asset.isOtc
                "REAL_ONLY" -> !asset.isOtc
                else -> true
            }
            matchesCategory && matchesSearch && matchesPreset
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkNavyBg)
            .padding(horizontal = 14.dp)
            .testTag("markets_screen")
    ) {
        Spacer(modifier = Modifier.height(10.dp))

        // Main switcher: Markets vs Trading Sessions
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(CardSurface)
                .border(1.dp, CardBorder, RoundedCornerShape(10.dp))
                .padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (activeScreenTab == "MARKETS") CyberCyan else Color.Transparent)
                    .clickable { activeScreenTab = "MARKETS" }
                    .padding(vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.ShowChart,
                        contentDescription = null,
                        tint = if (activeScreenTab == "MARKETS") DarkNavyBg else TextSecondary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "IQ Option মার্কেট",
                        color = if (activeScreenTab == "MARKETS") DarkNavyBg else TextSecondary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Box(
                modifier = Modifier
                    .weight(1.2f)
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (activeScreenTab == "SESSIONS") CryptoGold else Color.Transparent)
                    .clickable { activeScreenTab = "SESSIONS" }
                    .padding(vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.AccessTime,
                        contentDescription = null,
                        tint = if (activeScreenTab == "SESSIONS") DarkNavyBg else CryptoGold,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "ট্রেডিং সেশন (Trading Sessions)",
                        color = if (activeScreenTab == "SESSIONS") DarkNavyBg else CryptoGold,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        if (activeScreenTab == "SESSIONS") {
            TradingSessionsSection(
                sessions = sessions,
                currentBstTime = currentBstTime,
                onSelectPair = { pairSymbol ->
                    val found = assets.firstOrNull {
                        it.symbol.equals(pairSymbol, ignoreCase = true) || it.symbol.startsWith(pairSymbol)
                    }
                    if (found != null) {
                        viewModel.selectAsset(found.id)
                        viewModel.selectTab(NavigationTab.TERMINAL)
                    }
                }
            )
        } else {
            // ---- 4 market tabs: Digital / Binary / Forex / Blitz ----
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(CardSurface)
                    .padding(3.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                MarketType.values().forEach { m ->
                    val sel = m == selectedMarket
                    val count = assets.count { it.marketType == m }
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (sel) marketColor(m).copy(alpha = 0.25f) else Color.Transparent)
                            .border(1.dp, if (sel) marketColor(m) else Color.Transparent, RoundedCornerShape(8.dp))
                            .clickable {
                                activePresetFilter = "ALL"
                                viewModel.selectMarket(m)
                            }
                            .padding(vertical = 7.dp)
                            .testTag("market_tab_${m.name}"),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = m.displayName,
                                color = if (sel) marketColor(m) else TextSecondary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(text = "$count", color = TextMuted, fontSize = 9.sp)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.setSearchQuery(it) },
                placeholder = { Text("EUR/USD, Gold, Bitcoin, Tesla খুঁজুন...", color = TextMuted, fontSize = 12.sp) },
                leadingIcon = {
                    Icon(Icons.Default.Search, contentDescription = "Search", tint = TextSecondary, modifier = Modifier.size(18.dp))
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = CardSurface,
                    unfocusedContainerColor = CardSurface,
                    focusedBorderColor = CyberCyan,
                    unfocusedBorderColor = CardBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                shape = RoundedCornerShape(12.dp),
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("market_search_input")
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Quick presets
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                item {
                    PresetChip("সব (${marketAssets.size})", activePresetFilter == "ALL") { activePresetFilter = "ALL" }
                }
                item {
                    PresetChip("★ ওয়াচলিস্ট", activePresetFilter == "WATCH") { activePresetFilter = "WATCH" }
                }
                item {
                    PresetChip("⚡ OTC", activePresetFilter == "OTC_ONLY") { activePresetFilter = "OTC_ONLY" }
                }
                item {
                    PresetChip("🌐 রিয়েল মার্কেট", activePresetFilter == "REAL_ONLY") { activePresetFilter = "REAL_ONLY" }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Category chips
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                item {
                    CategoryChip(
                        label = "সকল ক্যাটাগরি",
                        isSelected = selectedCategory == null,
                        badgeColor = CyberCyan,
                        onClick = { viewModel.selectCategory(null) }
                    )
                }
                items(MarketCategory.values().toList()) { category ->
                    CategoryChip(
                        label = category.displayName,
                        isSelected = selectedCategory == category,
                        badgeColor = Color(category.badgeColorHex),
                        onClick = { viewModel.selectCategory(category) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${filteredAssets.size} টি অ্যাসেট • ${selectedMarket.subtitle}",
                    color = TextSecondary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )
                Text(
                    text = "রিয়েল মার্কেট প্রাইস",
                    color = CyberCyan,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(filteredAssets, key = { it.id }) { asset ->
                    AssetRowCard(
                        asset = asset,
                        isWatched = asset.id in watchlist,
                        onToggleWatch = { viewModel.toggleWatch(asset.id) },
                        onSelect = {
                            viewModel.selectAsset(asset.id)
                            viewModel.selectTab(NavigationTab.TERMINAL)
                        },
                        onScanSignal = {
                            viewModel.selectAsset(asset.id)
                            viewModel.selectTab(NavigationTab.SIGNALS)
                            viewModel.generateSignalForSelectedAsset()
                        },
                        onSetAlert = {
                            viewModel.navigateToAlertsForAsset(asset.id)
                        }
                    )
                }
                item {
                    Spacer(modifier = Modifier.height(80.dp))
                }
            }
        }
    }
}

/**
 * Dedicated Trading Sessions Section featuring 4 distinct Session Cards with Bengali instructions
 */
@Composable
fun TradingSessionsSection(
    sessions: List<TradingSessionInfo>,
    currentBstTime: String,
    onSelectPair: (String) -> Unit
) {
    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            // Live Bangladesh Time Header
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = CardSurface),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, CardBorder, RoundedCornerShape(12.dp))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(CryptoGold.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.AccessTime, contentDescription = null, tint = CryptoGold, modifier = Modifier.size(20.dp))
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "আন্তর্জাতিক ফরেক্স ও অপশন সেশন",
                                color = TextPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "বর্তমান সময়: $currentBstTime (UTC+6)",
                                color = CyberCyan,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
        }

        // 4 Distinct Session Cards
        items(sessions, key = { it.id }) { session ->
            SessionCard(session = session, onSelectPair = onSelectPair)
        }

        item {
            Spacer(modifier = Modifier.height(80.dp))
        }
    }
}

@Composable
fun SessionCard(
    session: TradingSessionInfo,
    onSelectPair: (String) -> Unit
) {
    val borderColor = if (session.isActive) BullishGreen else CardBorder
    val activeBg = if (session.isActive) BullishGreen.copy(alpha = 0.08f) else CardSurface

    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = activeBg),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, borderColor, RoundedCornerShape(14.dp))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Session Title & Status Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(
                                if (session.isGoldenHour) CryptoGold.copy(alpha = 0.2f)
                                else CyberCyan.copy(alpha = 0.2f)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (session.isGoldenHour) Icons.Default.LocalFireDepartment else Icons.Default.Public,
                            contentDescription = null,
                            tint = if (session.isGoldenHour) CryptoGold else CyberCyan,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = session.nameBn,
                            color = TextPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${session.bstHours} • (${session.utcHours})",
                            color = TextSecondary,
                            fontSize = 10.sp
                        )
                    }
                }

                // Active Badge
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (session.isActive) BullishGreen.copy(alpha = 0.2f) else CardSurfaceElevated)
                        .border(1.dp, if (session.isActive) BullishGreen else CardBorder, RoundedCornerShape(12.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(if (session.isActive) BullishGreen else TextMuted)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (session.isActive) "বর্তমানে সক্রিয়" else "এখন বন্ধ",
                            color = if (session.isActive) BullishGreen else TextMuted,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Best Recommended Pairs for this Session
            Text(
                text = "সেরা ট্রেডিং পেয়ারসমূহ (IQ Option):",
                color = TextMuted,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(6.dp))

            // Clickable Quick-Launch Chips for Best Pairs
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(session.bestPairs) { pair ->
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(CardSurfaceElevated)
                            .border(1.dp, CyberCyan.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                            .clickable { onSelectPair(pair) }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = pair,
                                color = CyberCyan,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(Icons.Default.TrendingUp, contentDescription = null, tint = BullishGreen, modifier = Modifier.size(12.dp))
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Detailed Bengali Market Behavior
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(DarkNavyBg.copy(alpha = 0.6f))
                    .padding(10.dp)
            ) {
                Text(
                    text = "মার্কেট বৈশিষ্ট্য ও অনুকূল সময়:",
                    color = CryptoGold,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = session.marketBehaviorBn,
                    color = TextPrimary,
                    fontSize = 11.sp,
                    lineHeight = 16.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "ট্রেডিং পরামর্শ ও স্ট্র্যাটেজি টিপস:",
                    color = CyberCyan,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = session.tipsAndStrategyBn,
                    color = TextSecondary,
                    fontSize = 11.sp,
                    lineHeight = 16.sp
                )
            }
        }
    }
}

@Composable
fun PresetChip(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (isSelected) CyberCyan.copy(alpha = 0.2f) else CardSurface)
            .border(1.dp, if (isSelected) CyberCyan else CardBorder, RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Text(
            text = label,
            color = if (isSelected) CyberCyan else TextSecondary,
            fontSize = 11.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
        )
    }
}

@Composable
fun CategoryChip(
    label: String,
    isSelected: Boolean,
    badgeColor: Color,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(if (isSelected) badgeColor.copy(alpha = 0.2f) else CardSurface)
            .border(1.dp, if (isSelected) badgeColor else CardBorder, RoundedCornerShape(20.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        Text(
            text = label,
            color = if (isSelected) badgeColor else TextSecondary,
            fontSize = 12.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
        )
    }
}

@Composable
fun AssetRowCard(
    asset: TradingAsset,
    isWatched: Boolean,
    onToggleWatch: () -> Unit,
    onSelect: () -> Unit,
    onScanSignal: () -> Unit,
    onSetAlert: () -> Unit
) {
    val categoryColor = Color(asset.category.badgeColorHex)
    val isPositive = asset.change24h >= 0
    val changeColor = if (isPositive) BullishGreen else BearishRed

    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = CardSurface),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, CardBorder, RoundedCornerShape(12.dp))
            .clickable(onClick = onSelect)
            .testTag("asset_card_${asset.id}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Left: icon + symbol + badge + payout
            Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(categoryColor.copy(alpha = 0.15f))
                        .clickable(onClick = onToggleWatch),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isWatched) Icons.Default.Star else Icons.Default.StarBorder,
                        contentDescription = "Watchlist",
                        tint = if (isWatched) CryptoGold else categoryColor,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        StatusDot(asset.status)
                        Spacer(modifier = Modifier.width(5.dp))
                        Text(
                            text = asset.symbol,
                            color = TextPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(categoryColor.copy(alpha = 0.2f))
                                .padding(horizontal = 5.dp, vertical = 1.dp)
                        ) {
                            Text(
                                text = if (asset.isOtc) "OTC" else asset.category.displayName.take(5),
                                color = categoryColor,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    if (asset.payoutPercent > 0) {
                        Text(
                            text = "পে-আউট: ${asset.payoutPercent}%",
                            color = BullishGreen,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                    } else {
                        Text(
                            text = statusLabel(asset),
                            color = TextMuted,
                            fontSize = 10.sp
                        )
                    }
                }
            }

            // Right: live price, 24h change, alert + AI scan buttons
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = formatPrice(asset),
                        color = TextPrimary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    if (asset.hasPrice) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (isPositive) Icons.Default.ArrowUpward else Icons.Default.ArrowDownward,
                                contentDescription = null,
                                tint = changeColor,
                                modifier = Modifier.size(12.dp)
                            )
                            Text(
                                text = "${if (isPositive) "+" else ""}${String.format(Locale.US, "%.2f", asset.change24h)}%",
                                color = changeColor,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(CryptoGold.copy(alpha = 0.15f))
                        .border(1.dp, CryptoGold.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                        .clickable(onClick = onSetAlert)
                        .padding(horizontal = 7.dp, vertical = 6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.NotificationsActive,
                        contentDescription = "Set Alert",
                        tint = CryptoGold,
                        modifier = Modifier.size(14.dp)
                    )
                }

                Spacer(modifier = Modifier.width(6.dp))

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(CyberCyan.copy(alpha = 0.15f))
                        .border(1.dp, CyberCyan.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                        .clickable(onClick = onScanSignal)
                        .padding(horizontal = 8.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "AI BOT",
                        color = CyberCyan,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
