package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import android.webkit.WebView
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.AutoGraph
import androidx.compose.material.icons.filled.CandlestickChart
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DesktopMac
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.HasanProSignal
import com.example.model.ExpiryTime
import com.example.model.QuoteStatus
import com.example.model.SignalDirection
import com.example.model.SimulationTrade
import com.example.model.TradingAsset
import com.example.ui.ChartUi
import com.example.ui.TradeProViewModel
import com.example.ui.TradeResultUi
import com.example.ui.components.AssetPickerDialog
import com.example.ui.components.IQ_OPTION_URL
import com.example.ui.components.IqWebTerminal
import com.example.ui.components.StatusDot
import com.example.ui.components.TechnicalIndicatorsPanel
import com.example.ui.components.TradingChart
import com.example.ui.components.applyLayoutMode
import com.example.ui.components.formatPrice
import com.example.ui.components.marketColor
import com.example.ui.components.statusLabel
import com.example.ui.theme.BearishRed
import com.example.ui.theme.BullishGreen
import com.example.ui.theme.CardBorder
import com.example.ui.theme.CardSurface
import com.example.ui.theme.CardSurfaceElevated
import com.example.ui.theme.CryptoGold
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DarkNavyBg
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningYellow
import kotlinx.coroutines.delay
import java.util.Locale
import kotlin.math.abs

@Composable
private fun rememberNowMs(intervalMs: Long = 250L): Long {
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            delay(intervalMs)
        }
    }
    return now
}

/**
 * Terminal: real-price chart with the Hasan Pro Signal indicator, demo trading with live countdown,
 * and the full IQ Option web terminal (kept alive, fits the screen).
 */
@Composable
fun TerminalScreen(
    viewModel: TradeProViewModel,
    webView: WebView,
    modifier: Modifier = Modifier
) {
    val selectedAsset by viewModel.selectedAsset.collectAsState()
    val allAssets by viewModel.allAssets.collectAsState()
    val chartUi by viewModel.chartUi.collectAsState()
    val selectedTimeframe by viewModel.selectedTimeframe.collectAsState()
    val selectedExpiry by viewModel.selectedExpiry.collectAsState()
    val isCandleChart by viewModel.isCandleChart.collectAsState()
    val showIndicators by viewModel.showIndicators.collectAsState()
    val demoBalance by viewModel.demoBalance.collectAsState()
    val tradeAmount by viewModel.tradeAmount.collectAsState()
    val activeTrades by viewModel.activeTrades.collectAsState()
    val lastResult by viewModel.lastTradeResult.collectAsState()
    val immersive by viewModel.immersive.collectAsState()
    val watchlist by viewModel.watchlist.collectAsState()
    val health by viewModel.feedHealth.collectAsState()

    var showPicker by remember { mutableStateOf(false) }
    var showIq by remember { mutableStateOf(false) }
    var desktopMode by remember { mutableStateOf(false) }

    val asset = selectedAsset ?: return
    val context = LocalContext.current

    BackHandler(enabled = immersive || (showIq && webView.canGoBack())) {
        if (immersive) viewModel.setImmersive(false) else webView.goBack()
    }

    if (showPicker) {
        AssetPickerDialog(
            allAssets = allAssets,
            initialMarket = asset.marketType,
            onBrowse = { viewModel.marketEngine.setBrowsingMarket(it) },
            onDismiss = { showPicker = false },
            onSelect = {
                viewModel.selectAsset(it.id)
                showPicker = false
            }
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkNavyBg)
            .testTag("terminal_screen")
    ) {
        if (!(immersive && showIq)) {
            Column(modifier = Modifier.padding(horizontal = 12.dp)) {
                Spacer(modifier = Modifier.height(8.dp))
                HeaderBar(
                    asset = asset,
                    demoBalance = demoBalance,
                    isWatched = watchlist.contains(asset.id),
                    onPick = { showPicker = true },
                    onToggleWatch = { viewModel.toggleWatch(asset.id) }
                )
                Spacer(modifier = Modifier.height(6.dp))
                PriceHeader(asset = asset)
                Spacer(modifier = Modifier.height(6.dp))
                ModeSwitch(showIq = showIq, onChange = {
                    showIq = it
                    if (!it) viewModel.setImmersive(false)
                })
                Spacer(modifier = Modifier.height(6.dp))
            }
        }

        if (lastResult != null && !(immersive && showIq)) {
            Box(modifier = Modifier.padding(horizontal = 12.dp)) {
                ResultBanner(result = lastResult!!, onDismiss = { viewModel.dismissTradeResult() })
            }
            Spacer(modifier = Modifier.height(6.dp))
        }

        if (showIq) {
            // ------------------------------------------------------------ IQ Option web terminal
            Column(modifier = Modifier.weight(1f).fillMaxWidth()) {
                IqToolbar(
                    asset = asset,
                    state = chartUi,
                    immersive = immersive,
                    desktop = desktopMode,
                    onFullscreen = { viewModel.setImmersive(!immersive) },
                    onLayout = {
                        desktopMode = !desktopMode
                        webView.applyLayoutMode(desktopMode)
                    },
                    onReload = { webView.reload() },
                    onBrowser = {
                        try {
                            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(IQ_OPTION_URL)))
                        } catch (e: Exception) {
                        }
                    }
                )
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .imePadding()
                ) {
                    IqWebTerminal(webView = webView)
                }
            }
        } else {
            // ------------------------------------------------------------ app chart + demo trading
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 12.dp)
            ) {
                ChartToolbar(
                    isCandleChart = isCandleChart,
                    showIndicators = showIndicators,
                    onToggleChart = { viewModel.toggleChartType() },
                    onToggleIndicators = { viewModel.toggleIndicators() },
                    onAlert = { viewModel.navigateToAlertsForAsset(asset.id) }
                )
                Spacer(modifier = Modifier.height(6.dp))

                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                    items(ExpiryTime.values().toList()) { tf ->
                        Chip(label = tf.label, selected = tf == selectedTimeframe) { viewModel.setTimeframe(tf) }
                    }
                }
                Text(
                    text = "ক্যান্ডেল টাইমফ্রেম (চার্ট)",
                    color = TextMuted,
                    fontSize = 9.sp,
                    modifier = Modifier.padding(top = 2.dp, bottom = 6.dp)
                )

                TradingChart(
                    candles = chartUi.candles,
                    currentPrice = asset.currentPrice,
                    isCandleChart = isCandleChart,
                    showIndicators = showIndicators,
                    hasan = chartUi.hasan,
                    priceDecimals = asset.priceDecimals,
                    candleSeconds = selectedTimeframe.seconds,
                    emptyText = when {
                        asset.status == QuoteStatus.NO_FEED -> "এই অ্যাসেটের জন্য কোনো পাবলিক রিয়েল প্রাইস ফিড নেই"
                        chartUi.warmingUp || selectedTimeframe.seconds < 60 -> "লাইভ টিক থেকে ${selectedTimeframe.label} ক্যান্ডেল তৈরি হচ্ছে..."
                        else -> "রিয়েল মার্কেট ডাটা লোড হচ্ছে..."
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(300.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .border(1.dp, CardBorder, RoundedCornerShape(12.dp))
                )

                if (chartUi.warmingUp && chartUi.candles.isNotEmpty()) {
                    Text(
                        text = "⏳ ${selectedTimeframe.label} ক্যান্ডেল লাইভ টিক থেকে জমছে — ইন্ডিকেটরের জন্য কিছুক্ষণ সময় লাগবে।",
                        color = WarningYellow,
                        fontSize = 10.sp,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))
                HasanCard(state = chartUi, timeframeLabel = selectedTimeframe.label)
                Spacer(modifier = Modifier.height(6.dp))
                FeedStatusLine(binanceAge = health.binanceAgeSec, yahooAge = health.yahooAgeSec, backoff = health.yahooBackoff)

                Spacer(modifier = Modifier.height(10.dp))

                if (activeTrades.isNotEmpty()) {
                    Text(
                        text = "সক্রিয় ডেমো ট্রেড (লাইভ কাউন্টডাউন)",
                        color = CryptoGold,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    val nowMs = rememberNowMs()
                    val byId = allAssets.associateBy { it.id }
                    activeTrades.forEach { trade ->
                        ActiveTradeCard(trade = trade, live = byId[trade.assetId], nowMs = nowMs)
                        Spacer(modifier = Modifier.height(6.dp))
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                }

                TradePanel(
                    asset = asset,
                    amount = tradeAmount,
                    expiry = selectedExpiry,
                    onAmount = { viewModel.setTradeAmount(it) },
                    onExpiry = { viewModel.setExpiry(it) },
                    onTrade = { viewModel.executeTrade(it) }
                )

                Spacer(modifier = Modifier.height(10.dp))
                TechnicalIndicatorsPanel(indicators = chartUi.indicators)
                Spacer(modifier = Modifier.height(90.dp))
            }
        }
    }

}

// ============================================================================================
// Header pieces
// ============================================================================================

@Composable
private fun HeaderBar(
    asset: TradingAsset,
    demoBalance: Double,
    isWatched: Boolean,
    onPick: () -> Unit,
    onToggleWatch: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            modifier = Modifier
                .weight(1f)
                .clip(RoundedCornerShape(10.dp))
                .background(CardSurface)
                .border(1.dp, marketColor(asset.marketType).copy(alpha = 0.6f), RoundedCornerShape(10.dp))
                .clickable(onClick = onPick)
                .padding(horizontal = 10.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            StatusDot(asset.status)
            Spacer(modifier = Modifier.width(8.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(asset.symbol, color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                Text(
                    text = asset.marketType.displayName + if (asset.payoutPercent > 0) "  •  +${asset.payoutPercent}%" else "  •  Margin CFD",
                    color = marketColor(asset.marketType),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Icon(Icons.Default.ArrowDropDown, contentDescription = "Select asset", tint = TextSecondary)
        }
        Spacer(modifier = Modifier.width(6.dp))
        IconButton(
            onClick = onToggleWatch,
            modifier = Modifier
                .size(38.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(CardSurface)
        ) {
            Icon(
                imageVector = if (isWatched) Icons.Default.Star else Icons.Default.StarBorder,
                contentDescription = "Watch",
                tint = if (isWatched) CryptoGold else TextSecondary,
                modifier = Modifier.size(20.dp)
            )
        }
        Spacer(modifier = Modifier.width(6.dp))
        Column(
            modifier = Modifier
                .clip(RoundedCornerShape(10.dp))
                .background(CardSurface)
                .border(1.dp, CardBorder, RoundedCornerShape(10.dp))
                .padding(horizontal = 10.dp, vertical = 5.dp),
            horizontalAlignment = Alignment.End
        ) {
            Text("DEMO", color = TextMuted, fontSize = 9.sp)
            Text(
                text = "$" + String.format(Locale.US, "%,.0f", demoBalance),
                color = BullishGreen,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun PriceHeader(asset: TradingAsset) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = formatPrice(asset),
                color = if (!asset.hasPrice) TextMuted else if (asset.isUp) BullishGreen else BearishRed,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.width(8.dp))
            if (asset.hasPrice) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background((if (asset.change24h >= 0) BullishGreen else BearishRed).copy(alpha = 0.15f))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = String.format(Locale.US, "%+.2f%%", asset.change24h),
                        color = if (asset.change24h >= 0) BullishGreen else BearishRed,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
            Spacer(modifier = Modifier.width(8.dp))
            val live = asset.status == QuoteStatus.LIVE
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background((if (live) BullishGreen else CryptoGold).copy(alpha = 0.15f))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = statusLabel(asset),
                    color = if (live) BullishGreen else CryptoGold,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
        Text(
            text = asset.name + sourceNote(asset),
            color = TextMuted,
            fontSize = 10.sp,
            maxLines = 1
        )
        if (asset.hasPrice) {
            Text(
                text = "H ${String.format(Locale.US, "%.${asset.priceDecimals}f", asset.high24h)}   " +
                    "L ${String.format(Locale.US, "%.${asset.priceDecimals}f", asset.low24h)}",
                color = TextMuted,
                fontSize = 10.sp
            )
        }
        val note = when {
            asset.status == QuoteStatus.NO_FEED ->
                "⚠ এই অ্যাসেট IQ Option-এর নিজস্ব ইনডেক্স; কোনো পাবলিক রিয়েল প্রাইস ফিড নেই।"
            asset.isOtc ->
                "ℹ OTC: IQ Option-এর OTC দাম ব্রোকার নিজে বানায়। এখানে আসল মার্কেটের দাম (রেফারেন্স) দেখানো হচ্ছে।"
            asset.status == QuoteStatus.STALE ->
                "ℹ আসল মার্কেট এখন বন্ধ বা ডাটা বিলম্বিত। IQ Option-এ তখন OTC অ্যাসেট চালু থাকে।"
            else -> null
        }
        if (note != null) {
            Text(text = note, color = WarningYellow, fontSize = 10.sp, modifier = Modifier.padding(top = 2.dp))
        }
    }
}

private fun sourceNote(asset: TradingAsset): String = when (asset.feed.source) {
    com.example.model.FeedSource.BINANCE -> " • Binance real-time"
    com.example.model.FeedSource.YAHOO -> " • Yahoo Finance"
    com.example.model.FeedSource.DERIVED -> " • real ratio"
    com.example.model.FeedSource.NONE -> ""
}

@Composable
private fun ModeSwitch(showIq: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(CardSurface)
            .padding(3.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        ModeButton("📊 অ্যাপ চার্ট + সিগন্যাল", !showIq, Modifier.weight(1f)) { onChange(false) }
        ModeButton("🌐 IQ Option টার্মিনাল", showIq, Modifier.weight(1f)) { onChange(true) }
    }
}

@Composable
private fun ModeButton(label: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (selected) CyberCyan.copy(alpha = 0.2f) else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(vertical = 9.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = if (selected) CyberCyan else TextSecondary,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
private fun Chip(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (selected) CyberCyan.copy(alpha = 0.2f) else CardSurface)
            .border(1.dp, if (selected) CyberCyan else CardBorder, RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Text(
            text = label,
            color = if (selected) CyberCyan else TextSecondary,
            fontSize = 12.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
        )
    }
}

@Composable
private fun ChartToolbar(
    isCandleChart: Boolean,
    showIndicators: Boolean,
    onToggleChart: () -> Unit,
    onToggleIndicators: () -> Unit,
    onAlert: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.End,
        verticalAlignment = Alignment.CenterVertically
    ) {
        SmallIcon(
            icon = if (isCandleChart) Icons.Default.CandlestickChart else Icons.Default.ShowChart,
            tint = if (isCandleChart) CyberCyan else TextSecondary,
            active = isCandleChart,
            onClick = onToggleChart
        )
        Spacer(modifier = Modifier.width(6.dp))
        SmallIcon(Icons.Default.AutoGraph, if (showIndicators) CryptoGold else TextSecondary, showIndicators, onToggleIndicators)
        Spacer(modifier = Modifier.width(6.dp))
        SmallIcon(Icons.Default.NotificationsActive, CryptoGold, false, onAlert)
    }
}

@Composable
private fun SmallIcon(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    tint: Color,
    active: Boolean,
    onClick: () -> Unit
) {
    IconButton(
        onClick = onClick,
        modifier = Modifier
            .size(34.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(if (active) tint.copy(alpha = 0.2f) else CardSurface)
    ) {
        Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(18.dp))
    }
}

// ============================================================================================
// Hasan Pro Signal card + feed status
// ============================================================================================

private fun signalColor(code: Int): Color = when (code) {
    HasanProSignal.UP_PLUS -> BullishGreen
    HasanProSignal.DOWN_PLUS -> BearishRed
    HasanProSignal.UP_POSSIBLE, HasanProSignal.DOWN_POSSIBLE -> WarningYellow
    else -> TextMuted
}

private fun signalText(code: Int): String = when (code) {
    HasanProSignal.UP_PLUS -> "▲ UP+  (শক্তিশালী CALL / Higher)"
    HasanProSignal.DOWN_PLUS -> "▼ DOWN+  (শক্তিশালী PUT / Lower)"
    HasanProSignal.UP_POSSIBLE -> "△ UP?  (সম্ভাব্য CALL)"
    HasanProSignal.DOWN_POSSIBLE -> "▽ DOWN?  (সম্ভাব্য PUT)"
    else -> "⏸ WAIT — কোনো সেটআপ নেই"
}

@Composable
private fun HasanCard(state: ChartUi, timeframeLabel: String) {
    val s = state.hasanState
    val color = signalColor(s.code)
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(CardSurface)
            .border(1.dp, color.copy(alpha = 0.6f), RoundedCornerShape(12.dp))
            .padding(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("HASAN PRO SIGNAL • $timeframeLabel", color = TextSecondary, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.8.sp)
            if (s.hasSignal) {
                Text("স্ট্রেংথ ${s.strength}/100", color = color, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(signalText(s.code), color = color, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold)
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "RSI(21) ${String.format(Locale.US, "%.1f", s.rsi)}  •  সর্বশেষ ক্লোজড ক্যান্ডেলের ভিত্তিতে (repaint হয় না)",
            color = TextMuted,
            fontSize = 10.sp
        )
        Text(
            text = "স্ট্রেংথ হলো নিয়ম মেলার স্কোর, জেতার সম্ভাবনা নয়। কোনো সিগন্যালই লাভের নিশ্চয়তা দেয় না।",
            color = TextMuted,
            fontSize = 9.sp
        )
    }
}

@Composable
private fun FeedStatusLine(binanceAge: Long, yahooAge: Long, backoff: Boolean) {
    fun part(name: String, age: Long): String = if (age < 0) "$name: —" else "$name: ${age}s"
    val ok = (binanceAge in 0..15) || (yahooAge in 0..15)
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(7.dp)
                .clip(RoundedCornerShape(50))
                .background(if (ok) BullishGreen else CryptoGold)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = "ফিড: " + part("Binance", binanceAge) + "  •  " + part("Yahoo", yahooAge) +
                if (backoff) "  •  রেট-লিমিট: অপেক্ষা" else "",
            color = TextMuted,
            fontSize = 10.sp
        )
    }
}

// ============================================================================================
// IQ Option web terminal toolbar
// ============================================================================================

@Composable
private fun IqToolbar(
    asset: TradingAsset,
    state: ChartUi,
    immersive: Boolean,
    desktop: Boolean,
    onFullscreen: () -> Unit,
    onLayout: () -> Unit,
    onReload: () -> Unit,
    onBrowser: () -> Unit
) {
    val s = state.hasanState
    val color = signalColor(s.code)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(CardSurfaceElevated)
            .padding(horizontal = 10.dp, vertical = 5.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = asset.symbol + "  " + formatPrice(asset),
                color = if (asset.isUp) BullishGreen else BearishRed,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1
            )
            Text(
                text = "Hasan: " + HasanProSignal.labelOf(s.code) + if (s.hasSignal) "  (${s.strength})" else "",
                color = color,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }
        SmallIconPlain(if (immersive) Icons.Default.FullscreenExit else Icons.Default.Fullscreen, CryptoGold, onFullscreen)
        SmallIconPlain(if (desktop) Icons.Default.DesktopMac else Icons.Default.PhoneAndroid, CyberCyan, onLayout)
        SmallIconPlain(Icons.Default.Refresh, TextSecondary, onReload)
        SmallIconPlain(Icons.Default.OpenInNew, CyberCyan, onBrowser)
    }
}

@Composable
private fun SmallIconPlain(icon: androidx.compose.ui.graphics.vector.ImageVector, tint: Color, onClick: () -> Unit) {
    IconButton(onClick = onClick, modifier = Modifier.size(34.dp)) {
        Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(18.dp))
    }
}

// ============================================================================================
// Demo trading
// ============================================================================================

@Composable
private fun TradePanel(
    asset: TradingAsset,
    amount: Double,
    expiry: ExpiryTime,
    onAmount: (Double) -> Unit,
    onExpiry: (ExpiryTime) -> Unit,
    onTrade: (SignalDirection) -> Unit
) {
    val payout = if (asset.payoutPercent > 0) asset.payoutPercent else 85
    val enabled = asset.hasPrice
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(CardSurface)
            .border(1.dp, CardBorder, RoundedCornerShape(12.dp))
            .padding(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("ডেমো ট্রেড (আসল প্রাইসে)", color = TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Text(
                text = "Expected +$payout% (+$${String.format(Locale.US, "%.2f", amount * payout / 100.0)})",
                color = BullishGreen,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text("এক্সপায়ারি (Time)", color = TextMuted, fontSize = 10.sp)
        Spacer(modifier = Modifier.height(4.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
            items(ExpiryTime.values().toList()) { e ->
                Chip(label = e.label, selected = e == expiry) { onExpiry(e) }
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text("পরিমাণ (Amount $)", color = TextMuted, fontSize = 10.sp)
        Spacer(modifier = Modifier.height(4.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
            items(listOf(1.0, 5.0, 10.0, 25.0, 50.0, 100.0, 250.0)) { amt ->
                Chip(label = "$" + amt.toInt(), selected = amt == amount) { onAmount(amt) }
            }
        }
        Spacer(modifier = Modifier.height(12.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(
                onClick = { onTrade(SignalDirection.PUT) },
                enabled = enabled,
                colors = ButtonDefaults.buttonColors(containerColor = BearishRed, disabledContainerColor = CardSurfaceElevated),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(50.dp)
                    .testTag("terminal_put_button")
            ) {
                Icon(Icons.Default.ArrowDownward, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Column {
                    Text("Lower", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text("PUT • ${expiry.label}", color = Color.White.copy(alpha = 0.8f), fontSize = 9.sp)
                }
            }
            Button(
                onClick = { onTrade(SignalDirection.CALL) },
                enabled = enabled,
                colors = ButtonDefaults.buttonColors(containerColor = BullishGreen, disabledContainerColor = CardSurfaceElevated),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(50.dp)
                    .testTag("terminal_call_button")
            ) {
                Icon(Icons.Default.ArrowUpward, contentDescription = null, tint = Color.Black, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Column {
                    Text("Higher", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text("CALL • ${expiry.label}", color = Color.Black.copy(alpha = 0.8f), fontSize = 9.sp)
                }
            }
        }
        if (!enabled) {
            Text(
                text = "রিয়েল প্রাইস না আসা পর্যন্ত ট্রেড বন্ধ।",
                color = WarningYellow,
                fontSize = 10.sp,
                modifier = Modifier.padding(top = 6.dp)
            )
        }
    }
}

@Composable
private fun ActiveTradeCard(trade: SimulationTrade, live: TradingAsset?, nowMs: Long) {
    val isCall = trade.direction == SignalDirection.CALL
    val dirColor = if (isCall) BullishGreen else BearishRed
    val total = (trade.closeTime - trade.openTime).coerceAtLeast(1L)
    val remaining = (trade.closeTime - nowMs).coerceAtLeast(0L)
    val progress = (1f - remaining.toFloat() / total.toFloat()).coerceIn(0f, 1f)
    val dec = live?.priceDecimals ?: 5
    val price = live?.currentPrice ?: trade.entryPrice
    val winning = if (isCall) price > trade.entryPrice else price < trade.entryPrice
    val losing = if (isCall) price < trade.entryPrice else price > trade.entryPrice
    val stateColor = when {
        winning -> BullishGreen
        losing -> BearishRed
        else -> TextSecondary
    }
    val stateText = when {
        winning -> "এখন জিতছে ✔ +$" + String.format(Locale.US, "%.2f", trade.investment * trade.payoutPercent / 100.0)
        losing -> "এখন হারছে ✘ -$" + String.format(Locale.US, "%.2f", trade.investment)
        else -> "সমান (Tie)"
    }
    val sec = (remaining / 1000L).toInt()
    val timeText = if (sec >= 60) String.format(Locale.US, "%d:%02d", sec / 60, sec % 60) else "${sec}s"

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(CardSurface)
            .border(1.dp, stateColor.copy(alpha = 0.6f), RoundedCornerShape(10.dp))
            .padding(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = if (isCall) Icons.Default.ArrowUpward else Icons.Default.ArrowDownward,
                    contentDescription = null,
                    tint = dirColor,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Column {
                    Text("${trade.assetSymbol} • ${if (isCall) "Higher" else "Lower"}", color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text(
                        "Entry ${String.format(Locale.US, "%.${dec}f", trade.entryPrice)} → Now ${String.format(Locale.US, "%.${dec}f", price)}",
                        color = TextMuted,
                        fontSize = 10.sp
                    )
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Timer, contentDescription = null, tint = CryptoGold, modifier = Modifier.size(15.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(timeText, color = CryptoGold, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        }
        Spacer(modifier = Modifier.height(6.dp))
        LinearProgressIndicator(
            progress = { progress },
            color = stateColor,
            trackColor = CardSurfaceElevated,
            modifier = Modifier.fillMaxWidth().height(4.dp)
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "$stateText  •  Inv $" + trade.investment.toInt(),
            color = stateColor,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
private fun ResultBanner(result: TradeResultUi, onDismiss: () -> Unit) {
    LaunchedEffect(result) {
        delay(9000L)
        onDismiss()
    }
    val color = if (result.isTie) TextSecondary else if (result.isWin) BullishGreen else BearishRed
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(color.copy(alpha = 0.15f))
            .border(1.dp, color, RoundedCornerShape(10.dp))
            .padding(horizontal = 12.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = if (result.isTie) "TIE  $0.00 (স্টেক ফেরত)"
                else (if (result.isWin) "WIN  +$" else "LOSS  -$") + String.format(Locale.US, "%.2f", kotlin.math.abs(result.profit)),
                color = color,
                fontSize = 15.sp,
                fontWeight = FontWeight.ExtraBold
            )
            Text(
                text = "${result.assetSymbol} ${if (result.direction == SignalDirection.CALL) "Higher" else "Lower"} • " +
                    "${String.format(Locale.US, "%.${result.decimals}f", result.entryPrice)} → " +
                    String.format(Locale.US, "%.${result.decimals}f", result.exitPrice),
                color = TextSecondary,
                fontSize = 10.sp
            )
        }
        IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
            Icon(Icons.Default.Close, contentDescription = "Dismiss", tint = TextSecondary, modifier = Modifier.size(16.dp))
        }
    }
}
