package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.database.SignalEntity
import com.example.model.ExpiryTime
import com.example.model.SignalDirection
import com.example.model.TradingSignal
import com.example.ui.TradeProViewModel
import com.example.ui.theme.BearishRed
import com.example.ui.theme.BullishGreen
import com.example.ui.theme.CardBorder
import com.example.ui.theme.CardSurface
import com.example.ui.theme.CardSurfaceElevated
import com.example.ui.theme.CryptoGold
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DarkNavyBg
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun SignalBotScreen(
    viewModel: TradeProViewModel,
    modifier: Modifier = Modifier
) {
    val selectedAsset by viewModel.selectedAsset.collectAsState()
    val allAssets by viewModel.allAssets.collectAsState()
    val selectedTimeframe by viewModel.selectedExpiry.collectAsState()
    val isGenerating by viewModel.isGeneratingSignal.collectAsState()
    val activeSignal by viewModel.activeSignal.collectAsState()
    val savedSignals by viewModel.savedSignals.collectAsState()

    var assetMenuExpanded by remember { mutableStateOf(false) }

    val asset = selectedAsset ?: return
    val scrollState = rememberScrollState()
    var signalScreenTab by remember { mutableStateOf("LIVE") } // "LIVE", "SCRIPTS", "HISTORY"

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkNavyBg)
            .verticalScroll(scrollState)
            .padding(horizontal = 14.dp)
            .testTag("signal_bot_screen")
    ) {
        Spacer(modifier = Modifier.height(12.dp))

        // Hero Title Banner
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(
                    Brush.horizontalGradient(
                        listOf(CyberCyan.copy(alpha = 0.15f), CardSurface)
                    )
                )
                .border(1.dp, CyberCyan.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(CyberCyan.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(20.dp))
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = "IQ OPTION AI SIGNALS & BOT",
                    color = CyberCyan,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "১ মিনিট ও ৫ মিনিট অপশনের জন্য নিবেদিত এআই অ্যালগরিদম",
                    color = TextSecondary,
                    fontSize = 11.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Sub-Tab Switcher
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(CardSurface)
                .border(1.dp, CardBorder, RoundedCornerShape(10.dp))
                .padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (signalScreenTab == "LIVE") CyberCyan else Color.Transparent)
                    .clickable { signalScreenTab = "LIVE" }
                    .padding(vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "এআই সিগন্যাল",
                    color = if (signalScreenTab == "LIVE") DarkNavyBg else TextSecondary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Box(
                modifier = Modifier
                    .weight(1.3f)
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (signalScreenTab == "SCRIPTS") CyberCyan else Color.Transparent)
                    .clickable { signalScreenTab = "SCRIPTS" }
                    .padding(vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "ট্রেডিং স্ক্রিপ্ট ও কৌশল",
                    color = if (signalScreenTab == "SCRIPTS") DarkNavyBg else TextSecondary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Box(
                modifier = Modifier
                    .weight(0.9f)
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (signalScreenTab == "HISTORY") CyberCyan else Color.Transparent)
                    .clickable { signalScreenTab = "HISTORY" }
                    .padding(vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "ইতিহাস",
                    color = if (signalScreenTab == "HISTORY") DarkNavyBg else TextSecondary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (signalScreenTab == "SCRIPTS") {
            TradingScriptsTab()
            Spacer(modifier = Modifier.height(80.dp))
        } else if (signalScreenTab == "HISTORY") {
            Text(
                text = "সংরক্ষিত সিগন্যাল ইতিহাস (${savedSignals.size})",
                color = TextSecondary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp
            )
            Spacer(modifier = Modifier.height(8.dp))
            if (savedSignals.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(CardSurface)
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("এখনও কোনো সিগন্যাল সংরক্ষিত হয়নি।", color = TextMuted, fontSize = 12.sp)
                }
            } else {
                savedSignals.forEach { signal ->
                    SavedSignalItem(signal = signal)
                    Spacer(modifier = Modifier.height(6.dp))
                }
            }
            Spacer(modifier = Modifier.height(80.dp))
        } else {
            // ==========================================
            // LIVE SIGNAL GENERATION VIEW (IQ Option)
            // ==========================================
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Target Asset Selector
                Box(modifier = Modifier.weight(1f)) {
                    Column {
                        Text("TARGET ASSET", color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(3.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(CardSurface)
                                .border(1.dp, CardBorder, RoundedCornerShape(8.dp))
                                .clickable { assetMenuExpanded = true }
                                .padding(horizontal = 10.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(asset.symbol, color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(16.dp))
                        }
                    }

                    DropdownMenu(
                        expanded = assetMenuExpanded,
                        onDismissRequest = { assetMenuExpanded = false },
                        modifier = Modifier.background(CardSurfaceElevated)
                    ) {
                        allAssets.forEach { a ->
                            DropdownMenuItem(
                                text = {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(a.symbol, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                        Text("${a.payoutPercent}%", color = BullishGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                },
                                onClick = {
                                    viewModel.selectAsset(a.id)
                                    assetMenuExpanded = false
                                }
                            )
                        }
                    }
                }

                // Fixed IQ Option platform header (no dropdown)
                Box(modifier = Modifier.weight(1f)) {
                    Column {
                        Text("PLATFORM PORTAL", color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(3.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(CyberCyan.copy(alpha = 0.12f))
                                .border(1.dp, CyberCyan.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                                .padding(horizontal = 10.dp, vertical = 9.dp),
                            horizontalArrangement = Arrangement.Start,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(7.dp)
                                    .clip(CircleShape)
                                    .background(BullishGreen)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("IQ Option", color = CyberCyan, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Live real-market price bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(CardSurface)
                    .border(1.dp, CardBorder, RoundedCornerShape(8.dp))
                    .padding(horizontal = 10.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("লাইভ মার্কেট প্রাইস (${asset.symbol})", color = TextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(2.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = com.example.ui.components.formatPrice(asset),
                            color = if (asset.isUp) BullishGreen else BearishRed,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        com.example.ui.components.StatusDot(asset.status)
                    }
                }

                Text(
                    text = com.example.ui.components.statusLabel(asset),
                    color = TextMuted,
                    fontSize = 10.sp
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Trade expiry selector
            Column {
                Text("EXPIRATION TIMEFRAME", color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(ExpiryTime.values()) { expiry ->
                        val isSel = selectedTimeframe == expiry
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSel) CyberCyan.copy(alpha = 0.2f) else CardSurface)
                                .border(1.dp, if (isSel) CyberCyan else CardBorder, RoundedCornerShape(8.dp))
                            .clickable { viewModel.setExpiry(expiry) }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = expiry.label,
                                color = if (isSel) CyberCyan else TextSecondary,
                                fontSize = 11.sp,
                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Main Action Button: GENERATE AI SIGNAL
            Button(
                onClick = { viewModel.generateSignalForSelectedAsset() },
                colors = ButtonDefaults.buttonColors(containerColor = CyberCyan),
                shape = RoundedCornerShape(12.dp),
                enabled = !isGenerating,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("generate_signal_button")
            ) {
                if (isGenerating) {
                    CircularProgressIndicator(
                        color = DarkNavyBg,
                        strokeWidth = 2.5.dp,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Hasan Pro Signal স্ক্যান করা হচ্ছে...",
                        color = DarkNavyBg,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                } else {
                    Icon(Icons.Default.FlashOn, contentDescription = null, tint = DarkNavyBg, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "GENERATE AI SIGNAL (${asset.symbol})",
                        color = DarkNavyBg,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Active Generated Signal Card
            activeSignal?.let { signal ->
                SignalResultCard(
                    signal = signal,
                    decimals = asset.priceDecimals,
                    onTradeNow = {
                        viewModel.executeTrade(signal.direction)
                    }
                )
                Spacer(modifier = Modifier.height(14.dp))
            }

            // Recent Signal History
            Text(
                text = "সাম্প্রতিক তৈরি হওয়া সিগন্যালসমূহ",
                color = TextSecondary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )

            Spacer(modifier = Modifier.height(8.dp))

            if (savedSignals.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(CardSurface)
                        .border(1.dp, CardBorder, RoundedCornerShape(8.dp))
                        .padding(20.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "এখনও কোনো সিগন্যাল তৈরি হয়নি। উপরে 'GENERATE AI SIGNAL' চাপুন।",
                        color = TextMuted,
                        fontSize = 12.sp
                    )
                }
            } else {
                savedSignals.take(4).forEach { sig ->
                    SavedSignalItem(signal = sig)
                    Spacer(modifier = Modifier.height(6.dp))
                }
            }
            Spacer(modifier = Modifier.height(80.dp))
        }
    }
}

@Composable
fun SignalResultCard(
    signal: TradingSignal,
    decimals: Int,
    onTradeNow: () -> Unit
) {
    val isCall = signal.direction == SignalDirection.CALL
    val actionColor = if (signal.isWait) CryptoGold else if (isCall) BullishGreen else BearishRed

    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = CardSurface),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.5.dp, actionColor.copy(alpha = 0.8f), RoundedCornerShape(14.dp))
            .testTag("signal_result_card")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // WAIT banner: the indicator shows no setup on the last closed candle
            if (signal.isWait) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(CryptoGold.copy(alpha = 0.18f))
                        .border(1.dp, CryptoGold.copy(alpha = 0.6f), RoundedCornerShape(8.dp))
                        .padding(horizontal = 10.dp, vertical = 8.dp)
                        .testTag("signal_wait_banner"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "⏸ WAIT — এখন কোনো সেটআপ নেই, ট্রেড করবেন না",
                        color = CryptoGold,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
            }

            // Signal Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(actionColor.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isCall) Icons.Default.ArrowUpward else Icons.Default.ArrowDownward,
                            contentDescription = signal.direction.label,
                            tint = actionColor,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "${signal.direction.label} • ${if (isCall) "ক্রয় (BUY UP)" else "বিক্রয় (SELL DOWN)"}",
                            color = actionColor,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            text = "${signal.assetSymbol} • IQ Option",
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    }
                }

                // Confidence Meter
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(actionColor.copy(alpha = 0.15f))
                        .border(1.dp, actionColor.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "সেটআপ স্ট্রেংথ ${signal.confidence}%",
                        color = actionColor,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Strategy Confluence
            Text(
                text = "কৌশল: ${signal.strategyName}",
                color = CyberCyan,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Details Grid
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                InfoBox(label = "স্ট্রাইক মূল্য", value = String.format(Locale.US, "%.${decimals}f", signal.strikePrice), modifier = Modifier.weight(1.2f))
                InfoBox(label = "মেয়াদকাল", value = signal.expiryTime.label, modifier = Modifier.weight(1f))
                InfoBox(label = "RSI (21)", value = String.format(Locale.US, "%.1f", signal.rsiValue), modifier = Modifier.weight(0.8f))
            }

            Spacer(modifier = Modifier.height(10.dp))

            if (!signal.isWait) {
            // Martingale Risk Plan
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(CardSurfaceElevated)
                    .padding(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("মার্টিঙ্গেল রিকভারি প্ল্যান", color = TextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    Text("Safe 2-Step", color = CryptoGold, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("প্রাথমিক: $10.00", color = TextPrimary, fontSize = 11.sp)
                    Text("ধাপ ১: $${signal.martingaleStep1}", color = CryptoGold, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    Text("ধাপ ২: $${signal.martingaleStep2}", color = BearishRed, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Quick Execution Button
            Button(
                onClick = onTradeNow,
                colors = ButtonDefaults.buttonColors(containerColor = actionColor),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(44.dp)
            ) {
                Text(
                    text = "ডেমো ট্রেড করুন (IQ Option)",
                    color = if (isCall) Color.Black else Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "সেটআপ স্ট্রেংথ নিয়ম মেলার স্কোর, জেতার সম্ভাবনা নয়।",
                color = TextMuted,
                fontSize = 9.sp
            )
        }
    }
}

@Composable
fun InfoBox(label: String, value: String, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(CardSurfaceElevated)
            .padding(6.dp)
    ) {
        Column {
            Text(label, color = TextMuted, fontSize = 8.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(1.dp))
            Text(value, color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        }
    }
}

@Composable
fun SavedSignalItem(signal: SignalEntity) {
    val isCall = signal.direction == "CALL"
    val color = if (isCall) BullishGreen else BearishRed
    val dateFormat = remember { SimpleDateFormat("HH:mm:ss", Locale.getDefault()) }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(CardSurface)
            .border(1.dp, CardBorder, RoundedCornerShape(8.dp))
            .padding(horizontal = 10.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = if (isCall) Icons.Default.ArrowUpward else Icons.Default.ArrowDownward,
                contentDescription = null,
                tint = color,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = "${signal.assetSymbol} ${signal.direction} (স্ট্রেংথ ${signal.confidence}%)",
                    color = TextPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "${signal.strategyName} • ${signal.platformName}",
                    color = TextMuted,
                    fontSize = 10.sp
                )
            }
        }

        Text(
            text = dateFormat.format(Date(signal.timestamp)),
            color = TextSecondary,
            fontSize = 10.sp
        )
    }
}
