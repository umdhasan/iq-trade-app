package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.database.AlertNotificationEntity
import com.example.database.AlertRuleEntity
import com.example.database.SignalEntity
import com.example.database.TradeEntity
import com.example.database.TradeProDatabase
import com.example.engine.AlertEngine
import com.example.engine.AlertSoundManager
import com.example.engine.ChartData
import com.example.engine.FeedHealth
import com.example.engine.HasanProSignal
import com.example.engine.MarketEngine
import com.example.engine.SignalEngine
import com.example.engine.TechnicalAnalysisEngine
import com.example.model.AlertNotification
import com.example.model.AlertRule
import com.example.model.AlertType
import com.example.model.ExpiryTime
import com.example.model.MarketCategory
import com.example.model.MarketPlatform
import com.example.model.MarketType
import com.example.model.SignalDirection
import com.example.model.SignalOutcome
import com.example.model.SimulationTrade
import com.example.model.TechnicalIndicators
import com.example.model.TradingAsset
import com.example.model.TradingSignal
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID

/** Everything the chart needs: visible candles + Hasan Pro Signal series + state of the last closed candle. */
data class ChartUi(
    val candles: List<com.example.model.Candle> = emptyList(),
    val hasan: HasanProSignal.Series? = null,
    val hasanState: HasanProSignal.State = HasanProSignal.State(HasanProSignal.NONE, "WAIT", 50.0, 0.0, 0.0, 0, -1),
    val indicators: TechnicalIndicators = TechnicalAnalysisEngine.analyze(emptyList()),
    val warmingUp: Boolean = false
)

data class TradeResultUi(
    val assetSymbol: String,
    val direction: SignalDirection,
    val entryPrice: Double,
    val exitPrice: Double,
    val profit: Double,
    val isWin: Boolean,
    val decimals: Int,
    val isTie: Boolean = false
)

enum class NavigationTab(val title: String) {
    MARKETS("Markets"),
    TERMINAL("Terminal"),
    SIGNALS("AI Bot"),
    ALERTS("Alerts"),
    JOURNAL("Journal")
}

class TradeProViewModel(application: Application) : AndroidViewModel(application) {

    private val db = TradeProDatabase.getDatabase(application)
    val soundManager = AlertSoundManager(application)
    val marketEngine = MarketEngine(viewModelScope)
    val alertEngine = AlertEngine(viewModelScope, db.alertDao(), marketEngine, soundManager)

    // Navigation
    private val _currentTab = MutableStateFlow(NavigationTab.TERMINAL)
    val currentTab: StateFlow<NavigationTab> = _currentTab.asStateFlow()

    // Market Filtering
    private val _selectedCategory = MutableStateFlow<MarketCategory?>(null) // null = ALL
    val selectedCategory: StateFlow<MarketCategory?> = _selectedCategory.asStateFlow()

    private val _selectedMarket = MutableStateFlow(MarketType.BLITZ)
    val selectedMarket: StateFlow<MarketType> = _selectedMarket.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    // Terminal & Chart State
    val selectedAssetId: StateFlow<String> = marketEngine.selectedAssetId
    val allAssets: StateFlow<List<TradingAsset>> = marketEngine.assets

    val selectedAsset: StateFlow<TradingAsset?> = combine(allAssets, selectedAssetId) { assets, id ->
        assets.firstOrNull { it.id == id } ?: assets.firstOrNull()
    }.stateIn(viewModelScope, SharingStarted.Eagerly, null)

    private val _selectedTimeframe = MutableStateFlow(ExpiryTime.MIN_1)
    val selectedTimeframe: StateFlow<ExpiryTime> = _selectedTimeframe.asStateFlow()

    // Trade expiry is separate from the candle timeframe (like in IQ Option)
    private val _selectedExpiry = MutableStateFlow(ExpiryTime.MIN_1)
    val selectedExpiry: StateFlow<ExpiryTime> = _selectedExpiry.asStateFlow()

    // Full-screen terminal (hides app bars)
    private val _immersive = MutableStateFlow(false)
    val immersive: StateFlow<Boolean> = _immersive.asStateFlow()

    private val _isCandleChart = MutableStateFlow(true)
    val isCandleChart: StateFlow<Boolean> = _isCandleChart.asStateFlow()

    private val _showIndicators = MutableStateFlow(true)
    val showIndicators: StateFlow<Boolean> = _showIndicators.asStateFlow()

    // Exclusive IQ Option platform state
    private val _selectedPlatform = MutableStateFlow(MarketPlatform.IQ_OPTION)
    val selectedPlatform: StateFlow<MarketPlatform> = _selectedPlatform.asStateFlow()

    private val _isGeneratingSignal = MutableStateFlow(false)
    val isGeneratingSignal: StateFlow<Boolean> = _isGeneratingSignal.asStateFlow()

    private val _activeSignal = MutableStateFlow<TradingSignal?>(null)
    val activeSignal: StateFlow<TradingSignal?> = _activeSignal.asStateFlow()

    // Simulation & Balance
    private val _demoBalance = MutableStateFlow(10000.0)
    val demoBalance: StateFlow<Double> = _demoBalance.asStateFlow()

    private val _tradeAmount = MutableStateFlow(25.0)
    val tradeAmount: StateFlow<Double> = _tradeAmount.asStateFlow()

    private val _activeTrades = MutableStateFlow<List<SimulationTrade>>(emptyList())
    val activeTrades: StateFlow<List<SimulationTrade>> = _activeTrades.asStateFlow()

    // Room Database Flows
    val savedSignals: StateFlow<List<SignalEntity>> = db.signalDao().getAllSignals()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val alertRules: StateFlow<List<AlertRuleEntity>> = db.alertDao().getAllRules()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val alertNotifications: StateFlow<List<AlertNotificationEntity>> = db.alertDao().getAllNotifications()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val tradeHistory: StateFlow<List<TradeEntity>> = db.tradeDao().getAllTrades()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val feedHealth: StateFlow<FeedHealth> = marketEngine.health
    val watchlist: StateFlow<Set<String>> = marketEngine.watchlist

    // Real candles of the selected asset in the selected timeframe + Hasan Pro Signal + indicators
    val chartUi: StateFlow<ChartUi> = combine(selectedAsset, _selectedTimeframe) { asset, tf ->
        if (asset == null) {
            ChartUi()
        } else {
            val data: ChartData = marketEngine.chartData(asset, tf)
            buildChartUi(data)
        }
    }.flowOn(Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.Eagerly, ChartUi())

    val technicalIndicators: StateFlow<TechnicalIndicators> = chartUi.map { it.indicators }
        .stateIn(viewModelScope, SharingStarted.Eagerly, TechnicalAnalysisEngine.analyze(emptyList()))

    private val _lastTradeResult = MutableStateFlow<TradeResultUi?>(null)
    val lastTradeResult: StateFlow<TradeResultUi?> = _lastTradeResult.asStateFlow()

    private fun buildChartUi(data: ChartData): ChartUi {
        val all = data.candles.takeLast(400)
        if (all.isEmpty()) return ChartUi(warmingUp = data.warmingUp)
        val series = HasanProSignal.compute(all)
        val state = HasanProSignal.lastClosed(all)
        val visible = VISIBLE_CANDLES.coerceAtMost(all.size)
        return ChartUi(
            candles = all.takeLast(visible),
            hasan = series.takeLast(visible),
            hasanState = state,
            indicators = TechnicalAnalysisEngine.analyze(all),
            warmingUp = data.warmingUp
        )
    }

    init {
        startTradeResolutionLoop()
    }

    fun selectTab(tab: NavigationTab) {
        _currentTab.value = tab
        // only poll the market list that is actually on screen
        marketEngine.setBrowsingMarket(if (tab == NavigationTab.MARKETS) _selectedMarket.value else null)
    }

    fun selectMarket(market: MarketType) {
        _selectedMarket.value = market
        _selectedCategory.value = null
        if (_currentTab.value == NavigationTab.MARKETS) marketEngine.setBrowsingMarket(market)
    }

    fun toggleWatch(assetId: String) {
        marketEngine.toggleWatch(assetId)
    }

    fun selectCategory(category: MarketCategory?) {
        _selectedCategory.value = category
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun selectAsset(assetId: String) {
        marketEngine.selectAsset(assetId)
        soundManager.playClickSound()
    }

    fun setTimeframe(expiry: ExpiryTime) {
        _selectedTimeframe.value = expiry
    }

    fun setExpiry(expiry: ExpiryTime) {
        _selectedExpiry.value = expiry
    }

    fun setImmersive(on: Boolean) {
        _immersive.value = on
    }

    fun toggleChartType() {
        _isCandleChart.value = !_isCandleChart.value
    }

    fun toggleIndicators() {
        _showIndicators.value = !_showIndicators.value
    }

    fun setPlatform(platform: MarketPlatform) {
        _selectedPlatform.value = MarketPlatform.IQ_OPTION
    }

    fun setTradeAmount(amount: Double) {
        _tradeAmount.value = amount
    }

    fun generateSignalForSelectedAsset() {
        val asset = selectedAsset.value ?: return
        viewModelScope.launch {
            _isGeneratingSignal.value = true
            soundManager.playClickSound()
            delay(400L)

            val tf = _selectedTimeframe.value
            val expiry = _selectedExpiry.value
            val candles = if (tf.seconds >= 60) marketEngine.candlesFor(asset, tf)
            else marketEngine.candlesFor(asset, ExpiryTime.MIN_1)
            val indicators = TechnicalAnalysisEngine.analyze(candles)
            val signal = SignalEngine.generateSignal(
                asset = asset,
                candles = candles,
                indicators = indicators,
                platform = MarketPlatform.IQ_OPTION,
                expiryTime = expiry,
                baseTradeAmount = _tradeAmount.value
            )
            _activeSignal.value = signal
            _isGeneratingSignal.value = false

            val soundOn = alertEngine.soundEnabled.value
            val vibeOn = alertEngine.vibrationEnabled.value
            if (!signal.isWait) {
                if (signal.direction == SignalDirection.CALL) {
                    soundManager.playCallAlert(soundEnabled = soundOn, vibrationEnabled = vibeOn)
                } else {
                    soundManager.playPutAlert(soundEnabled = soundOn, vibrationEnabled = vibeOn)
                }
            }

            // Save to room (only real setups, not WAIT)
            if (!signal.isWait) launch(Dispatchers.IO) {
                db.signalDao().insertSignal(
                    SignalEntity(
                        id = signal.id,
                        assetId = signal.assetId,
                        assetSymbol = signal.assetSymbol,
                        categoryName = signal.assetCategory.name,
                        direction = signal.direction.name,
                        confidence = signal.confidence,
                        strikePrice = signal.strikePrice,
                        expirySeconds = signal.expiryTime.seconds,
                        platformName = MarketPlatform.IQ_OPTION.displayName,
                        strategyName = signal.strategyName,
                        rsiValue = signal.rsiValue,
                        macdTrend = signal.macdTrend,
                        timestamp = signal.timestamp,
                        outcome = signal.outcome.name,
                        resultPnl = signal.resultPnl
                    )
                )
            }
        }
    }

    fun executeTrade(direction: SignalDirection) {
        val asset = selectedAsset.value ?: return
        val amount = _tradeAmount.value
        if (!asset.hasPrice) return
        if (_demoBalance.value < amount) return

        _demoBalance.update { it - amount }
        soundManager.playClickSound()

        val trade = SimulationTrade(
            id = UUID.randomUUID().toString(),
            assetId = asset.id,
            assetSymbol = asset.symbol,
            category = asset.category,
            direction = direction,
            investment = amount,
            entryPrice = asset.currentPrice,
            payoutPercent = if (asset.payoutPercent > 0) asset.payoutPercent else 85,
            expirySeconds = _selectedExpiry.value.seconds,
            platform = MarketPlatform.IQ_OPTION
        )

        _activeTrades.update { it + trade }
    }

    private fun startTradeResolutionLoop() {
        viewModelScope.launch(Dispatchers.Default) {
            while (true) {
                delay(500L)
                val now = System.currentTimeMillis()
                val due = _activeTrades.value.filter { now >= it.closeTime }
                if (due.isEmpty()) continue

                // remove only the resolved trades (a trade opened meanwhile must not be lost)
                val dueIds = due.map { it.id }.toSet()
                _activeTrades.update { cur -> cur.filter { it.id !in dueIds } }

                for (trade in due) {
                    val asset = allAssets.value.firstOrNull { it.id == trade.assetId }
                    val exitPrice = asset?.currentPrice?.takeIf { it > 0.0 } ?: trade.entryPrice
                    val isTie = exitPrice == trade.entryPrice
                    val isWin = !isTie && if (trade.direction == SignalDirection.CALL) {
                        exitPrice > trade.entryPrice
                    } else {
                        exitPrice < trade.entryPrice
                    }

                    val outcome = when {
                        isTie -> SignalOutcome.EXPIRED // tie: the stake is returned
                        isWin -> SignalOutcome.WIN
                        else -> SignalOutcome.LOSS
                    }
                    val profit = when {
                        isTie -> 0.0
                        isWin -> trade.investment * (trade.payoutPercent / 100.0)
                        else -> -trade.investment
                    }
                    _lastTradeResult.value = TradeResultUi(
                        assetSymbol = trade.assetSymbol,
                        direction = trade.direction,
                        entryPrice = trade.entryPrice,
                        exitPrice = exitPrice,
                        profit = profit,
                        isWin = isWin,
                        decimals = asset?.priceDecimals ?: 5,
                        isTie = isTie
                    )

                    val soundOn = alertEngine.soundEnabled.value
                    val vibeOn = alertEngine.vibrationEnabled.value
                    when {
                        isTie -> _demoBalance.update { it + trade.investment }
                        isWin -> {
                            _demoBalance.update { it + trade.investment + profit }
                            soundManager.playCallAlert(soundEnabled = soundOn, vibrationEnabled = vibeOn)
                        }
                        else -> soundManager.playPutAlert(soundEnabled = soundOn, vibrationEnabled = vibeOn)
                    }

                    val tradeEntity = TradeEntity(
                        id = trade.id,
                        assetId = trade.assetId,
                        assetSymbol = trade.assetSymbol,
                        categoryName = trade.category.name,
                        direction = trade.direction.name,
                        investment = trade.investment,
                        entryPrice = trade.entryPrice,
                        exitPrice = exitPrice,
                        payoutPercent = trade.payoutPercent,
                        expirySeconds = trade.expirySeconds,
                        openTime = trade.openTime,
                        closeTime = trade.closeTime,
                        outcome = outcome.name,
                        profit = profit,
                        platformName = MarketPlatform.IQ_OPTION.displayName
                    )
                    launch(Dispatchers.IO) {
                        db.tradeDao().insertTrade(tradeEntity)
                    }
                }
            }
        }
    }

    fun dismissTradeResult() {
        _lastTradeResult.value = null
    }

    fun navigateToAlertsForAsset(assetId: String) {
        selectAsset(assetId)
        _currentTab.value = NavigationTab.ALERTS
    }

    fun addCustomPriceAlert(
        asset: TradingAsset,
        targetPrice: Double,
        isAbove: Boolean,
        soundEnabled: Boolean = true,
        vibrationEnabled: Boolean = true
    ) {
        val type = if (isAbove) AlertType.PRICE_ABOVE else AlertType.PRICE_BELOW
        val rule = AlertRule(
            id = UUID.randomUUID().toString(),
            assetId = asset.id,
            assetSymbol = asset.symbol,
            type = type,
            targetValue = targetPrice,
            isEnabled = true,
            soundEnabled = soundEnabled,
            vibrationEnabled = vibrationEnabled
        )
        alertEngine.addCustomAlertRule(rule)
        soundManager.playClickSound()
    }

    fun toggleAlertRule(ruleId: String, isEnabled: Boolean) {
        alertEngine.toggleRuleStatus(ruleId, isEnabled)
        soundManager.playClickSound()
    }

    fun testTriggerAlertRule(rule: AlertRuleEntity) {
        alertEngine.testTriggerCustomRule(rule)
    }

    fun addCustomRsiAlert(asset: TradingAsset, isOversold: Boolean) {
        val type = if (isOversold) AlertType.RSI_OVERSOLD else AlertType.RSI_OVERBOUGHT
        val target = if (isOversold) 30.0 else 70.0
        val rule = AlertRule(
            id = UUID.randomUUID().toString(),
            assetId = asset.id,
            assetSymbol = asset.symbol,
            type = type,
            targetValue = target
        )
        alertEngine.addCustomAlertRule(rule)
        soundManager.playClickSound()
    }

    fun deleteAlertRule(ruleId: String) {
        alertEngine.deleteCustomAlertRule(ruleId)
    }

    fun markNotificationsRead() {
        viewModelScope.launch(Dispatchers.IO) {
            db.alertDao().markAllAsRead()
        }
    }

    fun clearNotifications() {
        viewModelScope.launch(Dispatchers.IO) {
            db.alertDao().clearNotifications()
        }
    }

    fun setSoundEnabled(enabled: Boolean) {
        alertEngine.setSoundEnabled(enabled)
    }

    fun setVibrationEnabled(enabled: Boolean) {
        alertEngine.setVibrationEnabled(enabled)
    }

    fun resetDemoBalance() {
        _demoBalance.value = 10000.0
        soundManager.playClickSound(alertEngine.soundEnabled.value)
    }

    override fun onCleared() {
        super.onCleared()
        marketEngine.shutdown()
        soundManager.release()
    }

    companion object {
        const val VISIBLE_CANDLES = 70
    }
}
