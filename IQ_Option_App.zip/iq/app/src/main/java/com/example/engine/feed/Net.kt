package com.example.engine.feed

import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

/** Shared HTTP client + helpers for all price feeds. */
object Net {
    const val BROWSER_UA =
        "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/124.0.0.0 Mobile Safari/537.36"

    val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .writeTimeout(10, TimeUnit.SECONDS)
        .pingInterval(20, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    class HttpResult(val code: Int, val body: String?)

    /** Blocking GET. Call from Dispatchers.IO. Never throws. */
    fun get(url: String): HttpResult {
        return try {
            val req = Request.Builder()
                .url(url)
                .header("User-Agent", BROWSER_UA)
                .header("Accept", "application/json,text/plain,*/*")
                .build()
            client.newCall(req).execute().use { resp ->
                HttpResult(resp.code, resp.body?.string())
            }
        } catch (e: Exception) {
            HttpResult(-1, null)
        }
    }
}
