package com.example.ui.components

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView

const val IQ_OPTION_URL = "https://iqoption.com/traderoom"

private const val MOBILE_UA =
    "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) " +
        "Chrome/124.0.0.0 Mobile Safari/537.36"
private const val DESKTOP_UA =
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) " +
        "Chrome/124.0.0.0 Safari/537.36"

/**
 * Creates the IQ Option web terminal. Create it ONCE (MainScreen keeps it) so the login session and the
 * open trade room survive tab switches.
 */
@SuppressLint("SetJavaScriptEnabled")
fun createIqWebView(context: Context): WebView {
    return WebView(context).apply {
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
        isVerticalScrollBarEnabled = false
        isHorizontalScrollBarEnabled = false
        overScrollMode = WebView.OVER_SCROLL_NEVER
        settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY
            cacheMode = WebSettings.LOAD_DEFAULT
            javaScriptCanOpenWindowsAutomatically = true
            setSupportMultipleWindows(false)
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
            // Mobile layout of IQ Option: honour the page viewport so it fits the screen width exactly
            useWideViewPort = true
            loadWithOverviewMode = false
            userAgentString = MOBILE_UA
        }
        webChromeClient = WebChromeClient()
        webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val url = request?.url?.toString() ?: return false
                return handleExternalScheme(view?.context, url)
            }
        }
        loadUrl(IQ_OPTION_URL)
    }
}

/** Switch between the phone layout (fits width) and the desktop layout (shrunk to fit the screen). */
fun WebView.applyLayoutMode(desktop: Boolean) {
    settings.userAgentString = if (desktop) DESKTOP_UA else MOBILE_UA
    settings.useWideViewPort = true
    settings.loadWithOverviewMode = desktop
    reload()
}

private fun handleExternalScheme(context: Context?, url: String): Boolean {
    if (url.startsWith("http://") || url.startsWith("https://")) return false
    try {
        if (context != null) {
            val intent = if (url.startsWith("intent://")) {
                Intent.parseUri(url, Intent.URI_INTENT_SCHEME)
            } else {
                Intent(Intent.ACTION_VIEW, Uri.parse(url))
            }
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
        }
    } catch (e: Exception) {
    }
    return true
}

/** Hosts the long-lived [webView] and fills all the space it is given (no fixed height, no clipping). */
@Composable
fun IqWebTerminal(webView: WebView, modifier: Modifier = Modifier) {
    AndroidView(
        modifier = modifier.fillMaxSize(),
        factory = {
            // the same instance is re-attached when coming back to this tab
            (webView.parent as? android.view.ViewGroup)?.removeView(webView)
            webView
        },
        update = { it.onResume() },
        onRelease = { it.onPause() }
    )
}
