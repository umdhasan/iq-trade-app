package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.HasanProSignal
import com.example.model.Candle
import com.example.ui.theme.BearishRed
import com.example.ui.theme.BullishGreen
import com.example.ui.theme.CardBorder
import com.example.ui.theme.CardSurface
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningYellow
import kotlinx.coroutines.delay
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

private val HasanFastColor = Color(0xFF00C853)
private val HasanSlowColor = Color(0xFFFF9800)

/**
 * Real-price chart. Draws the candles, the Hasan Pro Signal lines (WMA2 green, EMA21 orange),
 * the UP+ / DOWN+ / UP? / DOWN? markers, the live price tag and the candle close countdown.
 */
@Composable
fun TradingChart(
    candles: List<Candle>,
    currentPrice: Double,
    isCandleChart: Boolean,
    showIndicators: Boolean,
    hasan: HasanProSignal.Series?,
    priceDecimals: Int,
    candleSeconds: Int,
    emptyText: String,
    modifier: Modifier = Modifier
) {
    var touchX by remember { mutableStateOf<Float?>(null) }
    var selectedIndex by remember { mutableStateOf<Int?>(null) }
    var nowMs by remember { mutableLongStateOf(System.currentTimeMillis()) }
    val measurer = rememberTextMeasurer()

    LaunchedEffect(Unit) {
        while (true) {
            nowMs = System.currentTimeMillis()
            delay(250L)
        }
    }

    Box(
        modifier = modifier
            .background(CardSurface)
            .testTag("trading_chart_canvas")
    ) {
        if (candles.isEmpty()) {
            Text(
                text = emptyText,
                color = TextMuted,
                fontSize = 13.sp,
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(16.dp)
            )
            return@Box
        }

        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(candles.size) {
                    detectTapGestures(
                        onPress = { offset ->
                            val axisW = 56.dp.toPx()
                            val plotW = size.width - axisW
                            val per = plotW / candles.size
                            touchX = offset.x
                            selectedIndex = (offset.x / per).toInt().coerceIn(0, candles.size - 1)
                            tryAwaitRelease()
                            touchX = null
                            selectedIndex = null
                        }
                    )
                }
        ) {
            val axisW = 56.dp.toPx()
            val plotW = size.width - axisW
            val height = size.height
            val plotH = height - 18.dp.toPx()
            val n = candles.size
            val per = plotW / n
            val bodyW = max(2f, per * 0.66f)

            var lo = candles.minOf { it.low }
            var hi = candles.maxOf { it.high }
            if (showIndicators && hasan != null) {
                for (i in 0 until min(n, hasan.size)) {
                    lo = min(lo, min(hasan.fast[i], hasan.slow[i]))
                    hi = max(hi, max(hasan.fast[i], hasan.slow[i]))
                }
            }
            lo = min(lo, currentPrice.takeIf { it > 0.0 } ?: lo)
            hi = max(hi, currentPrice)
            val pad = max((hi - lo) * 0.08, hi * 0.00002)
            val minP = lo - pad
            val maxP = hi + pad
            val range = max(1e-12, maxP - minP)

            fun y(price: Double): Float = (plotH - ((price - minP) / range * plotH)).toFloat()
            fun x(i: Int): Float = i * per + per / 2f
            val labelStyle = TextStyle(color = TextSecondary, fontSize = 9.sp)

            // ---- grid + price axis
            val steps = 4
            for (s in 0..steps) {
                val gy = plotH / steps * s
                drawLine(
                    color = CardBorder.copy(alpha = 0.45f),
                    start = Offset(0f, gy),
                    end = Offset(plotW, gy),
                    strokeWidth = 1f,
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 8f))
                )
                val price = maxP - range / steps * s
                drawText(
                    textMeasurer = measurer,
                    text = String.format(Locale.US, "%.${priceDecimals}f", price),
                    topLeft = Offset(plotW + 4.dp.toPx(), (gy - 6.dp.toPx()).coerceAtLeast(0f)),
                    style = labelStyle
                )
            }

            // ---- time axis (first / middle / last candle)
            val fmt = java.text.SimpleDateFormat(if (candleSeconds < 60) "HH:mm:ss" else "HH:mm", Locale.US)
            for (idx in listOf(0, n / 2, n - 1)) {
                if (idx < 0 || idx >= n) continue
                val label = fmt.format(java.util.Date(candles[idx].timestamp))
                drawText(
                    textMeasurer = measurer,
                    text = label,
                    topLeft = Offset((x(idx) - 16.dp.toPx()).coerceIn(0f, plotW - 34.dp.toPx()), plotH + 3.dp.toPx()),
                    style = labelStyle
                )
            }

            // ---- chart body
            if (isCandleChart) {
                for (i in 0 until n) {
                    val c = candles[i]
                    val color = if (c.isBullish) BullishGreen else BearishRed
                    drawLine(color, Offset(x(i), y(c.high)), Offset(x(i), y(c.low)), strokeWidth = 1.4f)
                    val top = min(y(c.open), y(c.close))
                    val h = max(2f, abs(y(c.close) - y(c.open)))
                    drawRect(color, Offset(x(i) - bodyW / 2f, top), Size(bodyW, h))
                }
            } else {
                val line = Path()
                val fill = Path()
                for (i in 0 until n) {
                    val px = x(i)
                    val py = y(candles[i].close)
                    if (i == 0) {
                        line.moveTo(px, py)
                        fill.moveTo(px, plotH)
                        fill.lineTo(px, py)
                    } else {
                        line.lineTo(px, py)
                        fill.lineTo(px, py)
                    }
                }
                fill.lineTo(x(n - 1), plotH)
                fill.close()
                drawPath(
                    fill,
                    Brush.verticalGradient(listOf(CyberCyan.copy(alpha = 0.30f), Color.Transparent), 0f, plotH)
                )
                drawPath(line, CyberCyan, style = Stroke(width = 2.4f))
            }

            // ---- Hasan Pro Signal lines + markers
            if (showIndicators && hasan != null && hasan.size >= n) {
                val offset = hasan.size - n
                drawSeries(hasan.fast, offset, n, ::x, ::y, HasanFastColor)
                drawSeries(hasan.slow, offset, n, ::x, ::y, HasanSlowColor)

                for (i in 0 until n) {
                    val code = hasan.signal[offset + i]
                    if (code == HasanProSignal.NONE) continue
                    val forming = i == n - 1
                    val alpha = if (forming) 0.45f else 1f
                    val strong = abs(code) == 2
                    val up = code > 0
                    val color = when {
                        !strong -> WarningYellow
                        up -> HasanFastColor
                        else -> BearishRed
                    }.copy(alpha = alpha)
                    val sz = if (strong) 7.dp.toPx() else 4.5.dp.toPx()
                    val c = candles[i]
                    val cx = x(i)
                    val tri = Path()
                    if (up) {
                        val base = y(c.low) + 4.dp.toPx()
                        tri.moveTo(cx, base)
                        tri.lineTo(cx - sz, base + sz * 1.5f)
                        tri.lineTo(cx + sz, base + sz * 1.5f)
                        tri.close()
                        drawPath(tri, color)
                        drawText(
                            textMeasurer = measurer,
                            text = HasanProSignal.labelOf(code),
                            topLeft = Offset(cx - 10.dp.toPx(), base + sz * 1.5f + 1.dp.toPx()),
                            style = TextStyle(color = color, fontSize = 8.sp)
                        )
                    } else {
                        val base = y(c.high) - 4.dp.toPx()
                        tri.moveTo(cx, base)
                        tri.lineTo(cx - sz, base - sz * 1.5f)
                        tri.lineTo(cx + sz, base - sz * 1.5f)
                        tri.close()
                        drawPath(tri, color)
                        drawText(
                            textMeasurer = measurer,
                            text = HasanProSignal.labelOf(code),
                            topLeft = Offset(cx - 14.dp.toPx(), base - sz * 1.5f - 11.dp.toPx()),
                            style = TextStyle(color = color, fontSize = 8.sp)
                        )
                    }
                }
            }

            // ---- live price line + tag
            if (currentPrice > 0.0) {
                val cy = y(currentPrice)
                val last = candles.last()
                val liveColor = if (last.isBullish) BullishGreen else BearishRed
                drawLine(
                    color = liveColor,
                    start = Offset(0f, cy),
                    end = Offset(plotW, cy),
                    strokeWidth = 1.4f,
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 6f))
                )
                drawCircle(liveColor, 4.5f, Offset(x(n - 1), cy))
                drawCircle(liveColor.copy(alpha = 0.3f), 10f, Offset(x(n - 1), cy))
                drawRect(liveColor, Offset(plotW, cy - 8.dp.toPx()), Size(axisW, 16.dp.toPx()))
                drawText(
                    textMeasurer = measurer,
                    text = String.format(Locale.US, "%.${priceDecimals}f", currentPrice),
                    topLeft = Offset(plotW + 3.dp.toPx(), cy - 6.dp.toPx()),
                    style = TextStyle(color = Color.Black, fontSize = 9.sp)
                )
            }

            // ---- crosshair
            touchX?.let { tx ->
                drawLine(
                    color = Color.White.copy(alpha = 0.55f),
                    start = Offset(tx, 0f),
                    end = Offset(tx, plotH),
                    strokeWidth = 1f,
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(4f, 4f))
                )
            }
        }

        // candle close countdown (top right)
        if (candleSeconds > 0) {
            val span = candleSeconds * 1000L
            val left = span - (nowMs % span)
            val sec = (left / 1000L).toInt()
            val txt = if (candleSeconds >= 60) String.format(Locale.US, "%02d:%02d", sec / 60, sec % 60)
            else String.format(Locale.US, "00:%02d", sec)
            Text(
                text = "⏱ $txt",
                color = CyberCyan,
                fontSize = 11.sp,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(top = 4.dp, end = 62.dp)
            )
        }

        selectedIndex?.let { idx ->
            val c = candles.getOrNull(idx)
            if (c != null) {
                val f = "%.${priceDecimals}f"
                Text(
                    text = "O ${String.format(Locale.US, f, c.open)}  H ${String.format(Locale.US, f, c.high)}  " +
                        "L ${String.format(Locale.US, f, c.low)}  C ${String.format(Locale.US, f, c.close)}",
                    color = if (c.isBullish) BullishGreen else BearishRed,
                    fontSize = 10.sp,
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(6.dp)
                        .background(CardSurface.copy(alpha = 0.92f))
                        .padding(horizontal = 6.dp, vertical = 3.dp)
                )
            }
        }
    }
}

private fun DrawScope.drawSeries(
    values: DoubleArray,
    offset: Int,
    n: Int,
    x: (Int) -> Float,
    y: (Double) -> Float,
    color: Color
) {
    val path = Path()
    for (i in 0 until n) {
        val px = x(i)
        val py = y(values[offset + i])
        if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
    }
    drawPath(path, color, style = Stroke(width = 2f))
}
