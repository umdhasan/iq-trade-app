package com.example.engine.feed

import com.example.model.Candle
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/**
 * Binance public market data (no API key needed).
 *  - one WebSocket streams the 24h mini-ticker of EVERY symbol (~1 update / second)
 *  - an optional second WebSocket streams every trade of the selected symbol (real-time ticks)
 *  - REST klines give the 1-minute candle history for charts / indicators
 */
class BinanceFeed(
    private val onQuote: (symbol: String, quote: Quote) -> Unit,
    private val onTick: (symbol: String, tick: PriceTick) -> Unit
) {
    private val wsHosts = listOf(
        "wss://stream.binance.com:9443",
        "wss://data-stream.binance.vision"
    )
    private val restHosts = listOf(
        "https://api.binance.com",
        "https://data-api.binance.vision",
        "https://api1.binance.com"
    )

    @Volatile private var allSocket: WebSocket? = null
    @Volatile private var tradeSocket: WebSocket? = null
    @Volatile private var tradeSymbol: String? = null
    @Volatile private var running = false
    @Volatile private var hostIndex = 0
    @Volatile private var failures = 0

    private val lastPrice = HashMap<String, Double>()

    // ---------------------------------------------------------------- all-symbol ticker
    fun start() {
        if (running) return
        running = true
        connectAll()
    }

    fun stop() {
        running = false
        try { allSocket?.cancel() } catch (e: Exception) {}
        try { tradeSocket?.cancel() } catch (e: Exception) {}
        allSocket = null
        tradeSocket = null
    }

    private fun connectAll() {
        if (!running) return
        val url = "${wsHosts[hostIndex % wsHosts.size]}/stream?streams=!miniTicker@arr"
        val req = Request.Builder().url(url).build()
        allSocket = Net.client.newWebSocket(req, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                failures = 0
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                try {
                    val root = JSONObject(text)
                    val data = root.optJSONArray("data") ?: return
                    handleMiniTickers(data)
                } catch (e: Exception) {
                }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                scheduleReconnectAll()
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                scheduleReconnectAll()
            }
        })
    }

    private fun scheduleReconnectAll() {
        if (!running) return
        failures++
        if (failures % 2 == 0) hostIndex++
        val delayMs = (1000L * failures.coerceAtMost(10)).coerceAtLeast(1500L)
        Thread {
            try { Thread.sleep(delayMs) } catch (e: InterruptedException) {}
            connectAll()
        }.start()
    }

    private fun handleMiniTickers(arr: JSONArray) {
        val now = System.currentTimeMillis()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val s = o.optString("s")
            if (!s.endsWith("USDT")) continue
            val close = o.optString("c").toDoubleOrNull() ?: continue
            val open = o.optString("o").toDoubleOrNull() ?: close
            val high = o.optString("h").toDoubleOrNull() ?: close
            val low = o.optString("l").toDoubleOrNull() ?: close
            val prev = lastPrice[s] ?: close
            lastPrice[s] = close
            onQuote(
                s,
                Quote(
                    price = close,
                    prevPrice = prev,
                    refClose = open,
                    dayHigh = high,
                    dayLow = low,
                    marketTimeMs = o.optLong("E", now),
                    receivedMs = now
                )
            )
        }
    }

    // ---------------------------------------------------------------- per-symbol trade stream
    /** Subscribe to real-time trades of one symbol (pass null to stop). */
    fun watchTrades(symbol: String?) {
        if (symbol == tradeSymbol) return
        try { tradeSocket?.cancel() } catch (e: Exception) {}
        tradeSocket = null
        tradeSymbol = symbol
        if (symbol == null || !running) return
        connectTrades(symbol)
    }

    private fun connectTrades(symbol: String) {
        val url = "${wsHosts[hostIndex % wsHosts.size]}/ws/${symbol.lowercase(Locale.US)}@aggTrade"
        val req = Request.Builder().url(url).build()
        tradeSocket = Net.client.newWebSocket(req, object : WebSocketListener() {
            override fun onMessage(webSocket: WebSocket, text: String) {
                try {
                    val o = JSONObject(text)
                    val p = o.optString("p").toDoubleOrNull() ?: return
                    val t = o.optLong("T", System.currentTimeMillis())
                    onTick(symbol, PriceTick(t, p))
                } catch (e: Exception) {
                }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                retryTrades(symbol)
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                retryTrades(symbol)
            }
        })
    }

    private fun retryTrades(symbol: String) {
        if (!running || tradeSymbol != symbol) return
        Thread {
            try { Thread.sleep(2500) } catch (e: InterruptedException) {}
            if (running && tradeSymbol == symbol) connectTrades(symbol)
        }.start()
    }

    // ---------------------------------------------------------------- REST history
    /** 1-minute candles, oldest first. Blocking: call from Dispatchers.IO. */
    fun fetchKlines(symbol: String, limit: Int = 500): List<Candle> {
        for (host in restHosts) {
            val res = Net.get("$host/api/v3/klines?symbol=$symbol&interval=1m&limit=$limit")
            val body = res.body
            if (res.code != 200 || body == null) continue
            try {
                val arr = JSONArray(body)
                val out = ArrayList<Candle>(arr.length())
                for (i in 0 until arr.length()) {
                    val k = arr.getJSONArray(i)
                    out.add(
                        Candle(
                            timestamp = k.getLong(0),
                            open = k.getString(1).toDouble(),
                            high = k.getString(2).toDouble(),
                            low = k.getString(3).toDouble(),
                            close = k.getString(4).toDouble(),
                            volume = k.getString(5).toDouble()
                        )
                    )
                }
                if (out.isNotEmpty()) return out
            } catch (e: Exception) {
            }
        }
        return emptyList()
    }
}
