package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Radar
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.TrendingDown
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.database.AlertNotificationEntity
import com.example.database.AlertRuleEntity
import com.example.model.TradingAsset
import com.example.ui.TradeProViewModel
import com.example.ui.components.AssetPickerDialog
import com.example.ui.theme.BearishRed
import com.example.ui.theme.BullishGreen
import com.example.ui.theme.CardBorder
import com.example.ui.theme.CardSurface
import com.example.ui.theme.CardSurfaceElevated
import com.example.ui.theme.CryptoGold
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DarkNavyBg
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

@Composable
fun AlertsScreen(
    viewModel: TradeProViewModel,
    modifier: Modifier = Modifier
) {
    var activeSubTab by remember { mutableStateOf("TARGET_ALERTS") } // TARGET_ALERTS, AI_SCANNER, NOTIFICATION_FEED

    val selectedAsset by viewModel.selectedAsset.collectAsState()
    val allAssets by viewModel.allAssets.collectAsState()
    val alertRules by viewModel.alertRules.collectAsState()
    val notifications by viewModel.alertNotifications.collectAsState()
    val isAutoScannerActive by viewModel.alertEngine.isAutoScannerActive.collectAsState()
    val minConfidence by viewModel.alertEngine.minConfidenceThreshold.collectAsState()
    val soundEnabled by viewModel.alertEngine.soundEnabled.collectAsState()
    val vibrationEnabled by viewModel.alertEngine.vibrationEnabled.collectAsState()

    val currentAsset = selectedAsset ?: allAssets.firstOrNull()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkNavyBg)
            .padding(horizontal = 14.dp)
            .testTag("alerts_screen")
    ) {
        Spacer(modifier = Modifier.height(10.dp))

        // Top Sub-Tab Switcher
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(CardSurface)
                .border(1.dp, CardBorder, RoundedCornerShape(10.dp))
                .padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            SubTabItem(
                label = "🎯 কাস্টম প্রাইস অ্যালার্ট",
                isSelected = activeSubTab == "TARGET_ALERTS",
                selectedColor = CyberCyan,
                modifier = Modifier.weight(1.3f)
            ) { activeSubTab = "TARGET_ALERTS" }

            SubTabItem(
                label = "🤖 এআই স্ক্যানার",
                isSelected = activeSubTab == "AI_SCANNER",
                selectedColor = CryptoGold,
                modifier = Modifier.weight(1.1f)
            ) { activeSubTab = "AI_SCANNER" }

            SubTabItem(
                label = "🔔 নোটিফিকেশন (${notifications.size})",
                isSelected = activeSubTab == "NOTIFICATION_FEED",
                selectedColor = BullishGreen,
                modifier = Modifier.weight(1.2f)
            ) { activeSubTab = "NOTIFICATION_FEED" }
        }

        Spacer(modifier = Modifier.height(10.dp))

        when (activeSubTab) {
            "TARGET_ALERTS" -> {
                if (currentAsset != null) {
                    CustomPriceAlertTab(
                        viewModel = viewModel,
                        currentAsset = currentAsset,
                        allAssets = allAssets,
                        alertRules = alertRules
                    )
                }
            }
            "AI_SCANNER" -> {
                ScannerAndSettingsTab(
                    viewModel = viewModel,
                    isAutoScannerActive = isAutoScannerActive,
                    minConfidence = minConfidence,
                    soundEnabled = soundEnabled,
                    vibrationEnabled = vibrationEnabled
                )
            }
            "NOTIFICATION_FEED" -> {
                NotificationsFeedTab(
                    viewModel = viewModel,
                    notifications = notifications
                )
            }
        }
    }
}

@Composable
fun SubTabItem(
    label: String,
    isSelected: Boolean,
    selectedColor: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(7.dp))
            .background(if (isSelected) selectedColor.copy(alpha = 0.22f) else Color.Transparent)
            .border(1.dp, if (isSelected) selectedColor else Color.Transparent, RoundedCornerShape(7.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 7.dp, horizontal = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = if (isSelected) selectedColor else TextSecondary,
            fontSize = 11.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
            maxLines = 1
        )
    }
}

/**
 * Main Custom Price Alert Screen: define target price thresholds and view active alerts.
 */
@Composable
fun CustomPriceAlertTab(
    viewModel: TradeProViewModel,
    currentAsset: TradingAsset,
    allAssets: List<TradingAsset>,
    alertRules: List<AlertRuleEntity>
) {
    var showAssetPickerModal by remember { mutableStateOf(false) }
    var alertDirection by remember { mutableStateOf(true) } // true = Above (>=), false = Below (<=)
    var targetPriceInput by remember { mutableStateOf("") }
    var ruleSoundEnabled by remember { mutableStateOf(true) }
    var ruleVibeEnabled by remember { mutableStateOf(true) }
    var creationSuccessMsg by remember { mutableStateOf<String?>(null) }

    // Synchronize default target price when asset or direction changes
    val pipUnit = when (currentAsset.priceDecimals) {
        5 -> 0.00010
        4 -> 0.0010
        3 -> 0.010
        2 -> 0.10
        6 -> 0.000010
        else -> 1.0
    }

    LaunchedEffect(currentAsset.id, alertDirection) {
        val delta = if (alertDirection) pipUnit * 5.0 else -pipUnit * 5.0
        val target = currentAsset.currentPrice + delta
        targetPriceInput = String.format(Locale.US, "%.${currentAsset.priceDecimals}f", target)
    }

    val parsedTarget = targetPriceInput.toDoubleOrNull() ?: currentAsset.currentPrice
    val diffFromCurrent = parsedTarget - currentAsset.currentPrice
    val pctFromCurrent = (abs(diffFromCurrent) / currentAsset.currentPrice) * 100.0

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // 1. Current Asset Live Feed Card
        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = CardSurface),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, CardBorder, RoundedCornerShape(12.dp))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    // Top: Symbol & Badges
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = currentAsset.symbol,
                                color = TextPrimary,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            if (currentAsset.isOtc) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(CryptoGold.copy(alpha = 0.2f))
                                        .border(1.dp, CryptoGold.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
                                        .padding(horizontal = 5.dp, vertical = 2.dp)
                                ) {
                                    Text("OTC", color = CryptoGold, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold)
                                }
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(CyberCyan.copy(alpha = 0.15f))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "${currentAsset.payoutPercent}% পেআউট",
                                    color = CyberCyan,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        // Change Asset Button
                        Button(
                            onClick = { showAssetPickerModal = true },
                            colors = ButtonDefaults.buttonColors(containerColor = CardSurfaceElevated),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 3.dp),
                            modifier = Modifier.height(28.dp).testTag("select_asset_button")
                        ) {
                            Icon(Icons.Default.Tune, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(13.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("এসেট বদলান", color = CyberCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Live Price Feed Highlight Row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(CardSurfaceElevated)
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("লাইভ মার্কেট ফিড মূল্য", color = TextMuted, fontSize = 10.sp)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = String.format(Locale.US, "%.${currentAsset.priceDecimals}f", currentAsset.currentPrice),
                                    color = if (currentAsset.isUp) BullishGreen else BearishRed,
                                    fontSize = 20.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    modifier = Modifier.testTag("live_feed_price_display")
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Icon(
                                    imageVector = if (currentAsset.isUp) Icons.Default.TrendingUp else Icons.Default.TrendingDown,
                                    contentDescription = null,
                                    tint = if (currentAsset.isUp) BullishGreen else BearishRed,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Quick scroll: assets of the same market list
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(allAssets.filter { it.marketType == currentAsset.marketType }.take(8)) { a ->
                            val isSel = a.id == currentAsset.id
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (isSel) CyberCyan.copy(alpha = 0.2f) else CardSurfaceElevated)
                                    .border(1.dp, if (isSel) CyberCyan else CardBorder, RoundedCornerShape(6.dp))
                                    .clickable { viewModel.selectAsset(a.id) }
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = a.symbol,
                                    color = if (isSel) CyberCyan else TextSecondary,
                                    fontSize = 10.sp,
                                    fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal
                                )
                            }
                        }
                    }
                }
            }
        }

        // 2. Set Custom Target Price Threshold Builder Card
        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = CardSurface),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, CyberCyan.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "🎯 টার্গেট প্রাইস থ্রেশহোল্ড নির্ধারণ করুন",
                        color = TextPrimary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "ফিডের মূল্য এই লেভেলে পৌঁছামাত্র তাৎক্ষণিক নোটিফিকেশন প্রদান করা হবে।",
                        color = TextMuted,
                        fontSize = 11.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Condition Direction Toggle (Above / Below)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(CardSurfaceElevated)
                            .padding(4.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (alertDirection) BullishGreen.copy(alpha = 0.2f) else Color.Transparent)
                                .border(1.dp, if (alertDirection) BullishGreen else Color.Transparent, RoundedCornerShape(6.dp))
                                .clickable { alertDirection = true }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.TrendingUp, contentDescription = null, tint = if (alertDirection) BullishGreen else TextMuted, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "মূল্য বৃদ্ধি (≥ টার্গেট)",
                                    color = if (alertDirection) BullishGreen else TextSecondary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (!alertDirection) BearishRed.copy(alpha = 0.2f) else Color.Transparent)
                                .border(1.dp, if (!alertDirection) BearishRed else Color.Transparent, RoundedCornerShape(6.dp))
                                .clickable { alertDirection = false }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.TrendingDown, contentDescription = null, tint = if (!alertDirection) BearishRed else TextMuted, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "মূল্য পতন (≤ টার্গেট)",
                                    color = if (!alertDirection) BearishRed else TextSecondary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Target Price Input Field with Stepper Buttons
                    Text("টার্গেট মূল্য (Target Price):", color = TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(modifier = Modifier.height(4.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        // Decrement Button
                        Button(
                            onClick = {
                                val currentVal = targetPriceInput.toDoubleOrNull() ?: currentAsset.currentPrice
                                val newVal = max(0.000001, currentVal - pipUnit)
                                targetPriceInput = String.format(Locale.US, "%.${currentAsset.priceDecimals}f", newVal)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = CardSurfaceElevated),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.size(46.dp)
                        ) {
                            Text("-", color = TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        }

                        OutlinedTextField(
                            value = targetPriceInput,
                            onValueChange = { targetPriceInput = it },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = DarkNavyBg,
                                unfocusedContainerColor = DarkNavyBg,
                                focusedBorderColor = CyberCyan,
                                unfocusedBorderColor = CardBorder,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("target_price_input")
                        )

                        // Increment Button
                        Button(
                            onClick = {
                                val currentVal = targetPriceInput.toDoubleOrNull() ?: currentAsset.currentPrice
                                val newVal = currentVal + pipUnit
                                targetPriceInput = String.format(Locale.US, "%.${currentAsset.priceDecimals}f", newVal)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = CardSurfaceElevated),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.size(46.dp)
                        ) {
                            Text("+", color = TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Quick Distance Preset Chips
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        val multipliers = if (alertDirection) listOf(2.0, 5.0, 10.0, 25.0) else listOf(-2.0, -5.0, -10.0, -25.0)
                        multipliers.forEach { mult ->
                            val label = if (mult > 0) "+${mult.toInt()} Pips" else "${mult.toInt()} Pips"
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(CardSurfaceElevated)
                                    .border(1.dp, CardBorder, RoundedCornerShape(6.dp))
                                    .clickable {
                                        val calculated = currentAsset.currentPrice + (pipUnit * mult)
                                        targetPriceInput = String.format(Locale.US, "%.${currentAsset.priceDecimals}f", calculated)
                                    }
                                    .padding(horizontal = 8.dp, vertical = 5.dp)
                            ) {
                                Text(label, color = CyberCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Real-Time Distance & Direction Info Box
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(CardSurfaceElevated)
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("বর্তমান থেকে ব্যবধান (Distance):", color = TextMuted, fontSize = 10.sp)
                            val distanceText = if (diffFromCurrent >= 0) "+${String.format(Locale.US, "%.${currentAsset.priceDecimals}f", diffFromCurrent)}" else String.format(Locale.US, "%.${currentAsset.priceDecimals}f", diffFromCurrent)
                            Text(
                                text = "$distanceText (${String.format(Locale.US, "%.2f", pctFromCurrent)}% away)",
                                color = if (alertDirection) BullishGreen else BearishRed,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background((if (alertDirection) BullishGreen else BearishRed).copy(alpha = 0.15f))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = if (alertDirection) "স্পর্শ: ≥ $targetPriceInput" else "স্পর্শ: ≤ $targetPriceInput",
                                color = if (alertDirection) BullishGreen else BearishRed,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Notification Preferences Row (Sound & Vibration)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.VolumeUp, contentDescription = null, tint = if (ruleSoundEnabled) CyberCyan else TextMuted, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("সাউন্ড", color = TextPrimary, fontSize = 11.sp)
                            Spacer(modifier = Modifier.width(6.dp))
                            Switch(
                                checked = ruleSoundEnabled,
                                onCheckedChange = { ruleSoundEnabled = it },
                                colors = SwitchDefaults.colors(checkedThumbColor = CyberCyan, checkedTrackColor = CyberCyan.copy(alpha = 0.3f)),
                                modifier = Modifier.size(width = 36.dp, height = 22.dp)
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Vibration, contentDescription = null, tint = if (ruleVibeEnabled) CryptoGold else TextMuted, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("ভাইব্রেশন", color = TextPrimary, fontSize = 11.sp)
                            Spacer(modifier = Modifier.width(6.dp))
                            Switch(
                                checked = ruleVibeEnabled,
                                onCheckedChange = { ruleVibeEnabled = it },
                                colors = SwitchDefaults.colors(checkedThumbColor = CryptoGold, checkedTrackColor = CryptoGold.copy(alpha = 0.3f)),
                                modifier = Modifier.size(width = 36.dp, height = 22.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Confirmation feedback message
                    creationSuccessMsg?.let { msg ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(6.dp))
                                .background(BullishGreen.copy(alpha = 0.15f))
                                .padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Check, contentDescription = null, tint = BullishGreen, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(msg, color = BullishGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                    }

                    // Save / Set Target Price Alert Button
                    Button(
                        onClick = {
                            val target = targetPriceInput.toDoubleOrNull() ?: currentAsset.currentPrice
                            viewModel.addCustomPriceAlert(
                                asset = currentAsset,
                                targetPrice = target,
                                isAbove = alertDirection,
                                soundEnabled = ruleSoundEnabled,
                                vibrationEnabled = ruleVibeEnabled
                            )
                            creationSuccessMsg = "🎯 ${currentAsset.symbol} এ টার্গেট $targetPriceInput অ্যালার্ট সফলভাবে যুক্ত হয়েছে!"
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CyberCyan),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .testTag("create_target_price_alert_button")
                    ) {
                        Icon(Icons.Default.NotificationsActive, contentDescription = null, tint = DarkNavyBg, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "প্রাইস অ্যালার্ট সক্রিয় করুন",
                            color = DarkNavyBg,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // 3. Active Custom Price Alerts List
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.NotificationsActive, contentDescription = null, tint = CryptoGold, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "আপনার নির্ধারিত প্রাইস অ্যালার্টসমূহ (${alertRules.size})",
                        color = TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        if (alertRules.isEmpty()) {
            item {
                Card(
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = CardSurface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, CardBorder, RoundedCornerShape(10.dp))
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Default.Radar, contentDescription = null, tint = TextMuted, modifier = Modifier.size(36.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "কোনো সক্রিয় কাস্টম অ্যালার্ট নেই",
                            color = TextPrimary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "পকেট অপশনে ট্রেড এন্ট্রি নেওয়ার জন্য উপরে টার্গেট প্রাইস সেট করুন। লাইভ ফিড সেই লেভেলে পৌঁছামাত্র অ্যালার্ট পাবেন।",
                            color = TextMuted,
                            fontSize = 11.sp,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }
            }
        } else {
            items(alertRules, key = { it.id }) { rule ->
                val matchingAsset = allAssets.firstOrNull { it.id == rule.assetId }
                    ?: allAssets.firstOrNull { it.symbol == rule.assetSymbol }
                ActiveAlertCard(
                    rule = rule,
                    liveAsset = matchingAsset,
                    onToggle = { isEnabled -> viewModel.toggleAlertRule(rule.id, isEnabled) },
                    onTestTrigger = { viewModel.testTriggerAlertRule(rule) },
                    onDelete = { viewModel.deleteAlertRule(rule.id) }
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(70.dp))
        }
    }

    // Modal: IQ Option asset picker (Digital / Binary / Forex / Blitz)
    if (showAssetPickerModal) {
        AssetPickerDialog(
            allAssets = allAssets,
            initialMarket = currentAsset.marketType,
            onBrowse = { viewModel.marketEngine.setBrowsingMarket(it) },
            onDismiss = { showAssetPickerModal = false },
            onSelect = { asset ->
                viewModel.selectAsset(asset.id)
                showAssetPickerModal = false
            }
        )
    }
}

/**
 * Card displaying an active custom alert with live proximity progress and action controls.
 */
@Composable
fun ActiveAlertCard(
    rule: AlertRuleEntity,
    liveAsset: TradingAsset?,
    onToggle: (Boolean) -> Unit,
    onTestTrigger: () -> Unit,
    onDelete: () -> Unit
) {
    val isAbove = rule.alertType.contains("ABOVE")
    val directionLabel = if (isAbove) "উর্ধ্বে (≥)" else "নিম্নে (≤)"
    val directionColor = if (isAbove) BullishGreen else BearishRed

    val currentPrice = liveAsset?.currentPrice ?: 0.0
    val decimals = liveAsset?.priceDecimals ?: 5
    val targetVal = rule.targetValue
    val remainingDistance = if (isAbove) targetVal - currentPrice else currentPrice - targetVal
    val percentDistance = if (currentPrice > 0) (abs(remainingDistance) / currentPrice) * 100.0 else 0.0

    // Proximity ratio (0.0 to 1.0)
    val proximityProgress = if (remainingDistance <= 0) 1.0f else (1.0f - (percentDistance.toFloat() / 2.0f)).coerceIn(0.1f, 1.0f)

    Card(
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = CardSurface),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, if (rule.isEnabled) directionColor.copy(alpha = 0.4f) else CardBorder, RoundedCornerShape(10.dp))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(directionColor.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isAbove) Icons.Default.TrendingUp else Icons.Default.TrendingDown,
                            contentDescription = null,
                            tint = directionColor,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = rule.assetSymbol,
                            color = TextPrimary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "টার্গেট: $directionLabel ${String.format(Locale.US, "%.${decimals}f", targetVal)}",
                            color = directionColor,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                // Enable/Pause Switch
                Switch(
                    checked = rule.isEnabled,
                    onCheckedChange = onToggle,
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = CyberCyan,
                        checkedTrackColor = CyberCyan.copy(alpha = 0.3f),
                        uncheckedThumbColor = TextMuted,
                        uncheckedTrackColor = CardSurfaceElevated
                    ),
                    modifier = Modifier.size(width = 38.dp, height = 24.dp)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Live Price vs Target Indicator
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(6.dp))
                    .background(CardSurfaceElevated)
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("লাইভ ফিড:", color = TextMuted, fontSize = 9.sp)
                    Text(
                        text = String.format(Locale.US, "%.${decimals}f", currentPrice),
                        color = TextPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    val statusText = if (remainingDistance <= 0) "🎯 লেভেল স্পর্শ করেছে!" else "${String.format(Locale.US, "%.${decimals}f", remainingDistance)} বাকি"
                    val statusColor = if (remainingDistance <= 0) BullishGreen else TextSecondary
                    Text("টার্গেট ব্যবধান:", color = TextMuted, fontSize = 9.sp)
                    Text(
                        text = "$statusText (${String.format(Locale.US, "%.2f", percentDistance)}%)",
                        color = statusColor,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Proximity Visual Progress Bar
            LinearProgressIndicator(
                progress = { proximityProgress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(4.dp)
                    .clip(RoundedCornerShape(2.dp)),
                color = if (remainingDistance <= 0) BullishGreen else CyberCyan,
                trackColor = CardSurfaceElevated,
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Controls Footer: Test Trigger & Delete
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Test button: allows verifying sound and notification banner immediately
                Button(
                    onClick = onTestTrigger,
                    colors = ButtonDefaults.buttonColors(containerColor = CardSurfaceElevated),
                    shape = RoundedCornerShape(6.dp),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    modifier = Modifier.height(26.dp)
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null, tint = CryptoGold, modifier = Modifier.size(12.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("🔔 টেস্ট ট্রিগার", color = CryptoGold, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }

                IconButton(onClick = onDelete, modifier = Modifier.size(24.dp)) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = BearishRed, modifier = Modifier.size(16.dp))
                }
            }
        }
    }
}

/**
 * Tab 2: AI Market Scanner & Audio Preferences.
 */
@Composable
fun ScannerAndSettingsTab(
    viewModel: TradeProViewModel,
    isAutoScannerActive: Boolean,
    minConfidence: Int,
    soundEnabled: Boolean,
    vibrationEnabled: Boolean
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = CardSurface),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, CardBorder, RoundedCornerShape(12.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(CyberCyan.copy(alpha = 0.2f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Radar, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(20.dp))
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text("২৪/৭ স্বয়ংক্রিয় এআই স্ক্যানার", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                Text(
                                    text = if (isAutoScannerActive) "পকেট অপশন OTC ও রিয়েল মার্কেট স্ক্যান চলছে" else "স্ক্যানার সাময়িক বন্ধ আছে",
                                    color = if (isAutoScannerActive) BullishGreen else TextMuted,
                                    fontSize = 11.sp
                                )
                            }
                        }

                        Switch(
                            checked = isAutoScannerActive,
                            onCheckedChange = { viewModel.alertEngine.setAutoScannerActive(it) },
                            colors = SwitchDefaults.colors(checkedThumbColor = CyberCyan, checkedTrackColor = CyberCyan.copy(alpha = 0.3f))
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Sound & Vibration Toggles
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(CardSurfaceElevated)
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(if (soundEnabled) Icons.Default.VolumeUp else Icons.Default.VolumeOff, contentDescription = null, tint = if (soundEnabled) CyberCyan else TextMuted, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("অ্যালার্ট সাউন্ড", color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                            Spacer(modifier = Modifier.width(8.dp))
                            Switch(
                                checked = soundEnabled,
                                onCheckedChange = { viewModel.setSoundEnabled(it) },
                                colors = SwitchDefaults.colors(checkedThumbColor = CyberCyan, checkedTrackColor = CyberCyan.copy(alpha = 0.3f)),
                                modifier = Modifier.size(width = 38.dp, height = 24.dp)
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Vibration, contentDescription = null, tint = if (vibrationEnabled) CryptoGold else TextMuted, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("ভাইব্রেশন", color = TextPrimary, fontSize = 11.sp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Switch(
                                checked = vibrationEnabled,
                                onCheckedChange = { viewModel.setVibrationEnabled(it) },
                                colors = SwitchDefaults.colors(checkedThumbColor = CryptoGold, checkedTrackColor = CryptoGold.copy(alpha = 0.3f)),
                                modifier = Modifier.size(width = 38.dp, height = 24.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Minimum Confidence Threshold
                    Text("সর্বনিম্ন সেটআপ স্ট্রেংথ (৮০+ = শুধু UP+/DOWN+):", color = TextSecondary, fontSize = 11.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(50, 65, 80).forEach { th ->
                            val isSel = minConfidence == th
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (isSel) CyberCyan.copy(alpha = 0.2f) else CardSurfaceElevated)
                                    .border(1.dp, if (isSel) CyberCyan else CardBorder, RoundedCornerShape(6.dp))
                                    .clickable { viewModel.alertEngine.setMinConfidenceThreshold(th) }
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = ">=$th",
                                    color = if (isSel) CyberCyan else TextSecondary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Sound Test Chips
                    Text("অ্যালার্ট সাউন্ড টেস্টিং:", color = TextMuted, fontSize = 10.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TestAudioChip("Call চিম", BullishGreen) { viewModel.soundManager.playCallAlert(soundEnabled = true, vibrationEnabled = vibrationEnabled) }
                        TestAudioChip("Put চিম", BearishRed) { viewModel.soundManager.playPutAlert(soundEnabled = true, vibrationEnabled = vibrationEnabled) }
                        TestAudioChip("জরুরি সাইরেন", CryptoGold) { viewModel.soundManager.playUrgentAlert(soundEnabled = true, vibrationEnabled = vibrationEnabled) }
                    }
                }
            }
        }
    }
}

@Composable
fun TestAudioChip(label: String, color: Color, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(color.copy(alpha = 0.15f))
            .border(1.dp, color.copy(alpha = 0.3f), RoundedCornerShape(6.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 5.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.VolumeUp, contentDescription = null, tint = color, modifier = Modifier.size(12.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text(label, color = color, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
    }
}

/**
 * Tab 3: Historical Notifications Feed.
 */
@Composable
fun NotificationsFeedTab(
    viewModel: TradeProViewModel,
    notifications: List<AlertNotificationEntity>
) {
    val dateFormat = remember { SimpleDateFormat("HH:mm:ss", Locale.getDefault()) }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "ট্রিগার হওয়া নোটিফিকেশন (${notifications.size})",
                color = TextSecondary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )

            if (notifications.isNotEmpty()) {
                Text(
                    text = "সব মুছুন",
                    color = BearishRed,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.clickable { viewModel.clearNotifications() }
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        if (notifications.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(CardSurface)
                    .border(1.dp, CardBorder, RoundedCornerShape(8.dp))
                    .padding(28.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "এখনও কোনো অ্যালার্ট ট্রিগার হয়নি। টার্গেট প্রাইস ও স্ক্যানার ব্যাকগ্রাউন্ডে সক্রিয় আছে।",
                    color = TextMuted,
                    fontSize = 12.sp
                )
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(notifications, key = { it.id }) { notif ->
                    val badgeColor = if (notif.title.contains("CALL")) BullishGreen else if (notif.title.contains("PUT")) BearishRed else CyberCyan
                    Card(
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = CardSurface),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, CardBorder, RoundedCornerShape(10.dp))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(badgeColor.copy(alpha = 0.2f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Notifications, contentDescription = null, tint = badgeColor, modifier = Modifier.size(18.dp))
                            }

                            Spacer(modifier = Modifier.width(10.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = notif.title,
                                        color = TextPrimary,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = dateFormat.format(Date(notif.timestamp)),
                                        color = TextMuted,
                                        fontSize = 10.sp
                                    )
                                }
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = notif.message,
                                    color = TextSecondary,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                }
                item {
                    Spacer(modifier = Modifier.height(70.dp))
                }
            }
        }
    }
}
