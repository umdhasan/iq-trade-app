package com.example.engine

import com.example.engine.feed.BinanceFeed
import com.example.engine.feed.PriceTick
import com.example.engine.feed.Quote
import com.example.engine.feed.YahooFeed
import com.example.model.Candle
import com.example.model.ExpiryTime
import com.example.model.FeedRef
import com.example.model.FeedSource
import com.example.model.MarketCategory
import com.example.model.MarketType
import com.example.model.QuoteStatus
import com.example.model.TradingAsset
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.TreeMap
import kotlin.math.max
import kotlin.math.min

data class ChartData(
    val candles: List<Candle>,
    /** true while sub-minute candles are still collecting enough live ticks */
    val warmingUp: Boolean
)

data class FeedHealth(
    val binanceAgeSec: Long = -1,
    val yahooAgeSec: Long = -1,
    val yahooBackoff: Boolean = false
)

/**
 * REAL market data engine.
 *
 * Nothing here is simulated: every price comes from Binance (crypto) or Yahoo Finance (forex,
 * indices, commodities, stocks, ETFs). Derived assets (Gold/Silver, Bitcoin/Gold ...) are computed
 * from two real prices. Assets without any public feed are shown as NO_FEED.
 */
class MarketEngine(private val scope: CoroutineScope) {

    private val catalog: List<TradingAsset> = IqCatalog.build()
    private val byId: Map<String, TradingAsset> = catalog.associateBy { it.id }

    private val _assets = MutableStateFlow(catalog.map { initial(it) })
    val assets: StateFlow<List<TradingAsset>> = _assets.asStateFlow()

    private val _selectedAssetId = MutableStateFlow(DEFAULT_ASSET_ID)
    val selectedAssetId: StateFlow<String> = _selectedAssetId.asStateFlow()

    private val _watchlist = MutableStateFlow(DEFAULT_WATCHLIST)
    val watchlist: StateFlow<Set<String>> = _watchlist.asStateFlow()

    private val alertIds = MutableStateFlow<Set<String>>(emptySet())

    private val _health = MutableStateFlow(FeedHealth())
    val health: StateFlow<FeedHealth> = _health.asStateFlow()

    private val lock = Any()
    private val quotes = HashMap<String, Quote>()
    private val m1 = HashMap<String, TreeMap<Long, Candle>>()
    private val histNextAt = HashMap<String, Long>()
    private val histLoading = HashSet<String>()

    /** Sub-minute candles (5s / 15s / 30s) built from live ticks of the selected asset only. */
    private val subCandles = HashMap<Int, TreeMap<Long, Candle>>()
    private var subFeedKey: String = ""

    @Volatile private var browsingMarket: MarketType? = null
    @Volatile private var selectedFeed: FeedRef = byId[DEFAULT_ASSET_ID]?.feed ?: catalog.first().feed
    @Volatile private var yahooBackoffUntil = 0L
    @Volatile private var lastYahooOkMs = 0L
    @Volatile private var lastBinanceMs = 0L
    @Volatile private var fallbackCursor = 0

    private val usedKeys: Set<String> = HashSet<String>().also { set ->
        catalog.forEach { a -> rawKeysOf(a.feed).forEach { set.add(it) } }
    }

    private val binance = BinanceFeed(
        onQuote = { symbol, q -> onBinanceQuote(symbol, q) },
        onTick = { symbol, t -> onBinanceTick(symbol, t) }
    )
    private val yahoo = YahooFeed()

    init {
        binance.start()
        applySelection(DEFAULT_ASSET_ID)
        scope.launch(Dispatchers.IO) { fastSelectedLoop() }
        scope.launch(Dispatchers.IO) { batchLoop() }
        scope.launch(Dispatchers.IO) { historyLoop() }
        scope.launch(Dispatchers.Default) { flushLoop() }
    }

    fun shutdown() {
        binance.stop()
    }

    // =====================================================================================
    // Public API
    // =====================================================================================

    fun selectAsset(assetId: String) {
        if (!byId.containsKey(assetId)) return
        _selectedAssetId.value = assetId
        applySelection(assetId)
    }

    fun getSelectedAsset(): TradingAsset? {
        val id = _selectedAssetId.value
        return _assets.value.firstOrNull { it.id == id } ?: _assets.value.firstOrNull()
    }

    /** Tell the engine which market list is on screen so only those prices are polled. */
    fun setBrowsingMarket(market: MarketType?) {
        browsingMarket = market
    }

    /** Assets with an enabled price / RSI alert must keep receiving prices in the background. */
    fun setAlertAssets(ids: Set<String>) {
        alertIds.value = ids
    }

    fun toggleWatch(assetId: String) {
        val cur = _watchlist.value
        _watchlist.value = if (cur.contains(assetId)) cur - assetId else cur + assetId
    }

    /** Assets the background signal scanner looks at (watch-list + selected asset). */
    fun scanTargets(): List<TradingAsset> {
        val ids = LinkedHashSet<String>()
        ids.add(_selectedAssetId.value)
        ids.addAll(_watchlist.value)
        val current = _assets.value.associateBy { it.id }
        return ids.mapNotNull { current[it] }.filter { it.hasPrice }
    }

    /** Candles for charts / indicators in the selected timeframe. */
    fun chartData(asset: TradingAsset, expiry: ExpiryTime): ChartData {
        if (asset.feed.source == FeedSource.NONE) return ChartData(emptyList(), false)
        if (expiry.seconds >= 60) {
            val base = baseMinuteCandles(asset.feed)
            return ChartData(aggregate(base, expiry.seconds / 60), false)
        }
        val sub = synchronized(lock) {
            if (subFeedKey == asset.feed.key) subCandles[expiry.seconds]?.values?.toList() else null
        } ?: emptyList()
        return ChartData(sub, sub.size < 35)
    }

    /** Convenience for the alert engine: 1-minute candles of an asset. */
    fun candlesFor(asset: TradingAsset, expiry: ExpiryTime = ExpiryTime.MIN_1): List<Candle> {
        return chartData(asset, expiry).candles
    }

    // =====================================================================================
    // Selection
    // =====================================================================================

    private fun applySelection(assetId: String) {
        val a = byId[assetId] ?: return
        selectedFeed = a.feed
        synchronized(lock) {
            subCandles.clear()
            subFeedKey = a.feed.key
            for (s in listOf(5, 15, 30)) subCandles[s] = TreeMap()
        }
        // real-time trade stream for crypto (single symbol)
        val binKey = rawKeysOf(a.feed).firstOrNull { it.startsWith("B:") }
        binance.watchTrades(binKey?.substring(2))
        // history right away
        for (key in rawKeysOf(a.feed)) {
            scope.launch(Dispatchers.IO) { loadHistory(key, force = false) }
        }
    }

    // =====================================================================================
    // Polling loops
    // =====================================================================================

    /** Selected asset: latest candles + quote every ~1.2 s from Yahoo (crypto uses the Binance socket). */
    private suspend fun fastSelectedLoop() {
        while (scope.isActive) {
            val feed = selectedFeed
            val syms = rawKeysOf(feed).filter { it.startsWith("Y:") }.map { it.substring(2) }
            if (syms.isEmpty() || System.currentTimeMillis() < yahooBackoffUntil) {
                delay(1000L)
                continue
            }
            for (sym in syms) {
                val r = yahoo.fetchRecent(sym)
                if (r.rateLimited) {
                    yahooBackoffUntil = System.currentTimeMillis() + 30_000L
                    break
                }
                val v = r.value
                if (v != null) {
                    lastYahooOkMs = System.currentTimeMillis()
                    mergeCandles("Y:$sym", v.second)
                    onYahooQuote(sym, v.first)
                }
            }
            delay(1200L)
        }
    }

    /** Market lists + watch-list: one batched request per 20 symbols every ~5 s. */
    private suspend fun batchLoop() {
        while (scope.isActive) {
            if (System.currentTimeMillis() < yahooBackoffUntil) {
                delay(2000L)
                continue
            }
            val selectedSyms = rawKeysOf(selectedFeed).filter { it.startsWith("Y:") }.map { it.substring(2) }.toSet()
            val syms = LinkedHashSet<String>()
            val market = browsingMarket
            if (market != null) {
                for (a in catalog) {
                    if (a.marketType == market) addYahooSymbols(a.feed, syms)
                }
            }
            val wl = _watchlist.value
            for (id in wl) byId[id]?.let { addYahooSymbols(it.feed, syms) }
            for (id in alertIds.value) byId[id]?.let { addYahooSymbols(it.feed, syms) }
            syms.removeAll(selectedSyms)

            val list = syms.toList()
            for (chunk in list.chunked(20)) {
                val r = yahoo.fetchSpark(chunk)
                if (r.rateLimited) {
                    yahooBackoffUntil = System.currentTimeMillis() + 30_000L
                    break
                }
                val map = r.value
                if (map != null) {
                    if (map.isNotEmpty()) lastYahooOkMs = System.currentTimeMillis()
                    for ((s, q) in map) onYahooQuote(s, q)
                } else {
                    // batch endpoint unavailable -> fall back to single requests (a few per cycle)
                    var done = 0
                    var idx = fallbackCursor
                    while (done < 4 && chunk.isNotEmpty()) {
                        val sym = chunk[idx % chunk.size]
                        idx++
                        done++
                        val one = yahoo.fetchRecent(sym)
                        if (one.rateLimited) {
                            yahooBackoffUntil = System.currentTimeMillis() + 30_000L
                            break
                        }
                        one.value?.let {
                            lastYahooOkMs = System.currentTimeMillis()
                            onYahooQuote(sym, it.first)
                        }
                    }
                    fallbackCursor = idx
                }
                delay(250L)
            }
            delay(5000L)
        }
    }

    /** Keeps 1-minute history for the selected asset and every watch-list asset. */
    private suspend fun historyLoop() {
        while (scope.isActive) {
            val keys = LinkedHashSet<String>()
            keys.addAll(rawKeysOf(selectedFeed))
            for (id in _watchlist.value) byId[id]?.let { keys.addAll(rawKeysOf(it.feed)) }
            for (id in alertIds.value) byId[id]?.let { keys.addAll(rawKeysOf(it.feed)) }
            for (key in keys) {
                if (System.currentTimeMillis() < yahooBackoffUntil && key.startsWith("Y:")) continue
                loadHistory(key, force = false)
            }
            delay(3000L)
        }
    }

    private fun loadHistory(key: String, force: Boolean) {
        val now = System.currentTimeMillis()
        synchronized(lock) {
            if (histLoading.contains(key)) return
            if (!force && now < (histNextAt[key] ?: 0L)) return
            histLoading.add(key)
        }
        var ok = false
        try {
            if (key.startsWith("B:")) {
                val list = binance.fetchKlines(key.substring(2), 500)
                if (list.isNotEmpty()) {
                    mergeCandles(key, list)
                    ok = true
                }
            } else if (key.startsWith("Y:")) {
                val r = yahoo.fetchHistory(key.substring(2))
                if (r.rateLimited) yahooBackoffUntil = System.currentTimeMillis() + 30_000L
                val v = r.value
                if (v != null) {
                    mergeCandles(key, v.second)
                    onYahooQuote(key.substring(2), v.first)
                    lastYahooOkMs = System.currentTimeMillis()
                    ok = true
                }
            }
        } finally {
            synchronized(lock) {
                histLoading.remove(key)
                histNextAt[key] = System.currentTimeMillis() + if (ok) 120_000L else 15_000L
            }
        }
    }

    // =====================================================================================
    // Quote / candle updates
    // =====================================================================================

    private fun onBinanceQuote(symbol: String, q: Quote) {
        val key = "B:$symbol"
        if (!usedKeys.contains(key)) return
        lastBinanceMs = System.currentTimeMillis()
        updateQuote(key, q)
        applyPrice(key, q.price, q.marketTimeMs)
        afterQuote(key)
    }

    private fun onBinanceTick(symbol: String, t: PriceTick) {
        val key = "B:$symbol"
        lastBinanceMs = System.currentTimeMillis()
        val old = synchronized(lock) { quotes[key] }
        if (old != null) {
            updateQuote(key, old.copy(price = t.price, marketTimeMs = t.timeMs, receivedMs = System.currentTimeMillis()))
        }
        applyPrice(key, t.price, t.timeMs)
        afterQuote(key)
    }

    private fun onYahooQuote(symbol: String, q: Quote) {
        val key = "Y:$symbol"
        updateQuote(key, q)
        applyPrice(key, q.price, System.currentTimeMillis())
        afterQuote(key)
    }

    private fun updateQuote(key: String, q: Quote) {
        val now = System.currentTimeMillis()
        synchronized(lock) {
            val old = quotes[key]
            if (old == null) {
                quotes[key] = q.copy(prevPrice = q.price, receivedMs = now)
            } else if (q.marketTimeMs < old.marketTimeMs) {
                // older data than what we already have -> only mark the feed as alive
                quotes[key] = old.copy(receivedMs = now)
            } else {
                val prev = if (old.price != q.price) old.price else old.prevPrice
                quotes[key] = q.copy(prevPrice = prev, receivedMs = now)
            }
        }
    }

    /** Move the live 1-minute candle with the newest price. */
    private fun applyPrice(key: String, price: Double, timeMs: Long) {
        if (price <= 0.0) return
        synchronized(lock) {
            val map = m1[key] ?: return
            val minute = timeMs / 60_000L * 60_000L
            val last = map.lastEntry()?.value
            if (last != null && minute < last.timestamp) return // out-of-order tick
            val cur = map[minute]
            if (cur == null) {
                val open = last?.close ?: price
                map[minute] = Candle(minute, open, max(open, price), min(open, price), price, 0.0)
                while (map.size > MAX_M1) map.pollFirstEntry()
            } else {
                map[minute] = cur.copy(high = max(cur.high, price), low = min(cur.low, price), close = price)
            }
        }
    }

    /** After a raw quote changed: feed the selected asset's sub-minute candles. */
    private fun afterQuote(rawKey: String) {
        val feed = selectedFeed
        if (feed.source == FeedSource.NONE) return
        if (!rawKeysOf(feed).contains(rawKey)) return
        synchronized(lock) {
            val price = quoteForLocked(feed)?.price ?: return
            if (subFeedKey != feed.key) return
            val now = System.currentTimeMillis()
            for (size in intArrayOf(5, 15, 30)) {
                val map = subCandles.getOrPut(size) { TreeMap() }
                val bucket = now / (size * 1000L) * (size * 1000L)
                val cur = map[bucket]
                if (cur == null) {
                    val open = map.lastEntry()?.value?.close ?: price
                    map[bucket] = Candle(bucket, open, max(open, price), min(open, price), price, 1.0)
                    while (map.size > 400) map.pollFirstEntry()
                } else {
                    map[bucket] = cur.copy(
                        high = max(cur.high, price),
                        low = min(cur.low, price),
                        close = price,
                        volume = cur.volume + 1.0
                    )
                }
            }
        }
    }

    private fun mergeCandles(key: String, list: List<Candle>) {
        if (list.isEmpty()) return
        synchronized(lock) {
            val map = m1.getOrPut(key) { TreeMap() }
            for (c in list) {
                val ts = c.timestamp / 60_000L * 60_000L
                val ex = map[ts]
                map[ts] = if (ex == null) {
                    c.copy(timestamp = ts)
                } else {
                    Candle(ts, c.open, max(c.high, ex.high), min(c.low, ex.low), c.close, max(c.volume, ex.volume))
                }
            }
            while (map.size > MAX_M1) map.pollFirstEntry()
        }
    }

    // =====================================================================================
    // Candle building
    // =====================================================================================

    private fun baseMinuteCandles(feed: FeedRef): List<Candle> {
        synchronized(lock) {
            if (feed.source != FeedSource.DERIVED) {
                return m1[feed.key]?.values?.toList() ?: emptyList()
            }
            val n = m1[feed.numeratorKey] ?: return emptyList()
            val d = m1[feed.denominatorKey] ?: return emptyList()
            val out = ArrayList<Candle>()
            for ((ts, nc) in n) {
                val dc = d[ts] ?: continue
                if (dc.open == 0.0 || dc.close == 0.0) continue
                val o = if (feed.multiply) nc.open * dc.open else nc.open / dc.open
                val c = if (feed.multiply) nc.close * dc.close else nc.close / dc.close
                out.add(Candle(ts, o, max(o, c), min(o, c), c, 0.0))
            }
            return out
        }
    }

    private fun aggregate(base: List<Candle>, minutes: Int): List<Candle> {
        if (minutes <= 1 || base.isEmpty()) return base
        val span = minutes * 60_000L
        val out = ArrayList<Candle>()
        var bucket = Long.MIN_VALUE
        var o = 0.0; var h = 0.0; var l = 0.0; var c = 0.0; var v = 0.0
        for (k in base) {
            val b = k.timestamp / span * span
            if (b != bucket) {
                if (bucket != Long.MIN_VALUE) out.add(Candle(bucket, o, h, l, c, v))
                bucket = b; o = k.open; h = k.high; l = k.low; c = k.close; v = k.volume
            } else {
                h = max(h, k.high); l = min(l, k.low); c = k.close; v += k.volume
            }
        }
        if (bucket != Long.MIN_VALUE) out.add(Candle(bucket, o, h, l, c, v))
        return out
    }

    // =====================================================================================
    // Quotes -> assets
    // =====================================================================================

    private fun quoteForLocked(feed: FeedRef): Quote? {
        return when (feed.source) {
            FeedSource.BINANCE, FeedSource.YAHOO -> quotes[feed.key]
            FeedSource.NONE -> null
            FeedSource.DERIVED -> {
                val n = quotes[feed.numeratorKey] ?: return null
                val d = quotes[feed.denominatorKey] ?: return null
                if (d.price == 0.0 || n.price == 0.0) return null
                fun comb(a: Double, b: Double): Double =
                    if (feed.multiply) a * b else if (b != 0.0) a / b else 0.0
                val price = comb(n.price, d.price)
                val prev = comb(n.prevPrice, d.prevPrice).let { if (it > 0.0) it else price }
                val ref = comb(n.refClose, d.refClose).let { if (it > 0.0) it else price }
                Quote(
                    price = price,
                    prevPrice = prev,
                    refClose = ref,
                    dayHigh = max(price, ref),
                    dayLow = min(price, ref),
                    marketTimeMs = min(n.marketTimeMs, d.marketTimeMs),
                    receivedMs = min(n.receivedMs, d.receivedMs)
                )
            }
        }
    }

    private fun initial(a: TradingAsset): TradingAsset {
        return if (a.feed.source == FeedSource.NONE) a.copy(status = QuoteStatus.NO_FEED) else a
    }

    private suspend fun flushLoop() {
        while (scope.isActive) {
            delay(600L)
            val now = System.currentTimeMillis()
            val out = ArrayList<TradingAsset>(catalog.size)
            synchronized(lock) {
                for (base in catalog) {
                    if (base.feed.source == FeedSource.NONE) {
                        out.add(base.copy(status = QuoteStatus.NO_FEED))
                        continue
                    }
                    val q = quoteForLocked(base.feed)
                    if (q == null) {
                        out.add(base)
                        continue
                    }
                    val change = if (q.refClose > 0.0) (q.price - q.refClose) / q.refClose * 100.0 else 0.0
                    val feedAlive = now - q.receivedMs < 40_000L
                    val marketOpen = now - q.marketTimeMs < 20 * 60_000L
                    out.add(
                        base.copy(
                            currentPrice = q.price,
                            prevPrice = q.prevPrice,
                            basePrice = q.refClose,
                            change24h = change,
                            high24h = q.dayHigh,
                            low24h = q.dayLow,
                            priceDecimals = decimalsFor(base.category, q.price),
                            status = if (feedAlive && marketOpen) QuoteStatus.LIVE else QuoteStatus.STALE,
                            lastUpdateMs = q.marketTimeMs
                        )
                    )
                }
            }
            _assets.value = out
            _health.value = FeedHealth(
                binanceAgeSec = if (lastBinanceMs == 0L) -1 else (now - lastBinanceMs) / 1000L,
                yahooAgeSec = if (lastYahooOkMs == 0L) -1 else (now - lastYahooOkMs) / 1000L,
                yahooBackoff = now < yahooBackoffUntil
            )
        }
    }

    // =====================================================================================
    // Helpers
    // =====================================================================================

    private fun addYahooSymbols(feed: FeedRef, into: MutableSet<String>) {
        for (k in rawKeysOf(feed)) if (k.startsWith("Y:")) into.add(k.substring(2))
    }

    companion object {
        const val DEFAULT_ASSET_ID = "blitz_eur_usd"
        const val MAX_M1 = 2000

        val DEFAULT_WATCHLIST: Set<String> = linkedSetOf(
            "blitz_eur_usd", "blitz_gbp_usd", "blitz_usd_jpy", "blitz_aud_usd",
            "blitz_gold", "blitz_bitcoin", "blitz_us_500", "blitz_ethereum"
        )

        fun rawKeysOf(feed: FeedRef): List<String> = when (feed.source) {
            FeedSource.DERIVED -> listOf(feed.numeratorKey, feed.denominatorKey)
            FeedSource.NONE -> emptyList()
            else -> listOf(feed.key)
        }

        fun decimalsFor(cat: MarketCategory, price: Double): Int = when {
            cat == MarketCategory.INDICES || cat == MarketCategory.STOCKS -> 2
            price >= 1000.0 -> 2
            price >= 100.0 -> 3
            price >= 10.0 -> 4
            price >= 0.1 -> 5
            price >= 0.01 -> 6
            else -> 7
        }
    }
}
