package com.example.engine.feed

import com.example.model.Candle
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder

/**
 * Yahoo Finance public chart endpoints (no key needed) for forex, indices, commodities, stocks, ETFs.
 *
 *  - [fetchSpark]   : one request returns the latest price of up to ~20 symbols (market list screens)
 *  - [fetchRecent]  : latest 1-minute candles of ONE symbol (selected asset, polled every ~1.5 s)
 *  - [fetchHistory] : 1-minute candle history of ONE symbol (chart + indicators)
 */
class YahooFeed {

    private val hosts = listOf("https://query1.finance.yahoo.com", "https://query2.finance.yahoo.com")
    @Volatile private var hostIdx = 0

    private fun host(): String = hosts[hostIdx % hosts.size]
    private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")

    class Result<T>(val value: T?, val code: Int) {
        val rateLimited: Boolean get() = code == 429
    }

    // ------------------------------------------------------------------ batch last price
    fun fetchSpark(symbols: List<String>): Result<Map<String, Quote>> {
        if (symbols.isEmpty()) return Result(emptyMap(), 200)
        val joined = symbols.joinToString(",") { enc(it) }
        val res = Net.get("${host()}/v8/finance/spark?symbols=$joined&range=1d&interval=1m")
        val body = res.body
        if (res.code != 200 || body == null) {
            if (res.code != 429) hostIdx++
            return Result(null, res.code)
        }
        return try {
            val out = HashMap<String, Quote>()
            val now = System.currentTimeMillis()
            val root = JSONObject(body)
            val sparkObj = root.optJSONObject("spark")
            val results = sparkObj?.optJSONArray("result")
            if (results != null) {
                for (i in 0 until results.length()) {
                    val r = results.optJSONObject(i) ?: continue
                    val sym = r.optString("symbol")
                    val resp = r.optJSONArray("response")?.optJSONObject(0) ?: continue
                    val q = quoteFromChart(resp, now) ?: continue
                    out[sym] = q
                }
            } else {
                // Alternative shape: { "EURUSD=X": { "close": [...], "chartPreviousClose": ... } }
                for (sym in symbols) {
                    val o = root.optJSONObject(sym) ?: continue
                    val closes = o.optJSONArray("close") ?: continue
                    val times = o.optJSONArray("timestamp")
                    var last = Double.NaN
                    var lastIdx = -1
                    for (j in closes.length() - 1 downTo 0) {
                        if (!closes.isNull(j)) { last = closes.getDouble(j); lastIdx = j; break }
                    }
                    if (last.isNaN()) continue
                    val prevClose = o.optDouble("chartPreviousClose", last)
                    val t = if (times != null && lastIdx >= 0 && lastIdx < times.length()) times.getLong(lastIdx) * 1000L else now
                    out[sym] = Quote(last, last, prevClose, last, last, t, now)
                }
            }
            Result(out, 200)
        } catch (e: Exception) {
            Result(null, -2)
        }
    }

    // ------------------------------------------------------------------ single symbol
    /** Candles of the last few minutes + the live quote. */
    fun fetchRecent(symbol: String): Result<Pair<Quote, List<Candle>>> {
        val nowSec = System.currentTimeMillis() / 1000L
        val url = "${host()}/v8/finance/chart/${enc(symbol)}?interval=1m" +
            "&period1=${nowSec - 600}&period2=${nowSec + 120}&includePrePost=false"
        return parseChart(Net.get(url))
    }

    /** Up to ~1 day of 1-minute candles (falls back to 5 days if the session just started). */
    fun fetchHistory(symbol: String): Result<Pair<Quote, List<Candle>>> {
        val first = parseChart(Net.get("${host()}/v8/finance/chart/${enc(symbol)}?interval=1m&range=1d&includePrePost=false"))
        val v = first.value
        if (v != null && v.second.size >= 150) return first
        val second = parseChart(Net.get("${host()}/v8/finance/chart/${enc(symbol)}?interval=1m&range=5d&includePrePost=false"))
        return if (second.value != null) second else first
    }

    private fun parseChart(res: Net.HttpResult): Result<Pair<Quote, List<Candle>>> {
        val body = res.body
        if (res.code != 200 || body == null) {
            if (res.code != 429 && res.code != -1) hostIdx++
            return Result(null, res.code)
        }
        return try {
            val root = JSONObject(body)
            val r0 = root.optJSONObject("chart")?.optJSONArray("result")?.optJSONObject(0)
                ?: return Result(null, -3)
            val now = System.currentTimeMillis()
            val candles = candlesFromChart(r0)
            val quote = quoteFromChart(r0, now, candles) ?: return Result(null, -4)
            Result(Pair(quote, candles), 200)
        } catch (e: Exception) {
            Result(null, -2)
        }
    }

    // ------------------------------------------------------------------ parsing helpers
    private fun candlesFromChart(r0: JSONObject): List<Candle> {
        val ts = r0.optJSONArray("timestamp") ?: return emptyList()
        val q = r0.optJSONObject("indicators")?.optJSONArray("quote")?.optJSONObject(0) ?: return emptyList()
        val o = q.optJSONArray("open")
        val h = q.optJSONArray("high")
        val l = q.optJSONArray("low")
        val c = q.optJSONArray("close")
        val v = q.optJSONArray("volume")
        if (o == null || h == null || l == null || c == null) return emptyList()
        val out = ArrayList<Candle>(ts.length())
        for (i in 0 until ts.length()) {
            if (c.isNull(i) || o.isNull(i) || h.isNull(i) || l.isNull(i)) continue
            out.add(
                Candle(
                    timestamp = ts.getLong(i) * 1000L,
                    open = o.getDouble(i),
                    high = h.getDouble(i),
                    low = l.getDouble(i),
                    close = c.getDouble(i),
                    volume = if (v != null && !v.isNull(i)) v.getDouble(i) else 0.0
                )
            )
        }
        return out
    }

    private fun quoteFromChart(r: JSONObject, now: Long, candles: List<Candle>? = null): Quote? {
        val meta = r.optJSONObject("meta") ?: return null
        var price = meta.optDouble("regularMarketPrice", Double.NaN)
        var marketTime = meta.optLong("regularMarketTime", 0L) * 1000L
        val cs = candles ?: candlesFromChart(r)
        if (cs.isNotEmpty()) {
            val last = cs.last()
            // The latest candle is the freshest price when it is newer than the meta price.
            if (price.isNaN() || last.timestamp + 60_000L > marketTime) {
                price = last.close
                marketTime = maxOf(marketTime, last.timestamp)
            }
        }
        if (price.isNaN() || price <= 0.0) return null
        if (marketTime <= 0L) marketTime = now
        val refClose = firstPositive(
            meta.optDouble("chartPreviousClose", Double.NaN),
            meta.optDouble("previousClose", Double.NaN),
            price
        )
        val hi = firstPositive(meta.optDouble("regularMarketDayHigh", Double.NaN), price)
        val lo = firstPositive(meta.optDouble("regularMarketDayLow", Double.NaN), price)
        return Quote(price, price, refClose, maxOf(hi, price), minOf(lo, price), marketTime, now)
    }

    private fun firstPositive(vararg v: Double): Double {
        for (x in v) if (!x.isNaN() && x > 0.0) return x
        return 0.0
    }
}
