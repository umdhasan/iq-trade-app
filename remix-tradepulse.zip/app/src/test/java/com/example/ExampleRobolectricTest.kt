package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.engine.HasanProSignal
import com.example.engine.SignalEngine
import com.example.engine.TechnicalAnalysisEngine
import com.example.model.Candle
import com.example.model.ExpiryTime
import com.example.model.MarketCategory
import com.example.model.MarketPlatform
import com.example.model.TradingAsset
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("TradePro IQ", appName)
  }

  @Test
  fun `technical indicators and signal generation`() {
    val candles = (1..30).map { i ->
      Candle(
        open = 100.0 + i * 0.1,
        high = 100.5 + i * 0.1,
        low = 99.8 + i * 0.1,
        close = 100.2 + i * 0.1,
        volume = 50.0 + i,
        timestamp = System.currentTimeMillis() + i * 1000L
      )
    }

    val indicators = TechnicalAnalysisEngine.analyze(candles)
    assertTrue(indicators.rsi14 in 0.0..100.0)
    assertTrue(indicators.bbUpper >= indicators.bbLower)

    val asset = TradingAsset(
      id = "test_eurusd",
      symbol = "EUR/USD",
      name = "Euro / US Dollar",
      category = MarketCategory.CURRENCIES,
      basePrice = 1.08450,
      currentPrice = 1.08500,
      prevPrice = 1.08480,
      change24h = 0.28,
      high24h = 1.08900,
      low24h = 1.08100,
      payoutPercent = 95,
      priceDecimals = 5,
      candles = candles
    )

    val signal = SignalEngine.generateSignal(
      asset = asset,
      indicators = indicators,
      platform = MarketPlatform.IQ_OPTION,
      expiryTime = ExpiryTime.MIN_1,
      baseTradeAmount = 10.0
    )

    assertNotNull(signal)
    assertTrue(signal.confidence in 50..100)
    assertTrue(signal.martingaleStep1 > 10.0)

    val hasan = HasanProSignal.evaluate(candles)
    assertNotNull(hasan.signalType)
    assertTrue(hasan.setupStrength in 50..100)
  }

  @Test
  fun `verify extended expiry times`() {
    val expiries = ExpiryTime.values()
    assertTrue(expiries.any { it.seconds == 5 && it.isBlitz })
    assertTrue(expiries.any { it.seconds == 15 && it.isBlitz })
    assertTrue(expiries.any { it.seconds == 30 && it.isBlitz })
    assertTrue(expiries.any { it.seconds == 60 })
    assertTrue(expiries.any { it.seconds == 120 })
    assertTrue(expiries.any { it.seconds == 300 })
    assertTrue(expiries.any { it.seconds == 600 })
    assertTrue(expiries.any { it.seconds == 900 })
    assertTrue(expiries.any { it.seconds == 1800 })
  }

  @Test
  fun `verify otcharts catalog mappings`() {
    assertEquals("EURUSD-OTC", com.example.engine.IqCatalog.getOtChartsCode("iq_eurusd_otc"))
    assertEquals("GBPUSD-OTC", com.example.engine.IqCatalog.getOtChartsCode("iq_gbpusd_otc"))
    assertEquals("USDJPY-OTC", com.example.engine.IqCatalog.getOtChartsCode("iq_usdjpy_otc"))
    assertEquals("AUDUSD-OTC", com.example.engine.IqCatalog.getOtChartsCode("iq_audusd_otc"))
    assertEquals("ETHUSD-OTC", com.example.engine.IqCatalog.getOtChartsCode("iq_ethusd_otc"))

    val url = com.example.engine.IqCatalog.getOtChartsUrl("iq_eurusd_otc", 60)
    assertNotNull(url)
    assertTrue(url!!.contains("EURUSD-OTC"))
    assertTrue(url.contains("m=iq"))
  }
}
