package com.example.engine

import android.annotation.SuppressLint
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * Headless WebView DOM/SSE Bridge for otcharts.com.
 * Streams 100% real IQ Option OTC prices, live candle OHLC, countdown timer, and confluence score.
 */
class OtChartsOtcEngine(
    private val context: Context,
    private val scope: CoroutineScope,
    private val onTickReceived: (otcCode: String, open: Double, high: Double, low: Double, close: Double, changePct: Double) -> Unit
) {
    private val mainHandler = Handler(Looper.getMainLooper())

    private val _countdownTimer = MutableStateFlow("00:00")
    val countdownTimer: StateFlow<String> = _countdownTimer.asStateFlow()

    private val _confluenceScore = MutableStateFlow("+0")
    val confluenceScore: StateFlow<String> = _confluenceScore.asStateFlow()

    private val _isSseLive = MutableStateFlow(false)
    val isSseLive: StateFlow<Boolean> = _isSseLive.asStateFlow()

    private val _currentOtcCode = MutableStateFlow("EURUSD-OTC")
    val currentOtcCode: StateFlow<String> = _currentOtcCode.asStateFlow()

    private var headlessWebView: WebView? = null
    private var isEngineActive = true

    init {
        mainHandler.post {
            setupHeadlessWebView()
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupHeadlessWebView() {
        if (!isEngineActive) return
        try {
            val wv = WebView(context).apply {
                settings.apply {
                    javaScriptEnabled = true
                    domStorageEnabled = true
                    databaseEnabled = true
                    useWideViewPort = true
                    loadWithOverviewMode = true
                    mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                    userAgentString = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36"
                    cacheMode = WebSettings.LOAD_DEFAULT
                }

                val cookieManager = CookieManager.getInstance()
                cookieManager.setAcceptCookie(true)
                cookieManager.setAcceptThirdPartyCookies(this, true)

                addJavascriptInterface(AndroidOtcBridge(), "AndroidOtcBridge")

                webChromeClient = WebChromeClient()
                webViewClient = object : WebViewClient() {
                    override fun onPageFinished(view: WebView?, url: String?) {
                        super.onPageFinished(view, url)
                        injectOtcObserver(view)
                    }
                }
            }
            headlessWebView = wv
            loadOtcUrl(_currentOtcCode.value, 60)
        } catch (_: Throwable) {
            // Graceful initialization fallback in non-standard test runners
        }
    }

    private fun injectOtcObserver(view: WebView?) {
        val script = """
            (function() {
                if (window.__otcBridgeInjected) return;
                window.__otcBridgeInjected = true;
                
                setInterval(function() {
                    try {
                        var ohlcBolds = document.querySelectorAll('.ohlc-readout b');
                        if (ohlcBolds && ohlcBolds.length >= 4) {
                            var o = parseFloat(ohlcBolds[0].innerText.replace(/[^0-9.]/g, '')) || 0.0;
                            var h = parseFloat(ohlcBolds[1].innerText.replace(/[^0-9.]/g, '')) || 0.0;
                            var l = parseFloat(ohlcBolds[2].innerText.replace(/[^0-9.]/g, '')) || 0.0;
                            var c = parseFloat(ohlcBolds[3].innerText.replace(/[^0-9.]/g, '')) || 0.0;
                            
                            var changeElem = document.querySelector('.ohlc-up, .ohlc-down');
                            var chPct = 0.0;
                            if (changeElem) {
                                var txt = changeElem.innerText.replace(/%/g, '').trim();
                                chPct = parseFloat(txt) || 0.0;
                                if (changeElem.classList.contains('ohlc-down') && chPct > 0) {
                                    chPct = -chPct;
                                }
                            }
                            
                            var symElem = document.querySelector('.search-text');
                            var sym = symElem ? symElem.innerText.trim() : "";
                            
                            var timerElem = document.querySelector('.rail-section .rail-value.mono');
                            var timer = timerElem ? timerElem.innerText.trim() : "";
                            
                            var confElem = document.querySelector('.conf-value');
                            var conf = confElem ? confElem.innerText.trim() : "";
                            
                            var liveElem = document.querySelector('.feed-badge.live');
                            var isLive = liveElem != null;
                            
                            if (c > 0 && window.AndroidOtcBridge) {
                                window.AndroidOtcBridge.onPriceTick(sym, o, h, l, c, chPct, timer, conf, isLive);
                            }
                        }
                    } catch(e) {}
                }, 400);
            })();
        """.trimIndent()

        view?.evaluateJavascript(script, null)
    }

    private fun loadOtcUrl(otcCode: String, timeframeSec: Int) {
        val url = "https://otcharts.com/chart/?s=$otcCode&m=iq&tf=$timeframeSec"
        headlessWebView?.loadUrl(url)
    }

    fun switchOtcAsset(otcCode: String, timeframeSec: Int = 60) {
        if (!isEngineActive) return
        val sanitized = otcCode.trim().uppercase()
        if (_currentOtcCode.value == sanitized) return
        _currentOtcCode.value = sanitized
        mainHandler.post {
            loadOtcUrl(sanitized, timeframeSec)
        }
    }

    inner class AndroidOtcBridge {
        @JavascriptInterface
        fun onPriceTick(
            symbol: String,
            open: Double,
            high: Double,
            low: Double,
            close: Double,
            changePct: Double,
            countdown: String,
            confluence: String,
            isLive: Boolean
        ) {
            if (!isEngineActive) return

            scope.launch(Dispatchers.Main) {
                if (countdown.isNotBlank()) _countdownTimer.value = countdown
                if (confluence.isNotBlank()) _confluenceScore.value = confluence
                _isSseLive.value = isLive
            }

            scope.launch(Dispatchers.Default) {
                onTickReceived(_currentOtcCode.value, open, high, low, close, changePct)
            }
        }
    }

    fun destroy() {
        isEngineActive = false
        mainHandler.post {
            try {
                headlessWebView?.stopLoading()
                headlessWebView?.destroy()
                headlessWebView = null
            } catch (_: Throwable) {}
        }
    }
}
