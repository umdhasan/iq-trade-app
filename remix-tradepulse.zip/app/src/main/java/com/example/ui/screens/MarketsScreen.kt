package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.MarketSessionEngine
import com.example.engine.TradingSessionInfo
import com.example.model.IqMarketType
import com.example.model.MarketCategory
import com.example.model.TradingAsset
import com.example.ui.NavigationTab
import com.example.ui.TradeProViewModel
import com.example.ui.theme.BearishRed
import com.example.ui.theme.BullishGreen
import com.example.ui.theme.CardBorder
import com.example.ui.theme.CardSurface
import com.example.ui.theme.CardSurfaceElevated
import com.example.ui.theme.CryptoGold
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DarkNavyBg
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.Locale

@Composable
fun MarketsScreen(
    viewModel: TradeProViewModel,
    modifier: Modifier = Modifier
) {
    var activeMainSection by remember { mutableStateOf("IQ_MARKETS") } // "IQ_MARKETS" or "SESSIONS"
    var activeIqMarket by remember { mutableStateOf(IqMarketType.DIGITAL) }

    val assets by viewModel.allAssets.collectAsState()
    val selectedCategory by viewModel.selectedCategory.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()

    val sessions = remember { MarketSessionEngine.getSessions() }
    val currentBstTime = remember { MarketSessionEngine.getCurrentBstFormatted() }

    // Filter assets for active market tab
    val filteredAssets = assets.filter { asset ->
        val matchesMarket = asset.iqMarkets.contains(activeIqMarket)
        val matchesCategory = selectedCategory == null || asset.category == selectedCategory
        val matchesSearch = searchQuery.isBlank() ||
                asset.symbol.contains(searchQuery, ignoreCase = true) ||
                asset.name.contains(searchQuery, ignoreCase = true)

        matchesMarket && matchesCategory && matchesSearch
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkNavyBg)
            .padding(horizontal = 14.dp)
            .testTag("markets_screen")
    ) {
        Spacer(modifier = Modifier.height(10.dp))

        // Top Main Section Switcher: IQ Markets vs Trading Sessions
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(CardSurface)
                .border(1.dp, CardBorder, RoundedCornerShape(10.dp))
                .padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (activeMainSection == "IQ_MARKETS") CyberCyan else Color.Transparent)
                    .clickable { activeMainSection = "IQ_MARKETS" }
                    .padding(vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.ShowChart, contentDescription = null, tint = if (activeMainSection == "IQ_MARKETS") DarkNavyBg else TextSecondary, modifier = Modifier.size(15.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "IQ Option মার্কেট",
                        color = if (activeMainSection == "IQ_MARKETS") DarkNavyBg else TextSecondary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Box(
                modifier = Modifier
                    .weight(1.1f)
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (activeMainSection == "SESSIONS") CryptoGold else Color.Transparent)
                    .clickable { activeMainSection = "SESSIONS" }
                    .padding(vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AccessTime, contentDescription = null, tint = if (activeMainSection == "SESSIONS") DarkNavyBg else TextSecondary, modifier = Modifier.size(15.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "ট্রেডিং সেশন (BST)",
                        color = if (activeMainSection == "SESSIONS") DarkNavyBg else TextSecondary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        if (activeMainSection == "SESSIONS") {
            TradingSessionsSection(
                sessions = sessions,
                currentBstTime = currentBstTime,
                onSelectPair = { pairSymbol ->
                    val matched = assets.firstOrNull { it.symbol.startsWith(pairSymbol, ignoreCase = true) }
                    if (matched != null) {
                        viewModel.selectAsset(matched.id)
                        viewModel.selectTab(NavigationTab.TERMINAL)
                    }
                }
            )
        } else {
            // ==========================================
            // 4 IQ OPTION MARKET LIST TABS
            // ==========================================
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(CardSurfaceElevated)
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                IqMarketType.values().forEach { mType ->
                    val isSel = activeIqMarket == mType
                    val col = Color(mType.badgeColorHex)
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (isSel) col.copy(alpha = 0.25f) else Color.Transparent)
                            .border(1.dp, if (isSel) col else Color.Transparent, RoundedCornerShape(6.dp))
                            .clickable { activeIqMarket = mType }
                            .padding(vertical = 7.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = mType.displayName,
                            color = if (isSel) col else TextSecondary,
                            fontSize = 11.sp,
                            fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.setSearchQuery(it) },
                placeholder = { Text("EUR/USD, গোল্ড, বিটকয়েন, Apple খুঁজুন...", color = TextMuted, fontSize = 12.sp) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = TextMuted, modifier = Modifier.size(16.dp)) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = CardSurface,
                    unfocusedContainerColor = CardSurface,
                    focusedBorderColor = CyberCyan,
                    unfocusedBorderColor = CardBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                shape = RoundedCornerShape(10.dp),
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("market_search_input")
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Category Filter Chips
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                item {
                    CategoryChip(label = "সকল ক্যাটাগরি", isSelected = selectedCategory == null, badgeColor = CyberCyan) {
                        viewModel.selectCategory(null)
                    }
                }
                items(MarketCategory.values()) { category ->
                    CategoryChip(label = category.displayName, isSelected = selectedCategory == category, badgeColor = Color(category.badgeColorHex)) {
                        viewModel.selectCategory(category)
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Asset List
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(filteredAssets, key = { it.id }) { asset ->
                    IqAssetRowCard(
                        asset = asset,
                        onSelect = {
                            viewModel.selectAsset(asset.id)
                            viewModel.selectTab(NavigationTab.TERMINAL)
                        },
                        onScanSignal = {
                            viewModel.selectAsset(asset.id)
                            viewModel.selectTab(NavigationTab.SIGNALS)
                            viewModel.generateSignalForSelectedAsset()
                        },
                        onSetAlert = {
                            viewModel.navigateToAlertsForAsset(asset.id)
                        }
                    )
                }
                item {
                    Spacer(modifier = Modifier.height(80.dp))
                }
            }
        }
    }
}

@Composable
fun IqAssetRowCard(
    asset: TradingAsset,
    onSelect: () -> Unit,
    onScanSignal: () -> Unit,
    onSetAlert: () -> Unit
) {
    val categoryColor = Color(asset.category.badgeColorHex)
    val isPositive = asset.change24h >= 0
    val changeColor = if (isPositive) BullishGreen else BearishRed

    Card(
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = CardSurface),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, CardBorder, RoundedCornerShape(10.dp))
            .clickable(onClick = onSelect)
            .testTag("asset_card_${asset.id}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Left: Icon + Symbol + Category & Feed Source
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(categoryColor.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (asset.category == MarketCategory.CRYPTO) Icons.Default.Bolt else Icons.Default.ShowChart,
                        contentDescription = asset.category.name,
                        tint = categoryColor,
                        modifier = Modifier.size(18.dp)
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = asset.symbol,
                            color = TextPrimary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.width(6.dp))

                        // Feed Badge (IQ OTC Live (SSE) / Binance / Yahoo / OTC Reference / No Public Feed)
                        val feedColor = when (asset.feedSource) {
                            "IQ OTC Live (SSE)" -> CyberCyan
                            "Binance" -> CryptoGold
                            "Yahoo" -> CyberCyan
                            "OTC Reference" -> BullishGreen
                            else -> BearishRed
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(3.dp))
                                .background(feedColor.copy(alpha = 0.15f))
                                .padding(horizontal = 4.dp, vertical = 1.dp)
                        ) {
                            Text(asset.feedSource, color = feedColor, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "পে-আউট: ${asset.payoutPercent}% • ${asset.name}",
                        color = TextMuted,
                        fontSize = 10.sp
                    )
                }
            }

            // Right: Price + Quick Action Buttons
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = String.format(Locale.US, "%.${asset.priceDecimals}f", asset.currentPrice),
                        color = TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (isPositive) Icons.Default.ArrowUpward else Icons.Default.ArrowDownward,
                            contentDescription = null,
                            tint = changeColor,
                            modifier = Modifier.size(11.dp)
                        )
                        Text(
                            text = "${if (isPositive) "+" else ""}${String.format(Locale.US, "%.2f", asset.change24h)}%",
                            color = changeColor,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                // Price Alert Bell
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(CryptoGold.copy(alpha = 0.15f))
                        .border(1.dp, CryptoGold.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
                        .clickable(onClick = onSetAlert)
                        .padding(horizontal = 6.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Default.NotificationsActive, contentDescription = "Alert", tint = CryptoGold, modifier = Modifier.size(14.dp))
                }

                Spacer(modifier = Modifier.width(6.dp))

                // Hasan Signal Button
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(CyberCyan.copy(alpha = 0.15f))
                        .border(1.dp, CyberCyan.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
                        .clickable(onClick = onScanSignal)
                        .padding(horizontal = 8.dp, vertical = 6.dp)
                ) {
                    Text("সিগন্যাল", color = CyberCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun CategoryChip(
    label: String,
    isSelected: Boolean,
    badgeColor: Color,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .background(if (isSelected) badgeColor.copy(alpha = 0.2f) else CardSurface)
            .border(1.dp, if (isSelected) badgeColor else CardBorder, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Text(
            text = label,
            color = if (isSelected) badgeColor else TextSecondary,
            fontSize = 11.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
        )
    }
}

/**
 * 4 Trading Sessions Section in Bengali
 */
@Composable
fun TradingSessionsSection(
    sessions: List<TradingSessionInfo>,
    currentBstTime: String,
    onSelectPair: (String) -> Unit
) {
    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Card(
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = CardSurface),
                modifier = Modifier.fillMaxWidth().border(1.dp, CardBorder, RoundedCornerShape(10.dp))
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier.size(34.dp).clip(RoundedCornerShape(8.dp)).background(CryptoGold.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.AccessTime, contentDescription = null, tint = CryptoGold, modifier = Modifier.size(18.dp))
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text("আন্তর্জাতিক ফরেক্স ও অপশন সেশন", color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text("বর্তমান বাংলাদেশ সময়: $currentBstTime (UTC+6)", color = CyberCyan, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
        }

        items(sessions, key = { it.id }) { session ->
            Card(
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = CardSurface),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, if (session.isActive) BullishGreen.copy(alpha = 0.5f) else CardBorder, RoundedCornerShape(10.dp))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(session.nameBn, color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("(${session.nameEn})", color = TextMuted, fontSize = 11.sp)
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(if (session.isActive) BullishGreen.copy(alpha = 0.2f) else CardSurfaceElevated)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = if (session.isActive) "সক্রিয় সেশন (ACTIVE)" else "বন্ধ (CLOSED)",
                                color = if (session.isActive) BullishGreen else TextMuted,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text("বাংলাদেশ সময়: ${session.bstHours}", color = CryptoGold, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(session.marketBehaviorBn, color = TextSecondary, fontSize = 11.sp)

                    Spacer(modifier = Modifier.height(8.dp))
                    Text("সেরা ট্রেডিং পেয়ার্স:", color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))

                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(session.bestPairs) { pair ->
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(CyberCyan.copy(alpha = 0.15f))
                                    .clickable { onSelectPair(pair) }
                                    .padding(horizontal = 6.dp, vertical = 3.dp)
                            ) {
                                Text(pair, color = CyberCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(70.dp))
        }
    }
}
