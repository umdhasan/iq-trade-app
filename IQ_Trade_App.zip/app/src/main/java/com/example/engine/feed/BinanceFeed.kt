package com.example.engine.feed

import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject

object BinanceFeed {

    // Maps IQ Option crypto pair symbols to Binance ticker symbols
    private val BINANCE_SYMBOL_MAP = mapOf(
        "BTC/USD" to "BTCUSDT",
        "BTC/USDT" to "BTCUSDT",
        "Bitcoin" to "BTCUSDT",
        "ETH/USD" to "ETHUSDT",
        "ETH/USDT" to "ETHUSDT",
        "Ethereum" to "ETHUSDT",
        "SOL/USD" to "SOLUSDT",
        "Solana" to "SOLUSDT",
        "DOGE/USD" to "DOGEUSDT",
        "Dogecoin" to "DOGEUSDT",
        "BNB/USD" to "BNBUSDT",
        "BNB" to "BNBUSDT",
        "XRP/USD" to "XRPUSDT",
        "Ripple" to "XRPUSDT",
        "ADA/USD" to "ADAUSDT",
        "Cardano" to "ADAUSDT",
        "AVAX/USD" to "AVAXUSDT",
        "Avalanche" to "AVAXUSDT",
        "DOT/USD" to "DOTUSDT",
        "Polkadot" to "DOTUSDT",
        "MATIC/USD" to "POLUSDT",
        "Polygon" to "POLUSDT",
        "LINK/USD" to "LINKUSDT",
        "Chainlink" to "LINKUSDT",
        "TON/USD" to "TONUSDT",
        "Toncoin" to "TONUSDT"
    )

    fun getBinanceSymbol(cleanSymbol: String): String? {
        val normalized = cleanSymbol.replace(" OTC", "").trim()
        return BINANCE_SYMBOL_MAP[normalized]
    }

    /**
     * Fetches prices for all relevant Binance symbols in a single batch request.
     */
    fun fetchPrices(): Map<String, Double> {
        val resultMap = mutableMapOf<String, Double>()
        try {
            val request = Request.Builder()
                .url("https://api.binance.com/api/v3/ticker/price")
                .header("User-Agent", Net.USER_AGENT)
                .build()

            Net.client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return emptyMap()
                val body = response.body?.string() ?: return emptyMap()
                val jsonArray = JSONArray(body)

                for (i in 0 until jsonArray.length()) {
                    val item = jsonArray.getJSONObject(i)
                    val sym = item.getString("symbol")
                    val price = item.getString("price").toDoubleOrNull()
                    if (price != null) {
                        resultMap[sym] = price
                    }
                }
            }
        } catch (_: Exception) {
            // Network fallback
        }
        return resultMap
    }

    /**
     * Fetches single ticker with 24h stats.
     */
    fun fetchSingleTicker(binanceSymbol: String): RealQuote? {
        try {
            val request = Request.Builder()
                .url("https://api.binance.com/api/v3/ticker/24hr?symbol=$binanceSymbol")
                .header("User-Agent", Net.USER_AGENT)
                .build()

            Net.client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return null
                val body = response.body?.string() ?: return null
                val json = JSONObject(body)

                val price = json.getDouble("lastPrice")
                val prevClose = json.getDouble("prevClosePrice")
                val high = json.getDouble("highPrice")
                val low = json.getDouble("lowPrice")

                return RealQuote(
                    symbol = binanceSymbol,
                    price = price,
                    prevClose = prevClose,
                    high24 = high,
                    low24 = low,
                    source = "Binance"
                )
            }
        } catch (_: Exception) {
            return null
        }
    }
}
