package com.example.engine.feed

data class RealQuote(
    val symbol: String,
    val price: Double,
    val prevClose: Double,
    val high24: Double,
    val low24: Double,
    val source: String, // "Binance", "Yahoo", "OTC Reference", "No Public Feed"
    val timestamp: Long = System.currentTimeMillis()
)
