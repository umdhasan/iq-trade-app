package com.example.engine

import com.example.model.Candle
import com.example.model.IqMarketType
import com.example.model.MarketCategory
import com.example.model.TradingAsset
import kotlin.math.abs
import kotlin.random.Random

object IqCatalog {

    data class AssetSpec(
        val id: String,
        val symbol: String,
        val name: String,
        val category: MarketCategory,
        val basePrice: Double,
        val decimals: Int,
        val payout: Int,
        val isOtc: Boolean,
        val feedSource: String, // "Binance", "Yahoo", "OTC Reference", "পাবলিক ফিড নেই"
        val isInternalBasket: Boolean = false,
        val iqMarkets: List<IqMarketType>
    )

    val ALL_SPECS = listOf(
        // ==========================================
        // 1. FOREX MAJORS & MINORS (Real Yahoo Feed)
        // ==========================================
        AssetSpec(
            id = "iq_eurusd",
            symbol = "EUR/USD",
            name = "Euro / US Dollar",
            category = MarketCategory.CURRENCIES,
            basePrice = 1.08450,
            decimals = 5,
            payout = 95,
            isOtc = false,
            feedSource = "Yahoo",
            iqMarkets = listOf(IqMarketType.DIGITAL, IqMarketType.BINARY, IqMarketType.FOREX_CFD, IqMarketType.BLITZ)
        ),
        AssetSpec(
            id = "iq_gbpusd",
            symbol = "GBP/USD",
            name = "British Pound / US Dollar",
            category = MarketCategory.CURRENCIES,
            basePrice = 1.29850,
            decimals = 5,
            payout = 94,
            isOtc = false,
            feedSource = "Yahoo",
            iqMarkets = listOf(IqMarketType.DIGITAL, IqMarketType.BINARY, IqMarketType.FOREX_CFD, IqMarketType.BLITZ)
        ),
        AssetSpec(
            id = "iq_usdjpy",
            symbol = "USD/JPY",
            name = "US Dollar / Japanese Yen",
            category = MarketCategory.CURRENCIES,
            basePrice = 149.650,
            decimals = 3,
            payout = 93,
            isOtc = false,
            feedSource = "Yahoo",
            iqMarkets = listOf(IqMarketType.DIGITAL, IqMarketType.BINARY, IqMarketType.FOREX_CFD)
        ),
        AssetSpec(
            id = "iq_audcad",
            symbol = "AUD/CAD",
            name = "Australian Dollar / Canadian Dollar",
            category = MarketCategory.CURRENCIES,
            basePrice = 0.89520,
            decimals = 5,
            payout = 92,
            isOtc = false,
            feedSource = "Yahoo",
            iqMarkets = listOf(IqMarketType.DIGITAL, IqMarketType.BINARY, IqMarketType.FOREX_CFD)
        ),
        AssetSpec(
            id = "iq_audusd",
            symbol = "AUD/USD",
            name = "Australian Dollar / US Dollar",
            category = MarketCategory.CURRENCIES,
            basePrice = 0.65850,
            decimals = 5,
            payout = 90,
            isOtc = false,
            feedSource = "Yahoo",
            iqMarkets = listOf(IqMarketType.DIGITAL, IqMarketType.BINARY, IqMarketType.FOREX_CFD)
        ),
        AssetSpec(
            id = "iq_usdcad",
            symbol = "USD/CAD",
            name = "US Dollar / Canadian Dollar",
            category = MarketCategory.CURRENCIES,
            basePrice = 1.37800,
            decimals = 5,
            payout = 91,
            isOtc = false,
            feedSource = "Yahoo",
            iqMarkets = listOf(IqMarketType.BINARY, IqMarketType.FOREX_CFD)
        ),
        AssetSpec(
            id = "iq_usdchf",
            symbol = "USD/CHF",
            name = "US Dollar / Swiss Franc",
            category = MarketCategory.CURRENCIES,
            basePrice = 0.86540,
            decimals = 5,
            payout = 90,
            isOtc = false,
            feedSource = "Yahoo",
            iqMarkets = listOf(IqMarketType.BINARY, IqMarketType.FOREX_CFD)
        ),
        AssetSpec(
            id = "iq_eurjpy",
            symbol = "EUR/JPY",
            name = "Euro / Japanese Yen",
            category = MarketCategory.CURRENCIES,
            basePrice = 162.300,
            decimals = 3,
            payout = 92,
            isOtc = false,
            feedSource = "Yahoo",
            iqMarkets = listOf(IqMarketType.DIGITAL, IqMarketType.BINARY)
        ),
        AssetSpec(
            id = "iq_eurgbp",
            symbol = "EUR/GBP",
            name = "Euro / British Pound",
            category = MarketCategory.CURRENCIES,
            basePrice = 0.83520,
            decimals = 5,
            payout = 89,
            isOtc = false,
            feedSource = "Yahoo",
            iqMarkets = listOf(IqMarketType.BINARY, IqMarketType.FOREX_CFD)
        ),

        // ==========================================
        // 2. CRYPTOCURRENCY (Real Binance Feed)
        // ==========================================
        AssetSpec(
            id = "iq_btc",
            symbol = "Bitcoin",
            name = "Bitcoin / USDT",
            category = MarketCategory.CRYPTO,
            basePrice = 67850.00,
            decimals = 2,
            payout = 92,
            isOtc = false,
            feedSource = "Binance",
            iqMarkets = listOf(IqMarketType.DIGITAL, IqMarketType.BINARY, IqMarketType.FOREX_CFD, IqMarketType.BLITZ)
        ),
        AssetSpec(
            id = "iq_eth",
            symbol = "Ethereum",
            name = "Ethereum / USDT",
            category = MarketCategory.CRYPTO,
            basePrice = 2640.50,
            decimals = 2,
            payout = 91,
            isOtc = false,
            feedSource = "Binance",
            iqMarkets = listOf(IqMarketType.DIGITAL, IqMarketType.BINARY, IqMarketType.FOREX_CFD, IqMarketType.BLITZ)
        ),
        AssetSpec(
            id = "iq_sol",
            symbol = "Solana",
            name = "Solana / USDT",
            category = MarketCategory.CRYPTO,
            basePrice = 154.20,
            decimals = 2,
            payout = 93,
            isOtc = false,
            feedSource = "Binance",
            iqMarkets = listOf(IqMarketType.DIGITAL, IqMarketType.BINARY, IqMarketType.BLITZ)
        ),
        AssetSpec(
            id = "iq_doge",
            symbol = "Dogecoin",
            name = "Dogecoin / USDT",
            category = MarketCategory.CRYPTO,
            basePrice = 0.145000,
            decimals = 6,
            payout = 90,
            isOtc = false,
            feedSource = "Binance",
            iqMarkets = listOf(IqMarketType.DIGITAL, IqMarketType.BINARY)
        ),
        AssetSpec(
            id = "iq_bnb",
            symbol = "BNB",
            name = "Binance Coin / USDT",
            category = MarketCategory.CRYPTO,
            basePrice = 588.40,
            decimals = 2,
            payout = 90,
            isOtc = false,
            feedSource = "Binance",
            iqMarkets = listOf(IqMarketType.BINARY, IqMarketType.FOREX_CFD)
        ),

        // ==========================================
        // 3. COMMODITIES (Real Yahoo Feed)
        // ==========================================
        AssetSpec(
            id = "iq_gold",
            symbol = "Gold",
            name = "Gold Spot XAU/USD",
            category = MarketCategory.COMMODITIES,
            basePrice = 2674.50,
            decimals = 2,
            payout = 94,
            isOtc = false,
            feedSource = "Yahoo",
            iqMarkets = listOf(IqMarketType.DIGITAL, IqMarketType.BINARY, IqMarketType.FOREX_CFD, IqMarketType.BLITZ)
        ),
        AssetSpec(
            id = "iq_silver",
            symbol = "Silver",
            name = "Silver Spot XAG/USD",
            category = MarketCategory.COMMODITIES,
            basePrice = 31.850,
            decimals = 3,
            payout = 90,
            isOtc = false,
            feedSource = "Yahoo",
            iqMarkets = listOf(IqMarketType.BINARY, IqMarketType.FOREX_CFD)
        ),
        AssetSpec(
            id = "iq_wti",
            symbol = "Crude Oil WTI",
            name = "WTI Crude Oil Light",
            category = MarketCategory.COMMODITIES,
            basePrice = 70.80,
            decimals = 2,
            payout = 91,
            isOtc = false,
            feedSource = "Yahoo",
            iqMarkets = listOf(IqMarketType.BINARY, IqMarketType.FOREX_CFD)
        ),
        AssetSpec(
            id = "iq_brent",
            symbol = "Brent Oil",
            name = "Brent Crude Oil",
            category = MarketCategory.COMMODITIES,
            basePrice = 74.40,
            decimals = 2,
            payout = 90,
            isOtc = false,
            feedSource = "Yahoo",
            iqMarkets = listOf(IqMarketType.BINARY, IqMarketType.FOREX_CFD)
        ),

        // ==========================================
        // 4. INDICES (Real Yahoo Feed)
        // ==========================================
        AssetSpec(
            id = "iq_sp500",
            symbol = "S&P 500",
            name = "S&P 500 Index US",
            category = MarketCategory.INDICES,
            basePrice = 5860.00,
            decimals = 2,
            payout = 92,
            isOtc = false,
            feedSource = "Yahoo",
            iqMarkets = listOf(IqMarketType.DIGITAL, IqMarketType.FOREX_CFD)
        ),
        AssetSpec(
            id = "iq_us100",
            symbol = "US 100",
            name = "Nasdaq 100 Index",
            category = MarketCategory.INDICES,
            basePrice = 20380.00,
            decimals = 2,
            payout = 93,
            isOtc = false,
            feedSource = "Yahoo",
            iqMarkets = listOf(IqMarketType.DIGITAL, IqMarketType.FOREX_CFD)
        ),
        AssetSpec(
            id = "iq_dji30",
            symbol = "Dow Jones 30",
            name = "Dow Jones Industrial Average",
            category = MarketCategory.INDICES,
            basePrice = 43240.00,
            decimals = 2,
            payout = 91,
            isOtc = false,
            feedSource = "Yahoo",
            iqMarkets = listOf(IqMarketType.FOREX_CFD)
        ),
        AssetSpec(
            id = "iq_ftse",
            symbol = "FTSE 100",
            name = "UK FTSE 100 Index",
            category = MarketCategory.INDICES,
            basePrice = 8350.20,
            decimals = 2,
            payout = 90,
            isOtc = false,
            feedSource = "Yahoo",
            iqMarkets = listOf(IqMarketType.FOREX_CFD)
        ),

        // ==========================================
        // 5. STOCKS (Real Yahoo Feed)
        // ==========================================
        AssetSpec(
            id = "iq_aapl",
            symbol = "Apple",
            name = "Apple Inc. (AAPL)",
            category = MarketCategory.STOCKS,
            basePrice = 232.50,
            decimals = 2,
            payout = 91,
            isOtc = false,
            feedSource = "Yahoo",
            iqMarkets = listOf(IqMarketType.DIGITAL, IqMarketType.BINARY, IqMarketType.FOREX_CFD)
        ),
        AssetSpec(
            id = "iq_tsla",
            symbol = "Tesla",
            name = "Tesla Inc. (TSLA)",
            category = MarketCategory.STOCKS,
            basePrice = 220.80,
            decimals = 2,
            payout = 93,
            isOtc = false,
            feedSource = "Yahoo",
            iqMarkets = listOf(IqMarketType.DIGITAL, IqMarketType.BINARY, IqMarketType.FOREX_CFD)
        ),
        AssetSpec(
            id = "iq_nvda",
            symbol = "NVIDIA",
            name = "NVIDIA Corporation (NVDA)",
            category = MarketCategory.STOCKS,
            basePrice = 138.25,
            decimals = 2,
            payout = 92,
            isOtc = false,
            feedSource = "Yahoo",
            iqMarkets = listOf(IqMarketType.DIGITAL, IqMarketType.FOREX_CFD)
        ),

        // ==========================================
        // 6. OTC ASSETS (Underlying Quote Reference)
        // ==========================================
        AssetSpec(
            id = "iq_eurusd_otc",
            symbol = "EUR/USD OTC",
            name = "EUR/USD (IQ OTC Reference)",
            category = MarketCategory.CURRENCIES,
            basePrice = 1.08450,
            decimals = 5,
            payout = 92,
            isOtc = true,
            feedSource = "OTC Reference",
            iqMarkets = listOf(IqMarketType.DIGITAL, IqMarketType.BINARY, IqMarketType.BLITZ)
        ),
        AssetSpec(
            id = "iq_gbpusd_otc",
            symbol = "GBP/USD OTC",
            name = "GBP/USD (IQ OTC Reference)",
            category = MarketCategory.CURRENCIES,
            basePrice = 1.29850,
            decimals = 5,
            payout = 91,
            isOtc = true,
            feedSource = "OTC Reference",
            iqMarkets = listOf(IqMarketType.DIGITAL, IqMarketType.BINARY)
        ),
        AssetSpec(
            id = "iq_gold_otc",
            symbol = "Gold OTC",
            name = "Gold Spot (IQ OTC Reference)",
            category = MarketCategory.COMMODITIES,
            basePrice = 2674.50,
            decimals = 2,
            payout = 93,
            isOtc = true,
            feedSource = "OTC Reference",
            iqMarkets = listOf(IqMarketType.DIGITAL, IqMarketType.BINARY, IqMarketType.BLITZ)
        ),

        // ==========================================
        // 7. IQ OPTION PROPRIETARY BASKETS (No Public Feed)
        // ==========================================
        AssetSpec(
            id = "iq_eur_idx",
            symbol = "Euro Index",
            name = "IQ Option Euro Basket Index",
            category = MarketCategory.INDICES,
            basePrice = 1120.50,
            decimals = 2,
            payout = 88,
            isOtc = true,
            feedSource = "পাবলিক ফিড নেই",
            isInternalBasket = true,
            iqMarkets = listOf(IqMarketType.BINARY, IqMarketType.DIGITAL)
        )
    )

    fun createInitialAssets(): List<TradingAsset> {
        return ALL_SPECS.map { spec ->
            val candles = generateHistoricalCandles(spec.basePrice, 45, spec.decimals)
            val current = candles.last().close
            val prev = candles[candles.size - 2].close
            val high = candles.maxOf { it.high }
            val low = candles.minOf { it.low }
            val change = ((current - candles.first().open) / candles.first().open) * 100.0

            TradingAsset(
                id = spec.id,
                symbol = spec.symbol,
                name = spec.name,
                category = spec.category,
                basePrice = spec.basePrice,
                currentPrice = current,
                prevPrice = prev,
                change24h = change,
                high24h = high,
                low24h = low,
                payoutPercent = spec.payout,
                isOtc = spec.isOtc,
                priceDecimals = spec.decimals,
                candles = candles,
                feedSource = spec.feedSource,
                isInternalBasket = spec.isInternalBasket,
                iqMarkets = spec.iqMarkets
            )
        }
    }

    private fun generateHistoricalCandles(basePrice: Double, count: Int, decimals: Int): List<Candle> {
        val list = mutableListOf<Candle>()
        var price = basePrice
        val now = System.currentTimeMillis()
        val intervalMs = 60_000L
        val start = now - (count * intervalMs)

        for (i in 0 until count) {
            val deltaPct = (Random.nextDouble() - 0.498) * 0.0016
            val open = price
            price = maxOf(0.000001, price * (1.0 + deltaPct))
            val close = price
            val spread = abs(open - close) + (open * 0.0003 * Random.nextDouble())
            val high = maxOf(open, close) + spread * Random.nextDouble()
            val low = minOf(open, close) - spread * Random.nextDouble()
            val volume = 2000.0 + Random.nextDouble() * 5000.0

            list.add(
                Candle(
                    timestamp = start + (i * intervalMs),
                    open = round(open, decimals),
                    high = round(high, decimals),
                    low = round(low, decimals),
                    close = round(close, decimals),
                    volume = volume
                )
            )
        }
        return list
    }

    private fun round(value: Double, decimals: Int): Double {
        var multiplier = 1.0
        repeat(decimals) { multiplier *= 10.0 }
        return kotlin.math.round(value * multiplier) / multiplier
    }
}
