package com.example.engine.feed

import okhttp3.Request
import org.json.JSONObject

object YahooFeed {

    private val YAHOO_SYMBOL_MAP = mapOf(
        // Forex
        "EUR/USD" to "EURUSD=X",
        "GBP/USD" to "GBPUSD=X",
        "USD/JPY" to "USDJPY=X",
        "AUD/USD" to "AUDUSD=X",
        "USD/CAD" to "USDCAD=X",
        "USD/CHF" to "USDCHF=X",
        "AUD/CAD" to "AUDCAD=X",
        "EUR/GBP" to "EURGBP=X",
        "EUR/JPY" to "EURJPY=X",
        "GBP/JPY" to "GBPJPY=X",
        "NZD/USD" to "NZDUSD=X",
        "EUR/CHF" to "EURCHF=X",
        "AUD/JPY" to "AUDJPY=X",
        "CAD/JPY" to "CADJPY=X",
        "CHF/JPY" to "CHFJPY=X",
        "EUR/AUD" to "EURAUD=X",
        "EUR/CAD" to "EURCAD=X",
        "GBP/AUD" to "GBPAUD=X",

        // Commodities
        "Gold" to "GC=F",
        "Gold OTC" to "GC=F",
        "Silver" to "SI=F",
        "Silver OTC" to "SI=F",
        "Crude Oil WTI" to "CL=F",
        "WTI Crude Oil" to "CL=F",
        "Brent Oil" to "BZ=F",
        "Natural Gas" to "NG=F",
        "Platinum" to "PL=F",

        // Indices
        "S&P 500" to "^GSPC",
        "SP500" to "^GSPC",
        "US 100" to "^IXIC",
        "US100" to "^IXIC",
        "Nasdaq 100" to "^IXIC",
        "Dow Jones 30" to "^DJI",
        "DJI30" to "^DJI",
        "FTSE 100" to "^FTSE",
        "100GBP" to "^FTSE",
        "DAX 40" to "^GDAXI",
        "D30EUR" to "^GDAXI",
        "Nikkei 225" to "^N225",
        "JPN225" to "^N225",

        // Stocks
        "Apple" to "AAPL",
        "Tesla" to "TSLA",
        "Amazon" to "AMZN",
        "Microsoft" to "MSFT",
        "NVIDIA" to "NVDA",
        "Facebook" to "META",
        "Google" to "GOOGL",
        "Intel" to "INTC",
        "Boeing" to "BA",
        "Alibaba" to "BABA"
    )

    private var backoffUntil = 0L
    private var consecutiveErrors = 0

    fun getYahooSymbol(assetSymbol: String): String? {
        val clean = assetSymbol.replace(" OTC", "").trim()
        return YAHOO_SYMBOL_MAP[clean] ?: YAHOO_SYMBOL_MAP[assetSymbol]
    }

    /**
     * Fetches quote from Yahoo Finance v8 chart API.
     */
    fun fetchQuote(yahooSymbol: String): RealQuote? {
        val now = System.currentTimeMillis()
        if (now < backoffUntil) {
            return null
        }

        try {
            val url = "https://query1.finance.yahoo.com/v8/finance/chart/$yahooSymbol?interval=1m&range=1d"
            val request = Request.Builder()
                .url(url)
                .header("User-Agent", Net.USER_AGENT)
                .build()

            Net.client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    handleError()
                    return null
                }
                val body = response.body?.string() ?: return null
                val root = JSONObject(body)
                val chart = root.getJSONObject("chart")
                val results = chart.getJSONArray("result")
                if (results.length() == 0) return null

                val item = results.getJSONObject(0)
                val meta = item.getJSONObject("meta")

                val price = meta.optDouble("regularMarketPrice", 0.0)
                val prevClose = meta.optDouble("previousClose", meta.optDouble("chartPreviousClose", price))
                val high = meta.optDouble("regularMarketDayHigh", price)
                val low = meta.optDouble("regularMarketDayLow", price)

                if (price > 0.0) {
                    consecutiveErrors = 0
                    return RealQuote(
                        symbol = yahooSymbol,
                        price = price,
                        prevClose = prevClose,
                        high24 = high,
                        low24 = low,
                        source = "Yahoo Finance"
                    )
                }
            }
        } catch (_: Exception) {
            handleError()
        }
        return null
    }

    private fun handleError() {
        consecutiveErrors++
        val waitMs = when {
            consecutiveErrors > 5 -> 60_000L
            consecutiveErrors > 3 -> 20_000L
            else -> 5_000L
        }
        backoffUntil = System.currentTimeMillis() + waitMs
    }
}
