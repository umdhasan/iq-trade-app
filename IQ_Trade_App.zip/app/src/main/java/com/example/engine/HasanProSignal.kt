package com.example.engine

import com.example.model.Candle
import com.example.model.ExpiryTime
import com.example.model.SignalDirection
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

enum class HasanSignalType(val code: String, val bengaliLabel: String, val isBullish: Boolean) {
    UP_PLUS("UP+", "শক্তিশালী বুলিশ কনফার্মেশন", true),
    DOWN_PLUS("DOWN+", "শক্তিশালী বিয়ারিশ কনফার্মেশন", false),
    UP_QUESTION("UP?", "সম্ভাব্য বুলিশ রিভার্সাল / টেস্ট", true),
    DOWN_QUESTION("DOWN?", "সম্ভাব্য বিয়ারিশ রিভার্সাল / টেস্ট", false),
    NEUTRAL("NEUTRAL", "মার্কেট রেঞ্জিং / কোনো পরিষ্কার সেটআপ নেই", true)
}

data class HasanSignalResult(
    val signalType: HasanSignalType,
    val direction: SignalDirection,
    val setupStrength: Int, // e.g. 85 (Setup matching score)
    val wma2: Double,
    val ema21: Double,
    val rsi21: Double,
    val candlePattern: String,
    val bengaliExplanation: String,
    val recommendedExpiry: ExpiryTime,
    val closedCandlePrice: Double
)

object HasanProSignal {

    /**
     * Evaluates Hasan Pro Signal strictly from closed candles.
     * Prevents signal repainting.
     */
    fun evaluate(candles: List<Candle>): HasanSignalResult {
        if (candles.size < 25) {
            val lastPrice = candles.lastOrNull()?.close ?: 1.0
            return HasanSignalResult(
                signalType = HasanSignalType.NEUTRAL,
                direction = SignalDirection.CALL,
                setupStrength = 50,
                wma2 = lastPrice,
                ema21 = lastPrice,
                rsi21 = 50.0,
                candlePattern = "পর্যাপ্ত ক্যান্ডেল ডাটা লোড হচ্ছে",
                bengaliExplanation = "নির্ভরযোগ্য সিগন্যালের জন্য ন্যূনতম ২৫টি ক্যান্ডেল প্রয়োজন।",
                recommendedExpiry = ExpiryTime.MIN_1,
                closedCandlePrice = lastPrice
            )
        }

        // Use the latest fully closed candle to guarantee zero repaint
        val closedCandles = if (candles.size >= 2) candles.dropLast(1) else candles
        val lastClosed = closedCandles.last()
        val prevClosed = closedCandles[closedCandles.size - 2]

        val wma2 = calculateWma2(closedCandles)
        val ema21 = calculateEma(closedCandles, 21)
        val rsi21 = calculateRsi(closedCandles, 21)

        val body = abs(lastClosed.close - lastClosed.open)
        val range = max(lastClosed.high - lastClosed.low, 0.000001)
        val bodyRatio = body / range
        val isBullish = lastClosed.close >= lastClosed.open
        val upperWick = lastClosed.high - max(lastClosed.close, lastClosed.open)
        val lowerWick = min(lastClosed.close, lastClosed.open) - lastClosed.low

        var score = 60
        val signalType: HasanSignalType
        val direction: SignalDirection
        val patternName: String
        val explanation: String
        val expiry: ExpiryTime

        when {
            // ==========================================
            // UP+: Strong Bullish Confluence
            // ==========================================
            isBullish && bodyRatio >= 0.50 && wma2 > ema21 && rsi21 in 52.0..72.0 && lastClosed.close >= ema21 -> {
                signalType = HasanSignalType.UP_PLUS
                direction = SignalDirection.CALL
                patternName = "শক্তিশালী বুলিশ মারুবোজু / ব্রেকআউট (UP+)"
                expiry = if (bodyRatio >= 0.70) ExpiryTime.MIN_1 else ExpiryTime.MIN_2

                score += 15 // WMA > EMA
                if (rsi21 in 55.0..68.0) score += 10
                if (bodyRatio >= 0.65) score += 10
                if (lastClosed.volume > prevClosed.volume) score += 5
                score = min(score, 95)

                explanation = "WMA(2) [${format(wma2)}] পরিষ্কারভাবে EMA(21) [${format(ema21)}]-এর উপরে উঠেছে। RSI(21)=${String.format(Locale.US, "%.1f", rsi21)} এবং শক্তিশালী গ্রিন বডি(${String.format(Locale.US, "%.0f", bodyRatio * 100)}%) কনফার্মেশন দিচ্ছে।"
            }

            // ==========================================
            // DOWN+: Strong Bearish Confluence
            // ==========================================
            !isBullish && bodyRatio >= 0.50 && wma2 < ema21 && rsi21 in 28.0..48.0 && lastClosed.close <= ema21 -> {
                signalType = HasanSignalType.DOWN_PLUS
                direction = SignalDirection.PUT
                patternName = "শক্তিশালী বিয়ারিশ ড্রপ / ব্রেকডাউন (DOWN+)"
                expiry = if (bodyRatio >= 0.70) ExpiryTime.MIN_1 else ExpiryTime.MIN_2

                score += 15 // WMA < EMA
                if (rsi21 in 32.0..45.0) score += 10
                if (bodyRatio >= 0.65) score += 10
                if (lastClosed.volume > prevClosed.volume) score += 5
                score = min(score, 95)

                explanation = "WMA(2) [${format(wma2)}] বিয়ারিশ ক্রসিংয়ে EMA(21) [${format(ema21)}]-এর নিচে নেমেছে। RSI(21)=${String.format(Locale.US, "%.1f", rsi21)} এবং শক্তিশালী রেড বডি(${String.format(Locale.US, "%.0f", bodyRatio * 100)}%) সেলিং প্রেসার নির্দেশ করছে।"
            }

            // ==========================================
            // UP?: Bullish Reversal / Oversold Bounce Test
            // ==========================================
            (lowerWick >= body * 1.3 || rsi21 <= 32.0) && lastClosed.close > prevClosed.close -> {
                signalType = HasanSignalType.UP_QUESTION
                direction = SignalDirection.CALL
                patternName = "বুলিশ রিজেকশন হ্যামার / বাউন্স টেস্ট (UP?)"
                expiry = ExpiryTime.MIN_2

                score += 10
                if (rsi21 <= 30.0) score += 10
                if (lowerWick >= body * 1.8) score += 10
                score = min(score, 88)

                explanation = "নিচ থেকে ক্রেতাদের শক্তিশালী রিজেকশন (লোয়ার শ্যাডো) দেখা গেছে। RSI(21)=${String.format(Locale.US, "%.1f", rsi21)} ওভারসোল্ড জোন থেকে সম্ভাব্য রিভার্সাল টেস্ট করছে।"
            }

            // ==========================================
            // DOWN?: Bearish Reversal / Overbought Exhaustion Test
            // ==========================================
            (upperWick >= body * 1.3 || rsi21 >= 68.0) && lastClosed.close < prevClosed.close -> {
                signalType = HasanSignalType.DOWN_QUESTION
                direction = SignalDirection.PUT
                patternName = "বিয়ারিশ শুটিং স্টার / রিজেকশন টেস্ট (DOWN?)"
                expiry = ExpiryTime.MIN_2

                score += 10
                if (rsi21 >= 70.0) score += 10
                if (upperWick >= body * 1.8) score += 10
                score = min(score, 88)

                explanation = "উচ্চ স্তর থেকে বিক্রেতাদের শক্তিশালী রিজেকশন (আপার শ্যাডো)। RSI(21)=${String.format(Locale.US, "%.1f", rsi21)} ওভারবট লেভেলে পৌঁছে বাউন্স ব্যর্থ হওয়ার ইঙ্গিত দিচ্ছে।"
            }

            else -> {
                signalType = HasanSignalType.NEUTRAL
                direction = if (wma2 >= ema21) SignalDirection.CALL else SignalDirection.PUT
                patternName = "কনসোলিডেশন / রেঞ্জিং ফেজ"
                expiry = ExpiryTime.MIN_1
                score = 55
                explanation = "মার্কেট রেঞ্জিং চ্যানেলে অবস্থান করছে। WMA(2) ও EMA(21) সমান্তরাল চলছে, পরিচ্ছন্ন ব্রেকআউটের জন্য অপেক্ষা করুন।"
            }
        }

        return HasanSignalResult(
            signalType = signalType,
            direction = direction,
            setupStrength = score,
            wma2 = wma2,
            ema21 = ema21,
            rsi21 = rsi21,
            candlePattern = patternName,
            bengaliExplanation = explanation,
            recommendedExpiry = expiry,
            closedCandlePrice = lastClosed.close
        )
    }

    private fun calculateWma2(candles: List<Candle>): Double {
        if (candles.size < 2) return candles.lastOrNull()?.close ?: 0.0
        val c1 = candles[candles.size - 2].close
        val c2 = candles[candles.size - 1].close
        return (c1 + (2.0 * c2)) / 3.0
    }

    private fun calculateEma(candles: List<Candle>, period: Int): Double {
        if (candles.isEmpty()) return 0.0
        val multiplier = 2.0 / (period + 1.0)
        var ema = candles.first().close
        for (i in 1 until candles.size) {
            ema = ((candles[i].close - ema) * multiplier) + ema
        }
        return ema
    }

    private fun calculateRsi(candles: List<Candle>, period: Int): Double {
        if (candles.size <= period) return 50.0
        var gains = 0.0
        var losses = 0.0

        for (i in (candles.size - period) until candles.size) {
            val change = candles[i].close - candles[i - 1].close
            if (change > 0) gains += change else losses += abs(change)
        }

        val avgGain = gains / period
        val avgLoss = losses / period
        if (avgLoss == 0.0) return 100.0
        val rs = avgGain / avgLoss
        return (100.0 - (100.0 / (1.0 + rs))).coerceIn(0.0, 100.0)
    }

    private fun format(v: Double): String {
        return if (v >= 100.0) String.format(Locale.US, "%.2f", v) else String.format(Locale.US, "%.5f", v)
    }
}
