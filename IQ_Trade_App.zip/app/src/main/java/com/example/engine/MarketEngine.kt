package com.example.engine

import com.example.engine.feed.BinanceFeed
import com.example.engine.feed.YahooFeed
import com.example.model.Candle
import com.example.model.IqMarketType
import com.example.model.MarketCategory
import com.example.model.TradingAsset
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlin.random.Random

class MarketEngine(private val scope: CoroutineScope) {

    private val _assets = MutableStateFlow<List<TradingAsset>>(emptyList())
    val assets: StateFlow<List<TradingAsset>> = _assets.asStateFlow()

    // Default asset: EUR/USD
    private val _selectedAssetId = MutableStateFlow<String>("iq_eurusd")
    val selectedAssetId: StateFlow<String> = _selectedAssetId.asStateFlow()

    private val _activeMarketType = MutableStateFlow<IqMarketType>(IqMarketType.DIGITAL)
    val activeMarketType: StateFlow<IqMarketType> = _activeMarketType.asStateFlow()

    init {
        _assets.value = IqCatalog.createInitialAssets()
        startLiveMarketFeed()
        startRealMarketFeedNetworkSync()
    }

    fun setMarketType(type: IqMarketType) {
        _activeMarketType.value = type
    }

    /**
     * Micro-tick oscillator: maintains smooth, continuous 650ms price action on charts
     * between network polls, especially for fast binary/blitz options.
     */
    private fun startLiveMarketFeed() {
        scope.launch(Dispatchers.Default) {
            while (true) {
                delay(650L)

                val updatedList = _assets.value.map { asset ->
                    val volatilityFactor = when {
                        asset.isInternalBasket -> 0.00030
                        asset.category == MarketCategory.CRYPTO -> 0.00045
                        asset.category == MarketCategory.CURRENCIES -> 0.00015
                        asset.category == MarketCategory.INDICES -> 0.00020
                        asset.category == MarketCategory.COMMODITIES -> 0.00025
                        else -> 0.00020
                    }

                    val tickPct = (Random.nextDouble() - 0.499) * volatilityFactor
                    val oldPrice = asset.currentPrice
                    val newPrice = round(oldPrice * (1.0 + tickPct), asset.priceDecimals)

                    val currentCandles = asset.candles.toMutableList()
                    if (currentCandles.isNotEmpty()) {
                        val lastCandle = currentCandles.last()
                        val updatedCandle = lastCandle.copy(
                            high = maxOf(lastCandle.high, newPrice),
                            low = minOf(lastCandle.low, newPrice),
                            close = newPrice,
                            volume = lastCandle.volume + (Random.nextDouble() * 20.0)
                        )
                        currentCandles[currentCandles.size - 1] = updatedCandle
                    }

                    val high24 = maxOf(asset.high24h, newPrice)
                    val low24 = minOf(asset.low24h, newPrice)
                    val change = ((newPrice - asset.basePrice) / asset.basePrice) * 100.0

                    asset.copy(
                        currentPrice = newPrice,
                        prevPrice = oldPrice,
                        change24h = change,
                        high24h = high24,
                        low24h = low24,
                        candles = currentCandles
                    )
                }
                _assets.value = updatedList
            }
        }
    }

    /**
     * Real-world network synchronization loop:
     * - Crypto feeds from Binance Public API (BTC, ETH, SOL, DOGE, BNB)
     * - Forex, Commodities, Indices, Stocks from Yahoo Finance API
     */
    private fun startRealMarketFeedNetworkSync() {
        // 1. Binance Crypto Poller (every 3.5s)
        scope.launch(Dispatchers.IO) {
            while (true) {
                delay(3500L)
                try {
                    val binancePrices = BinanceFeed.fetchPrices()
                    if (binancePrices.isNotEmpty()) {
                        val updated = _assets.value.map { asset ->
                            if (asset.category == MarketCategory.CRYPTO) {
                                val binanceSym = BinanceFeed.getBinanceSymbol(asset.symbol)
                                val realPrice = binancePrices[binanceSym]
                                if (realPrice != null && realPrice > 0.0) {
                                    applyRealNetworkPrice(asset, realPrice)
                                } else asset
                            } else asset
                        }
                        _assets.value = updated
                    }
                } catch (_: Exception) {}
            }
        }

        // 2. Yahoo Finance Poller (every 6s for selected & active forex/commodities)
        scope.launch(Dispatchers.IO) {
            while (true) {
                delay(6000L)
                try {
                    val currentSelId = _selectedAssetId.value
                    val targetAsset = _assets.value.firstOrNull { it.id == currentSelId }

                    if (targetAsset != null && targetAsset.category != MarketCategory.CRYPTO && !targetAsset.isInternalBasket) {
                        val yahooSymbol = YahooFeed.getYahooSymbol(targetAsset.symbol)
                        if (yahooSymbol != null) {
                            val quote = YahooFeed.fetchQuote(yahooSymbol)
                            if (quote != null && quote.price > 0.0) {
                                val updated = _assets.value.map { a ->
                                    if (a.id == targetAsset.id) {
                                        applyRealNetworkPrice(a, quote.price, quote.high24, quote.low24, quote.prevClose)
                                    } else a
                                }
                                _assets.value = updated
                            }
                        }
                    }
                } catch (_: Exception) {}
            }
        }
    }

    private fun applyRealNetworkPrice(
        asset: TradingAsset,
        realPrice: Double,
        networkHigh: Double = 0.0,
        networkLow: Double = 0.0,
        networkPrevClose: Double = 0.0
    ): TradingAsset {
        val clamped = round(realPrice, asset.priceDecimals)
        val currentCandles = asset.candles.toMutableList()
        if (currentCandles.isNotEmpty()) {
            val last = currentCandles.last().copy(
                high = maxOf(currentCandles.last().high, clamped),
                low = minOf(currentCandles.last().low, clamped),
                close = clamped
            )
            currentCandles[currentCandles.size - 1] = last
        }

        val high = if (networkHigh > 0.0) maxOf(networkHigh, clamped) else maxOf(asset.high24h, clamped)
        val low = if (networkLow > 0.0) minOf(networkLow, clamped) else minOf(asset.low24h, clamped)
        val base = if (networkPrevClose > 0.0) networkPrevClose else asset.basePrice
        val change = if (base > 0) ((clamped - base) / base) * 100.0 else asset.change24h

        return asset.copy(
            currentPrice = clamped,
            prevPrice = asset.currentPrice,
            change24h = change,
            high24h = high,
            low24h = low,
            candles = currentCandles
        )
    }

    fun selectAsset(assetId: String) {
        _selectedAssetId.value = assetId
    }

    fun getSelectedAsset(): TradingAsset? {
        val id = _selectedAssetId.value
        return _assets.value.firstOrNull { it.id == id } ?: _assets.value.firstOrNull()
    }

    /**
     * User price calibration utility: sets the exact price directly on the asset and shifts candles.
     */
    fun setExactAssetPrice(assetId: String, exactPrice: Double) {
        val updated = _assets.value.map { asset ->
            if (asset.id == assetId) {
                val clamped = round(exactPrice, asset.priceDecimals)
                val diff = clamped - asset.currentPrice
                val shiftedCandles = asset.candles.map { c ->
                    c.copy(
                        open = round(c.open + diff, asset.priceDecimals),
                        high = round(maxOf(c.high + diff, clamped), asset.priceDecimals),
                        low = round(minOf(c.low + diff, clamped), asset.priceDecimals),
                        close = round(c.close + diff, asset.priceDecimals)
                    )
                }
                val newCandles = if (shiftedCandles.isNotEmpty()) {
                    val last = shiftedCandles.last().copy(close = clamped)
                    shiftedCandles.dropLast(1) + last
                } else shiftedCandles

                asset.copy(
                    basePrice = clamped,
                    currentPrice = clamped,
                    prevPrice = if (newCandles.size >= 2) newCandles[newCandles.size - 2].close else clamped,
                    candles = newCandles
                )
            } else asset
        }
        _assets.value = updated
    }

    fun calibrateAssetPrice(assetId: String, offsetDelta: Double) {
        val asset = _assets.value.firstOrNull { it.id == assetId } ?: return
        setExactAssetPrice(assetId, asset.currentPrice + offsetDelta)
    }

    private fun round(value: Double, decimals: Int): Double {
        var multiplier = 1.0
        repeat(decimals) { multiplier *= 10.0 }
        return kotlin.math.round(value * multiplier) / multiplier
    }
}
