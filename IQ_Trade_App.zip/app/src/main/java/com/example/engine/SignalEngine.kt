package com.example.engine

import com.example.model.ExpiryTime
import com.example.model.MarketCategory
import com.example.model.MarketPlatform
import com.example.model.SignalDirection
import com.example.model.TechnicalIndicators
import com.example.model.TradingAsset
import com.example.model.TradingSignal
import java.util.UUID
import kotlin.math.roundToInt
import kotlin.random.Random

object SignalEngine {

    fun generateSignal(
        asset: TradingAsset,
        indicators: TechnicalIndicators,
        platform: MarketPlatform = MarketPlatform.IQ_OPTION,
        expiryTime: ExpiryTime = ExpiryTime.MIN_1,
        baseTradeAmount: Double = 10.0
    ): TradingSignal {
        // 1. Calculate Hasan Pro Signal from closed candles
        val hasanResult = HasanProSignal.evaluate(asset.candles)

        // 2. Confluence calculation
        val rsiScore = when {
            hasanResult.rsi21 < 32 -> 1.0 // Strong Call
            hasanResult.rsi21 > 68 -> -1.0 // Strong Put
            hasanResult.rsi21 < 48 -> -0.4
            hasanResult.rsi21 > 52 -> 0.4
            else -> 0.0
        }

        val wmaEmaScore = if (hasanResult.wma2 > hasanResult.ema21) 0.9 else -0.9
        val macdScore = if (indicators.macdHistogram > 0) 0.5 else -0.5
        val stochScore = when {
            indicators.stochasticK < 25 -> 0.6
            indicators.stochasticK > 75 -> -0.6
            else -> 0.0
        }

        val totalScore = rsiScore + wmaEmaScore + macdScore + stochScore
        val direction = when (hasanResult.signalType) {
            HasanSignalType.UP_PLUS, HasanSignalType.UP_QUESTION -> SignalDirection.CALL
            HasanSignalType.DOWN_PLUS, HasanSignalType.DOWN_QUESTION -> SignalDirection.PUT
            HasanSignalType.NEUTRAL -> if (totalScore >= 0) SignalDirection.CALL else SignalDirection.PUT
        }

        // Setup Strength score from Hasan Pro Signal (72% to 96%)
        val confidence = hasanResult.setupStrength.coerceIn(75, 96)

        val strategy = when (hasanResult.signalType) {
            HasanSignalType.UP_PLUS -> "Hasan Pro: UP+ (WMA 2 > EMA 21 & Strong Green Marubozu)"
            HasanSignalType.DOWN_PLUS -> "Hasan Pro: DOWN+ (WMA 2 < EMA 21 & Strong Red Breakdown)"
            HasanSignalType.UP_QUESTION -> "Hasan Pro: UP? (Oversold Lower Shadow Rejection Test)"
            HasanSignalType.DOWN_QUESTION -> "Hasan Pro: DOWN? (Overbought Upper Shadow Exhaustion Test)"
            HasanSignalType.NEUTRAL -> "Hasan Pro: Range Channel Confluence"
        }

        val step1 = baseTradeAmount * 2.2
        val step2 = step1 * 2.3

        return TradingSignal(
            id = UUID.randomUUID().toString(),
            assetId = asset.id,
            assetSymbol = asset.symbol,
            assetCategory = asset.category,
            direction = direction,
            confidence = confidence,
            strikePrice = asset.currentPrice,
            expiryTime = hasanResult.recommendedExpiry,
            platform = platform,
            strategyName = strategy,
            martingaleStep1 = roundToTwoDecimals(step1),
            martingaleStep2 = roundToTwoDecimals(step2),
            rsiValue = roundToTwoDecimals(hasanResult.rsi21),
            macdTrend = if (indicators.macdHistogram >= 0) "বুলিশ কনভার্জেন্স" else "বিয়ারিশ ডাইভার্জেন্স"
        )
    }

    private fun roundToTwoDecimals(value: Double): Double {
        return kotlin.math.round(value * 100.0) / 100.0
    }
}
