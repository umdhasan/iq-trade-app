package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.IqMarketType
import com.example.model.MarketCategory
import com.example.model.TradingAsset
import com.example.ui.theme.BearishRed
import com.example.ui.theme.BullishGreen
import com.example.ui.theme.CardBorder
import com.example.ui.theme.CardSurface
import com.example.ui.theme.CardSurfaceElevated
import com.example.ui.theme.CryptoGold
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DarkNavyBg
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.Locale

@Composable
fun AssetPickerModal(
    allAssets: List<TradingAsset>,
    selectedAssetId: String,
    onDismiss: () -> Unit,
    onSelectAsset: (TradingAsset) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedMarketType by remember { mutableStateOf<IqMarketType?>(null) } // null = All
    var selectedCategory by remember { mutableStateOf<MarketCategory?>(null) }

    val filtered = allAssets.filter { asset ->
        val matchesSearch = searchQuery.isBlank() ||
                asset.symbol.contains(searchQuery, ignoreCase = true) ||
                asset.name.contains(searchQuery, ignoreCase = true)

        val matchesMarket = selectedMarketType == null || asset.iqMarkets.contains(selectedMarketType)
        val matchesCategory = selectedCategory == null || asset.category == selectedCategory

        matchesSearch && matchesMarket && matchesCategory
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CardSurfaceElevated,
        modifier = Modifier.testTag("asset_picker_modal"),
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "IQ Option এসেট তালিকা",
                    color = TextPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
                IconButton(onClick = onDismiss, modifier = Modifier.size(24.dp)) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = TextMuted, modifier = Modifier.size(16.dp))
                }
            }
        },
        text = {
            Column(modifier = Modifier.height(440.dp)) {
                // Search Input
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("EUR/USD, গোল্ড, বিটকয়েন...", color = TextMuted, fontSize = 12.sp) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = TextMuted, modifier = Modifier.size(16.dp)) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = DarkNavyBg,
                        unfocusedContainerColor = DarkNavyBg,
                        focusedBorderColor = CyberCyan,
                        unfocusedBorderColor = CardBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth().testTag("asset_search_input")
                )

                Spacer(modifier = Modifier.height(8.dp))

                // 4 IQ Markets Quick Filter Row
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    item {
                        FilterPill(
                            label = "সকল মার্কেট",
                            isSelected = selectedMarketType == null,
                            color = CyberCyan
                        ) { selectedMarketType = null }
                    }
                    items(IqMarketType.values()) { mType ->
                        FilterPill(
                            label = mType.displayName,
                            isSelected = selectedMarketType == mType,
                            color = Color(mType.badgeColorHex)
                        ) { selectedMarketType = mType }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Category Filter Row
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    item {
                        FilterPill(
                            label = "সব ক্যাটাগরি",
                            isSelected = selectedCategory == null,
                            color = TextSecondary
                        ) { selectedCategory = null }
                    }
                    items(MarketCategory.values()) { cat ->
                        FilterPill(
                            label = cat.displayName,
                            isSelected = selectedCategory == cat,
                            color = Color(cat.badgeColorHex)
                        ) { selectedCategory = cat }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Asset List
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(filtered, key = { it.id }) { asset ->
                        val isSelected = asset.id == selectedAssetId
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) CyberCyan.copy(alpha = 0.15f) else CardSurface)
                                .border(1.dp, if (isSelected) CyberCyan else CardBorder, RoundedCornerShape(8.dp))
                                .clickable { onSelectAsset(asset) }
                                .padding(horizontal = 10.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = asset.symbol,
                                        color = TextPrimary,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    // Feed source badge
                                    val sourceColor = when (asset.feedSource) {
                                        "Binance" -> CryptoGold
                                        "Yahoo" -> CyberCyan
                                        "OTC Reference" -> BullishGreen
                                        else -> BearishRed
                                    }
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(3.dp))
                                            .background(sourceColor.copy(alpha = 0.15f))
                                            .padding(horizontal = 4.dp, vertical = 1.dp)
                                    ) {
                                        Text(asset.feedSource, color = sourceColor, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                                Text(
                                    text = "${asset.name} • ${asset.payoutPercent}% পেআউট",
                                    color = TextMuted,
                                    fontSize = 10.sp
                                )
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = String.format(Locale.US, "%.${asset.priceDecimals}f", asset.currentPrice),
                                    color = if (asset.isUp) BullishGreen else BearishRed,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${if (asset.change24h >= 0) "+" else ""}${String.format(Locale.US, "%.2f", asset.change24h)}%",
                                    color = if (asset.change24h >= 0) BullishGreen else BearishRed,
                                    fontSize = 10.sp
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("বন্ধ করুন", color = CyberCyan)
            }
        }
    )
}

@Composable
private fun FilterPill(
    label: String,
    isSelected: Boolean,
    color: Color,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(if (isSelected) color.copy(alpha = 0.22f) else DarkNavyBg)
            .border(1.dp, if (isSelected) color else CardBorder, RoundedCornerShape(6.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Text(
            text = label,
            color = if (isSelected) color else TextSecondary,
            fontSize = 10.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
        )
    }
}
