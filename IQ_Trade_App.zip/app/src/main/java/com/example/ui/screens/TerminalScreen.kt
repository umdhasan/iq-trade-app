package com.example.ui.screens

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CandlestickChart
import androidx.compose.material.icons.filled.DesktopMac
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.engine.HasanSignalType
import com.example.model.ExpiryTime
import com.example.model.SignalDirection
import com.example.model.SimulationTrade
import com.example.model.TradingAsset
import com.example.ui.TradeProViewModel
import com.example.ui.components.AssetPickerModal
import com.example.ui.components.IQ_OPTION_TRADEROOM_URL
import com.example.ui.components.TradingChart
import com.example.ui.theme.BearishRed
import com.example.ui.theme.BullishGreen
import com.example.ui.theme.CardBorder
import com.example.ui.theme.CardSurface
import com.example.ui.theme.CardSurfaceElevated
import com.example.ui.theme.CryptoGold
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DarkNavyBg
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun TerminalScreen(
    viewModel: TradeProViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    val asset by viewModel.selectedAsset.collectAsState()
    val allAssets by viewModel.allAssets.collectAsState()
    val isCandleChart by viewModel.isCandleChart.collectAsState()
    val showIndicators by viewModel.showIndicators.collectAsState()
    val selectedTimeframe by viewModel.selectedTimeframe.collectAsState()
    val demoBalance by viewModel.demoBalance.collectAsState()
    val tradeAmount by viewModel.tradeAmount.collectAsState()
    val activeTrades by viewModel.activeTrades.collectAsState()
    val hasanSignal by viewModel.hasanProSignal.collectAsState()

    var isFullScreen by remember { mutableStateOf(false) }
    var isDesktopMode by remember { mutableStateOf(false) }
    var showAssetPicker by remember { mutableStateOf(false) }
    var showPriceSyncDialog by remember { mutableStateOf(false) }
    var terminalViewMode by remember { mutableStateOf("CHART") } // "CHART" or "IQ_WEBVIEW"
    var webViewRef by remember { mutableStateOf<WebView?>(null) }

    val desktopUserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36"
    val mobileUserAgent = "Mozilla/5.0 (Linux; Android 14; Pixel 8 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Mobile Safari/537.36"

    if (asset == null) {
        Box(modifier = Modifier.fillMaxSize().background(DarkNavyBg), contentAlignment = Alignment.Center) {
            Text("এসেট ডাটা লোড হচ্ছে...", color = TextSecondary)
        }
        return
    }

    val currentAsset = asset!!

    // Full-screen WebView Mode with BackHandler
    if (isFullScreen) {
        BackHandler {
            if (webViewRef?.canGoBack() == true) webViewRef?.goBack()
            else isFullScreen = false
        }

        Box(modifier = Modifier.fillMaxSize().background(DarkNavyBg)) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { ctx ->
                    WebView(ctx).apply {
                        settings.apply {
                            javaScriptEnabled = true
                            domStorageEnabled = true
                            databaseEnabled = true
                            useWideViewPort = true
                            loadWithOverviewMode = true
                            setSupportZoom(true)
                            builtInZoomControls = true
                            displayZoomControls = false
                            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                            userAgentString = if (isDesktopMode) desktopUserAgent else mobileUserAgent
                        }
                        CookieManager.getInstance().setAcceptCookie(true)
                        CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                        webViewClient = WebViewClient()
                        webChromeClient = WebChromeClient()
                        loadUrl(IQ_OPTION_TRADEROOM_URL)
                        webViewRef = this
                    }
                }
            )

            // Top Floating HUD
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(10.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(CardSurface.copy(alpha = 0.92f))
                    .border(1.dp, CardBorder, RoundedCornerShape(8.dp))
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(BullishGreen)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "IQ Option টার্মিনাল",
                        color = CyberCyan,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = {
                            isDesktopMode = !isDesktopMode
                            webViewRef?.settings?.userAgentString = if (isDesktopMode) desktopUserAgent else mobileUserAgent
                            webViewRef?.reload()
                        },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(if (isDesktopMode) Icons.Default.DesktopMac else Icons.Default.PhoneAndroid, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(16.dp))
                    }

                    IconButton(
                        onClick = { webViewRef?.reload() },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(16.dp))
                    }

                    IconButton(
                        onClick = {
                            try {
                                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(IQ_OPTION_TRADEROOM_URL)))
                            } catch (_: Exception) {}
                        },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(Icons.Default.OpenInNew, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(16.dp))
                    }

                    IconButton(
                        onClick = { isFullScreen = false },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(Icons.Default.FullscreenExit, contentDescription = null, tint = CryptoGold, modifier = Modifier.size(18.dp))
                    }
                }
            }
        }
        return
    }

    // Standard Embedded Scrollable Screen
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkNavyBg)
            .verticalScroll(scrollState)
            .padding(horizontal = 12.dp)
            .testTag("terminal_screen")
    ) {
        Spacer(modifier = Modifier.height(10.dp))

        // Top Bar: Asset Selector + IQ Portal Tag + Demo Balance
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Asset Chip Button (Opens Asset Picker)
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(CardSurface)
                    .border(1.dp, CardBorder, RoundedCornerShape(8.dp))
                    .clickable { showAssetPicker = true }
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = currentAsset.symbol,
                    color = TextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.width(4.dp))
                Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(18.dp))
            }

            // IQ Option Portal Tag
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(CyberCyan.copy(alpha = 0.12f))
                    .border(1.dp, CyberCyan.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(BullishGreen))
                Spacer(modifier = Modifier.width(6.dp))
                Text("IQ Option Portal", color = CyberCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }

            // Demo Balance Pill with Reset Icon
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(CardSurface)
                    .border(1.dp, CardBorder, RoundedCornerShape(8.dp))
                    .padding(horizontal = 8.dp, vertical = 5.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("ডেমো ব্যালেন্স:", color = TextMuted, fontSize = 8.sp)
                    Text(
                        text = "$${String.format(Locale.US, "%,.0f", demoBalance)}",
                        color = BullishGreen,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.width(4.dp))
                IconButton(onClick = { viewModel.resetDemoBalance() }, modifier = Modifier.size(20.dp)) {
                    Icon(Icons.Default.RestartAlt, contentDescription = "Reset Demo", tint = TextMuted, modifier = Modifier.size(14.dp))
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Price Header & Feed Source Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = String.format(Locale.US, "%.${currentAsset.priceDecimals}f", currentAsset.currentPrice),
                        color = if (currentAsset.isUp) BullishGreen else BearishRed,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background((if (currentAsset.change24h >= 0) BullishGreen else BearishRed).copy(alpha = 0.15f))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "${if (currentAsset.change24h >= 0) "+" else ""}${String.format(Locale.US, "%.2f", currentAsset.change24h)}%",
                            color = if (currentAsset.change24h >= 0) BullishGreen else BearishRed,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    val feedColor = when (currentAsset.feedSource) {
                        "Binance" -> CryptoGold
                        "Yahoo" -> CyberCyan
                        "OTC Reference" -> BullishGreen
                        else -> BearishRed
                    }
                    Text(
                        text = "${currentAsset.name} • ${currentAsset.payoutPercent}% পেআউট",
                        color = TextMuted,
                        fontSize = 11.sp
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(3.dp))
                            .background(feedColor.copy(alpha = 0.15f))
                            .padding(horizontal = 5.dp, vertical = 1.dp)
                    ) {
                        Text(currentAsset.feedSource, color = feedColor, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Controls: Toggle Chart / WebView + Chart Type + Set Alert
            Row(verticalAlignment = Alignment.CenterVertically) {
                // View Switcher (Chart vs Web)
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (terminalViewMode == "IQ_WEBVIEW") CyberCyan else CardSurface)
                        .border(1.dp, if (terminalViewMode == "IQ_WEBVIEW") CyberCyan else CardBorder, RoundedCornerShape(6.dp))
                        .clickable {
                            terminalViewMode = if (terminalViewMode == "CHART") "IQ_WEBVIEW" else "CHART"
                        }
                        .padding(horizontal = 8.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = if (terminalViewMode == "CHART") "🌐 IQ ওয়েব" else "📊 চার্ট",
                        color = if (terminalViewMode == "IQ_WEBVIEW") DarkNavyBg else TextSecondary,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.width(6.dp))

                IconButton(
                    onClick = { viewModel.toggleChartType() },
                    modifier = Modifier.size(32.dp).clip(RoundedCornerShape(6.dp)).background(CardSurface)
                ) {
                    Icon(if (isCandleChart) Icons.Default.CandlestickChart else Icons.Default.ShowChart, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(16.dp))
                }

                Spacer(modifier = Modifier.width(6.dp))

                IconButton(
                    onClick = { viewModel.navigateToAlertsForAsset(currentAsset.id) },
                    modifier = Modifier.size(32.dp).clip(RoundedCornerShape(6.dp)).background(CryptoGold.copy(alpha = 0.15f))
                ) {
                    Icon(Icons.Default.NotificationsActive, contentDescription = "Set Alert", tint = CryptoGold, modifier = Modifier.size(16.dp))
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Hasan Pro Signal Live HUD Bar
        Card(
            shape = RoundedCornerShape(10.dp),
            colors = CardDefaults.cardColors(containerColor = CardSurface),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, if (hasanSignal.direction == SignalDirection.CALL) BullishGreen.copy(alpha = 0.4f) else BearishRed.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
        ) {
            Column(modifier = Modifier.padding(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background((if (hasanSignal.direction == SignalDirection.CALL) BullishGreen else BearishRed).copy(alpha = 0.2f))
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = "Hasan Pro: ${hasanSignal.signalType.code}",
                                color = if (hasanSignal.direction == SignalDirection.CALL) BullishGreen else BearishRed,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = hasanSignal.signalType.bengaliLabel,
                            color = TextPrimary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(CyberCyan.copy(alpha = 0.15f))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "সেটআপ ম্যাচ: ${hasanSignal.setupStrength}%",
                            color = CyberCyan,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Indicators values: WMA(2), EMA(21), RSI(21)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("WMA(2): ${String.format(Locale.US, "%.${currentAsset.priceDecimals}f", hasanSignal.wma2)}", color = TextMuted, fontSize = 10.sp)
                    Text("EMA(21): ${String.format(Locale.US, "%.${currentAsset.priceDecimals}f", hasanSignal.ema21)}", color = TextMuted, fontSize = 10.sp)
                    Text("RSI(21): ${String.format(Locale.US, "%.1f", hasanSignal.rsi21)}", color = TextMuted, fontSize = 10.sp)
                    Text("ক্লোজড ক্যান্ডেল", color = BullishGreen, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Center View: Chart vs Embedded IQ Option Web Terminal
        if (terminalViewMode == "CHART") {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = CardSurface),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(260.dp)
                    .border(1.dp, CardBorder, RoundedCornerShape(12.dp))
            ) {
                TradingChart(
                    candles = currentAsset.candles,
                    currentPrice = currentAsset.currentPrice,
                    isCandleChart = isCandleChart,
                    showIndicators = showIndicators,
                    indicators = viewModel.technicalIndicators.collectAsState().value,
                    priceDecimals = currentAsset.priceDecimals,
                    modifier = Modifier.fillMaxSize()
                )
            }
        } else {
            // Embedded IQ Option Web Terminal (320dp height)
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = CardSurface),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(340.dp)
                    .border(1.dp, CardBorder, RoundedCornerShape(12.dp))
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    AndroidView(
                        modifier = Modifier.fillMaxSize(),
                        factory = { ctx ->
                            WebView(ctx).apply {
                                settings.apply {
                                    javaScriptEnabled = true
                                    domStorageEnabled = true
                                    databaseEnabled = true
                                    useWideViewPort = true
                                    loadWithOverviewMode = true
                                    setSupportZoom(true)
                                    builtInZoomControls = true
                                    displayZoomControls = false
                                    mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                                    userAgentString = if (isDesktopMode) desktopUserAgent else mobileUserAgent
                                }
                                CookieManager.getInstance().setAcceptCookie(true)
                                CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                                webViewClient = WebViewClient()
                                webChromeClient = WebChromeClient()
                                loadUrl(IQ_OPTION_TRADEROOM_URL)
                                webViewRef = this
                            }
                        }
                    )

                    // Embedded Actions Floating HUD
                    Row(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(8.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(CardSurface.copy(alpha = 0.90f))
                            .padding(4.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        IconButton(onClick = { isFullScreen = true }, modifier = Modifier.size(28.dp)) {
                            Icon(Icons.Default.Fullscreen, contentDescription = "Fullscreen", tint = CyberCyan, modifier = Modifier.size(16.dp))
                        }
                        IconButton(onClick = { webViewRef?.reload() }, modifier = Modifier.size(28.dp)) {
                            Icon(Icons.Default.Refresh, contentDescription = "Refresh", tint = TextSecondary, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Expiry Time Selector (5s Blitz, 15s, 30s, 1m Turbo, 2m, 5m Binary)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("ট্রেড মেয়াদ (Expiry):", color = TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(ExpiryTime.values()) { exp ->
                    val isSel = exp == selectedTimeframe
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (isSel) CyberCyan.copy(alpha = 0.2f) else CardSurface)
                            .border(1.dp, if (isSel) CyberCyan else CardBorder, RoundedCornerShape(6.dp))
                            .clickable { viewModel.setTimeframe(exp) }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = exp.label,
                            color = if (isSel) CyberCyan else TextSecondary,
                            fontSize = 10.sp,
                            fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Demo Investment Amount Preset Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("ট্রেড পরিমাণ: $${tradeAmount.toInt()}", color = TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(listOf(5.0, 10.0, 25.0, 50.0, 100.0)) { amt ->
                    val isSel = amt == tradeAmount
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (isSel) CryptoGold.copy(alpha = 0.2f) else CardSurface)
                            .border(1.dp, if (isSel) CryptoGold else CardBorder, RoundedCornerShape(6.dp))
                            .clickable { viewModel.setTradeAmount(amt) }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "$${amt.toInt()}",
                            color = if (isSel) CryptoGold else TextSecondary,
                            fontSize = 10.sp,
                            fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Interactive CALL / PUT Demo Execution Buttons
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // CALL Button
            Button(
                onClick = { viewModel.executeTrade(SignalDirection.CALL) },
                colors = ButtonDefaults.buttonColors(containerColor = BullishGreen),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.weight(1f).height(50.dp).testTag("call_trade_button")
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.ArrowUpward, contentDescription = null, tint = DarkNavyBg, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("CALL (UP)", color = DarkNavyBg, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold)
                    }
                    Text("+${currentAsset.payoutPercent}% পেআউট", color = DarkNavyBg.copy(alpha = 0.8f), fontSize = 10.sp)
                }
            }

            // PUT Button
            Button(
                onClick = { viewModel.executeTrade(SignalDirection.PUT) },
                colors = ButtonDefaults.buttonColors(containerColor = BearishRed),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.weight(1f).height(50.dp).testTag("put_trade_button")
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.ArrowDownward, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("PUT (DOWN)", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold)
                    }
                    Text("+${currentAsset.payoutPercent}% পেআউট", color = Color.White.copy(alpha = 0.8f), fontSize = 10.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Active Simulation Trades with Real-Time Countdown
        if (activeTrades.isNotEmpty()) {
            Text(
                text = "চলমান ডেমো ট্রেড কাউন্টডাউন (${activeTrades.size})",
                color = TextPrimary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(6.dp))

            activeTrades.forEach { trade ->
                CountdownTradeCard(trade = trade, currentPrice = currentAsset.currentPrice)
                Spacer(modifier = Modifier.height(6.dp))
            }
        }

        Spacer(modifier = Modifier.height(70.dp))
    }

    // Asset Picker Modal Sheet
    if (showAssetPicker) {
        AssetPickerModal(
            allAssets = allAssets,
            selectedAssetId = currentAsset.id,
            onDismiss = { showAssetPicker = false },
            onSelectAsset = { a ->
                viewModel.selectAsset(a.id)
                showAssetPicker = false
            }
        )
    }
}

@Composable
fun CountdownTradeCard(trade: SimulationTrade, currentPrice: Double) {
    val now = System.currentTimeMillis()
    val remainingSec = max(0, ((trade.closeTime - now) / 1000L).toInt())
    val progress = 1.0f - (remainingSec.toFloat() / trade.expirySeconds.toFloat()).coerceIn(0.0f, 1.0f)

    val isWinning = if (trade.direction == SignalDirection.CALL) currentPrice > trade.entryPrice else currentPrice < trade.entryPrice
    val outcomeColor = if (isWinning) BullishGreen else BearishRed

    Card(
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = CardSurface),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, outcomeColor.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .clip(CircleShape)
                            .background(outcomeColor.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (trade.direction == SignalDirection.CALL) Icons.Default.ArrowUpward else Icons.Default.ArrowDownward,
                            contentDescription = null,
                            tint = outcomeColor,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "${trade.assetSymbol} • $${trade.investment.toInt()}",
                        color = TextPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Timer, contentDescription = null, tint = CryptoGold, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "${remainingSec}s বাকি",
                        color = CryptoGold,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Entry vs Current Price Info
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("এন্ট্রি মূল্য: ${trade.entryPrice}", color = TextMuted, fontSize = 10.sp)
                Text(
                    text = if (isWinning) "প্রত্যাশিত লাভ: +$${String.format(Locale.US, "%.1f", trade.investment * (trade.payoutPercent / 100.0))}" else "প্রত্যাশিত লোকসান: -$${trade.investment.toInt()}",
                    color = outcomeColor,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Countdown Progress Line
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)),
                color = outcomeColor,
                trackColor = CardSurfaceElevated
            )
        }
    }
}
