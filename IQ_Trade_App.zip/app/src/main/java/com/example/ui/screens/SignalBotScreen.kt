package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.database.SignalEntity
import com.example.engine.HasanSignalType
import com.example.model.ExpiryTime
import com.example.model.SignalDirection
import com.example.model.TradingSignal
import com.example.ui.TradeProViewModel
import com.example.ui.components.AssetPickerModal
import com.example.ui.theme.BearishRed
import com.example.ui.theme.BullishGreen
import com.example.ui.theme.CardBorder
import com.example.ui.theme.CardSurface
import com.example.ui.theme.CardSurfaceElevated
import com.example.ui.theme.CryptoGold
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DarkNavyBg
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun SignalBotScreen(
    viewModel: TradeProViewModel,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    val selectedAsset by viewModel.selectedAsset.collectAsState()
    val allAssets by viewModel.allAssets.collectAsState()
    val isGenerating by viewModel.isGeneratingSignal.collectAsState()
    val activeSignal by viewModel.activeSignal.collectAsState()
    val hasanSignal by viewModel.hasanProSignal.collectAsState()
    val savedSignals by viewModel.savedSignals.collectAsState()
    val selectedTimeframe by viewModel.selectedTimeframe.collectAsState()

    var showAssetPicker by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkNavyBg)
            .verticalScroll(scrollState)
            .padding(horizontal = 14.dp)
            .testTag("signal_bot_screen")
    ) {
        Spacer(modifier = Modifier.height(10.dp))

        // Header Title
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Hasan Pro Signal ইন্ডিকেটর",
                    color = TextPrimary,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "WMA(2) + EMA(21) + RSI(21) • ক্লোজড ক্যান্ডেল অ্যানালাইসিস",
                    color = CyberCyan,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(CyberCyan.copy(alpha = 0.15f))
                    .border(1.dp, CyberCyan.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text("IQ Option", color = CyberCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Asset & Expiry Selector Card
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = CardSurface),
            modifier = Modifier.fillMaxWidth().border(1.dp, CardBorder, RoundedCornerShape(12.dp))
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("নির্বাচিত এসেট:", color = TextSecondary, fontSize = 11.sp)
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(CardSurfaceElevated)
                            .border(1.dp, CardBorder, RoundedCornerShape(6.dp))
                            .clickable { showAssetPicker = true }
                            .padding(horizontal = 10.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = selectedAsset?.symbol ?: "এসেট বাছুন",
                            color = TextPrimary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(16.dp))
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Timeframe Selector
                Text("ট্রেড মেয়াদ নির্বাচন করুন:", color = TextSecondary, fontSize = 11.sp)
                Spacer(modifier = Modifier.height(4.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(ExpiryTime.values()) { exp ->
                        val isSel = exp == selectedTimeframe
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (isSel) CyberCyan.copy(alpha = 0.2f) else CardSurfaceElevated)
                                .border(1.dp, if (isSel) CyberCyan else CardBorder, RoundedCornerShape(6.dp))
                                .clickable { viewModel.setTimeframe(exp) }
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = exp.label,
                                color = if (isSel) CyberCyan else TextSecondary,
                                fontSize = 11.sp,
                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Hasan Pro Live Technical Indicator Dashboard Card
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = CardSurface),
            modifier = Modifier.fillMaxWidth().border(1.dp, CardBorder, RoundedCornerShape(12.dp))
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Speed, contentDescription = null, tint = CryptoGold, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("লাইভ ইন্ডিকেটর কনফ্লুয়েন্স", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }

                    val tagColor = when (hasanSignal.signalType) {
                        HasanSignalType.UP_PLUS -> BullishGreen
                        HasanSignalType.DOWN_PLUS -> BearishRed
                        HasanSignalType.UP_QUESTION -> CyberCyan
                        HasanSignalType.DOWN_QUESTION -> CryptoGold
                        HasanSignalType.NEUTRAL -> TextMuted
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(tagColor.copy(alpha = 0.2f))
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(hasanSignal.signalType.code, color = tagColor, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Indicators 3-Column Grid
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    IndicatorStatBox(
                        title = "WMA (2)",
                        value = String.format(Locale.US, "%.${selectedAsset?.priceDecimals ?: 5}f", hasanSignal.wma2),
                        color = if (hasanSignal.wma2 >= hasanSignal.ema21) BullishGreen else BearishRed,
                        modifier = Modifier.weight(1f)
                    )
                    IndicatorStatBox(
                        title = "EMA (21)",
                        value = String.format(Locale.US, "%.${selectedAsset?.priceDecimals ?: 5}f", hasanSignal.ema21),
                        color = CyberCyan,
                        modifier = Modifier.weight(1f)
                    )
                    IndicatorStatBox(
                        title = "RSI (21)",
                        value = String.format(Locale.US, "%.1f", hasanSignal.rsi21),
                        color = if (hasanSignal.rsi21 > 70) BearishRed else if (hasanSignal.rsi21 < 30) BullishGreen else TextSecondary,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Pattern & Status
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(CardSurfaceElevated)
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("ক্যান্ডেল প্যাটার্ন ও শর্ত:", color = TextMuted, fontSize = 10.sp)
                        Text(hasanSignal.candlePattern, color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text("সেটআপ স্ট্রেংথ স্কোর:", color = TextMuted, fontSize = 10.sp)
                        Text("${hasanSignal.setupStrength}% ম্যাচ", color = CyberCyan, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "* 'সেটআপ স্ট্রেংথ' নিয়ম মেলার স্কোর, জেতার নিশ্চয়তা নয়। ক্লোজ হওয়া ক্যান্ডেল থেকে সিগন্যাল নির্ধারণ করা হয় যাতে কোনো রিপেইন্ট না হয়।",
                    color = TextMuted,
                    fontSize = 9.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Scan Hasan Pro Signal Button
        Button(
            onClick = { viewModel.generateSignalForSelectedAsset() },
            enabled = !isGenerating,
            colors = ButtonDefaults.buttonColors(containerColor = CyberCyan),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.fillMaxWidth().height(48.dp).testTag("generate_signal_button")
        ) {
            if (isGenerating) {
                CircularProgressIndicator(color = DarkNavyBg, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                Spacer(modifier = Modifier.width(8.dp))
                Text("রিয়েল ফিড স্ক্যান হচ্ছে...", color = DarkNavyBg, fontWeight = FontWeight.Bold)
            } else {
                Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = DarkNavyBg, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Hasan Pro সিগন্যাল স্ক্যান করুন", color = DarkNavyBg, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Active Signal Result Card
        activeSignal?.let { sig ->
            SignalResultCard(signal = sig, onExecuteDemo = { dir -> viewModel.executeTrade(dir) })
            Spacer(modifier = Modifier.height(14.dp))
        }

        // Saved Signals History
        if (savedSignals.isNotEmpty()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("সাম্প্রতিক সিগন্যাল ইতিহাস", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Text("${savedSignals.size} টি সিগন্যাল", color = TextMuted, fontSize = 11.sp)
            }
            Spacer(modifier = Modifier.height(8.dp))

            savedSignals.take(6).forEach { entity ->
                SavedSignalRow(entity = entity)
                Spacer(modifier = Modifier.height(6.dp))
            }
        }

        Spacer(modifier = Modifier.height(70.dp))
    }

    if (showAssetPicker && selectedAsset != null) {
        AssetPickerModal(
            allAssets = allAssets,
            selectedAssetId = selectedAsset!!.id,
            onDismiss = { showAssetPicker = false },
            onSelectAsset = { a ->
                viewModel.selectAsset(a.id)
                showAssetPicker = false
            }
        )
    }
}

@Composable
fun IndicatorStatBox(title: String, value: String, color: Color, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(CardSurfaceElevated)
            .padding(vertical = 8.dp, horizontal = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(title, color = TextMuted, fontSize = 10.sp)
            Spacer(modifier = Modifier.height(2.dp))
            Text(value, color = color, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        }
    }
}

@Composable
fun SignalResultCard(signal: TradingSignal, onExecuteDemo: (SignalDirection) -> Unit) {
    val isCall = signal.direction == SignalDirection.CALL
    val badgeColor = if (isCall) BullishGreen else BearishRed

    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = CardSurface),
        modifier = Modifier
            .fillMaxWidth()
            .border(2.dp, badgeColor, RoundedCornerShape(12.dp))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(badgeColor.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isCall) Icons.Default.ArrowUpward else Icons.Default.ArrowDownward,
                            contentDescription = null,
                            tint = badgeColor,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "${signal.assetSymbol} • ${signal.direction.label}",
                            color = badgeColor,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            text = "মেয়াদ: ${signal.expiryTime.label}",
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(CyberCyan.copy(alpha = 0.2f))
                        .padding(horizontal = 10.dp, vertical = 5.dp)
                ) {
                    Text(
                        text = "স্ট্রেংথ: ${signal.confidence}%",
                        color = CyberCyan,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Strategy Name
            Text(signal.strategyName, color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)

            Spacer(modifier = Modifier.height(8.dp))

            // Strike Price & Martingale Box
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(CardSurfaceElevated)
                    .padding(10.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("স্ট্রাইক প্রাইস:", color = TextMuted, fontSize = 10.sp)
                    Text("${signal.strikePrice}", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("মার্টিনগেল ব্যাকআপ (MTG):", color = TextMuted, fontSize = 10.sp)
                    Text("1st: $${signal.martingaleStep1} • 2nd: $${signal.martingaleStep2}", color = CryptoGold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // 1-Tap Demo Execute Button
            Button(
                onClick = { onExecuteDemo(signal.direction) },
                colors = ButtonDefaults.buttonColors(containerColor = badgeColor),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth().height(42.dp)
            ) {
                Text(
                    text = "ডেমো ট্রেড এক্সেকিউট করুন (${signal.direction.label})",
                    color = if (isCall) DarkNavyBg else Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
            }
        }
    }
}

@Composable
fun SavedSignalRow(entity: SignalEntity) {
    val isCall = entity.direction.equals("CALL", ignoreCase = true)
    val color = if (isCall) BullishGreen else BearishRed
    val dateFormat = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(CardSurface)
            .border(1.dp, CardBorder, RoundedCornerShape(8.dp))
            .padding(10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(if (isCall) Icons.Default.ArrowUpward else Icons.Default.ArrowDownward, contentDescription = null, tint = color, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Column {
                Text("${entity.assetSymbol} (${entity.direction})", color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text(entity.strategyName, color = TextMuted, fontSize = 10.sp, maxLines = 1)
            }
        }

        Column(horizontalAlignment = Alignment.End) {
            Text("${entity.confidence}%", color = CyberCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Text(dateFormat.format(Date(entity.timestamp)), color = TextMuted, fontSize = 9.sp)
        }
    }
}
