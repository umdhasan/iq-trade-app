package com.example.database

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface AlertDao {
    @Query("SELECT * FROM alert_rules ORDER BY createdAt DESC")
    fun getAllRules(): Flow<List<AlertRuleEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRule(rule: AlertRuleEntity)

    @Update
    suspend fun updateRule(rule: AlertRuleEntity)

    @Delete
    suspend fun deleteRule(rule: AlertRuleEntity)

    @Query("DELETE FROM alert_rules WHERE id = :id")
    suspend fun deleteRuleById(id: String)

    @Query("UPDATE alert_rules SET isEnabled = :isEnabled WHERE id = :id")
    suspend fun toggleRuleStatus(id: String, isEnabled: Boolean)

    @Query("UPDATE alert_rules SET triggeredCount = triggeredCount + 1, lastTriggeredAt = :now, isEnabled = 0 WHERE id = :id")
    suspend fun markRuleTriggered(id: String, now: Long)

    @Query("SELECT * FROM alert_notifications ORDER BY timestamp DESC")
    fun getAllNotifications(): Flow<List<AlertNotificationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notification: AlertNotificationEntity)

    @Query("UPDATE alert_notifications SET isRead = 1 WHERE isRead = 0")
    suspend fun markAllAsRead()

    @Query("DELETE FROM alert_notifications")
    suspend fun clearNotifications()
}
