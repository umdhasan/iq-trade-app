package com.example.model

enum class MarketCategory(val displayName: String, val badgeColorHex: Long) {
    CURRENCIES("Currencies", 0xFF14B8A6),
    CRYPTO("Crypto", 0xFFF59E0B),
    COMMODITIES("Commodities", 0xFF38BDF8),
    STOCKS("Stocks", 0xFFA855F7),
    INDICES("Indices", 0xFFEC4899)
}

enum class IqMarketType(val displayName: String, val bengaliName: String, val badgeColorHex: Long) {
    DIGITAL("Digital", "ডিজিটাল", 0xFF00E5FF),
    BINARY("Binary", "বাইনারি", 0xFF10B981),
    FOREX_CFD("Forex/CFD", "ফরেক্স ও সিএফডি", 0xFF8B5CF6),
    BLITZ("Blitz", "ব্লিৎজ", 0xFFF59E0B)
}

enum class MarketPlatform(val displayName: String, val shortName: String) {
    IQ_OPTION("IQ Option", "IQ"),
    POCKET_OPTION("Pocket Option", "PO")
}

enum class ExpiryTime(val label: String, val seconds: Int, val isBlitz: Boolean = false) {
    SEC_5("5s Blitz", 5, true),
    SEC_15("15s Blitz", 15, true),
    SEC_30("30s Blitz", 30, true),
    MIN_1("1m Turbo", 60),
    MIN_2("2m", 120),
    MIN_5("5m Binary", 300)
}

data class Candle(
    val timestamp: Long,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Double
) {
    val isBullish: Boolean get() = close >= open
}

data class TradingAsset(
    val id: String,
    val symbol: String,
    val name: String,
    val category: MarketCategory,
    val basePrice: Double,
    var currentPrice: Double,
    var prevPrice: Double,
    var change24h: Double,
    val high24h: Double,
    val low24h: Double,
    val payoutPercent: Int,
    val isOtc: Boolean = false,
    val priceDecimals: Int = 5,
    val candles: List<Candle> = emptyList(),
    val feedSource: String = "Yahoo", // "Binance", "Yahoo", "OTC Reference", "No Public Feed"
    val isInternalBasket: Boolean = false,
    val iqMarkets: List<IqMarketType> = listOf(IqMarketType.BINARY, IqMarketType.DIGITAL)
) {
    val isUp: Boolean get() = currentPrice >= prevPrice
}

data class TechnicalIndicators(
    val rsi14: Double,
    val ema9: Double,
    val ema21: Double,
    val bbUpper: Double,
    val bbMiddle: Double,
    val bbLower: Double,
    val macdValue: Double,
    val macdSignal: Double,
    val macdHistogram: Double,
    val stochasticK: Double,
    val stochasticD: Double,
    val bullishSentimentPercent: Int,
    val volatilityLevel: String, // "Low", "Medium", "High", "Ultra"
    val trendRecommendation: String // "STRONG_BUY", "BUY", "NEUTRAL", "SELL", "STRONG_SELL"
)
